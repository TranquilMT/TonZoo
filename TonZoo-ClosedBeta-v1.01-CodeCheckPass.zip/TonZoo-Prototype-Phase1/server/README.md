## TonZoo Server (Phase B2)

This server provides **automatic on-chain verification** for deposits using a payment comment:
`TONZOO:<depositId>`

### What it does
- Creates deposit intents (id + expected amount + currency)
- Verifies transactions to your `TREASURY_ADDRESS`
- Confirms matching deposits and returns them to the client to credit in-game

### Start
```bash
cd server
cp .env.example .env
npm install
npm run dev
```

### Provider
- `TON_PROVIDER=tonapi` (recommended) or `toncenter`
- Put your API key in `.env`

### Notes
- For **TON deposits**: matches incoming transfer **comment** `TONZOO:<id>`
- For **USDT on TON**: matches **jetton transfer** with the same comment (works if sender wallet includes it)


### Withdrawals (prototype)
- Client requests withdrawal with currency TON/USDT
- Server queues and processes when `processAfter` passed
- Processing can auto-mark as paid (PAYOUT_MODE=auto) for testing, or manual via Admin (sets txHash)
- In Phase C2 we will replace demo mode with real TON/USDT transfers.

import fetch from "node-fetch";

export function normalizeAddr(a){ return (a||"").replace(/\s+/g,""); }

export async function fetchTonTransactions(env, address, limit=50){
  const provider = env.TON_PROVIDER || "tonapi";
  if(provider === "toncenter"){
    const url = `${env.TONCENTER_BASE}/getTransactions?address=${encodeURIComponent(address)}&limit=${limit}`;
    const res = await fetch(url, { headers: { "X-API-Key": env.TONCENTER_KEY || "" } });
    if(!res.ok) throw new Error(`toncenter http ${res.status}`);
    const j = await res.json();
    return (j.result || []).map(tx => ({
      id: tx.transaction_id?.hash || tx.transaction_id?.lt || String(Math.random()),
      utime: (tx.utime || 0)*1000,
      inMsg: tx.in_msg,
      outMsgs: tx.out_msgs || []
    }));
  }

  // tonapi
  const url = `${env.TONAPI_BASE}/v2/blockchain/accounts/${encodeURIComponent(address)}/transactions?limit=${limit}`;
  const res = await fetch(url, { headers: { "Authorization": `Bearer ${env.TONAPI_KEY || ""}` } });
  if(!res.ok) throw new Error(`tonapi http ${res.status}`);
  const j = await res.json();
  return (j.transactions || []).map(tx => ({
    id: tx.hash,
    utime: (tx.utime || 0)*1000,
    inMsg: tx.in_msg,
    outMsgs: tx.out_msgs || []
  }));
}

export function extractComment(msg){
  if(!msg) return "";
  // tonapi: msg.message, toncenter: msg.message
  return (msg.message || msg.comment || "").toString();
}

export function extractTonAmountNano(msg){
  if(!msg) return 0;
  // tonapi: value, toncenter: value
  return Number(msg.value || 0);
}

import "dotenv/config";
import express from "express";
import cors from "cors";
import { v4 as uuid } from "uuid";
import { fetchTonTransactions, extractComment, extractTonAmountNano, normalizeAddr } from "./ton.js";

import fs from "fs";
import path from "path";
import { Cell } from "@ton/core";


const app = express();
function adminKey(){
  return String(process.env.ADMIN_KEY || "dev");
}
function requireAdmin(req,res){
  const key = req.headers["x-admin-key"] || req.query?.key;
  if (!key || String(key) !== adminKey()){
    res.status(401).json({ ok:false, error:"Unauthorized" });
    return false;
  }
  return true;
}

app.use(express.json());
const PAYOUT_MODE = String(process.env.PAYOUT_MODE || "manual"); 
// manual: admin sets txHash + marks paid
// auto: server marks paid with a generated txHash after processAfter (for testing flows)

function makeTxHash(prefix="TX"){
  const raw = prefix + "-" + Date.now() + "-" + Math.random().toString(16).slice(2);
  return Buffer.from(raw).toString("hex").slice(0, 64);
}

app.use(cors({ origin: process.env.CORS_ORIGIN || "*", credentials: false }));

// In-memory store (prototype). Swap to DB later.
const deposits = new Map(); // id -> { id, userId, currency, usd, coins, expectedNano, status, createdAt, confirmedAt, txHash }
const withdrawals = new Map();
const userStats = new Map(); // userId -> { firstDepositAt, lastDepositAt, withdrawDay, withdrawCount, rl }
const leaderboard = new Map(); // userId -> { name, visitors, prestige, updatedAt }
const referrals = new Map(); // userId -> { referrerId, invitedCount, depositRewarded, pendingCoins }
const profiles = new Map(); // userId -> { name, coinsPurchase, visitors, prestige, updatedAt }


 // userId -> { firstDepositAt, lastDepositAt }
 // id -> {id,userId,address,currency,usd,feePct,netUsd,requestedAt,processAfter,status,paidAt,txHash}

// Server-side ledger (prototype)
const split = { treasury: 0.60, profit: 0.30, buffer: 0.10 };
function loadDb(){
  try{
    if(!fs.existsSync(DB_FILE)) return null;
    const raw = fs.readFileSync(DB_FILE, "utf-8");
    return JSON.parse(raw);
  }catch(e){ return null; }
}

let saveTimer = null;
function scheduleSave(){
  if(saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try{
      const data = {
        ledger,
        deposits: Array.from(deposits.entries()),
        withdrawals: Array.from(withdrawals.entries()),
        userStats: Array.from(userStats.entries()),
        leaderboard: Array.from(leaderboard.entries()),
        referrals: Array.from(referrals.entries()),
        profiles: Array.from(profiles.entries())
      };
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
    }catch(e){}
  }, 250);
}

let ledger = {
  treasuryUsd: 0,
  profitUsd: 0,
  bufferUsd: 0,
  withdrawalsPaused: false,
  withdrawFeePct: 0.03,
  withdrawDepositCooldownMs: 24*60*60*1000,
  withdrawUserDailyMax: 3,
  apiRateLimitPerMin: 60,
  withdrawDelayMs: 24*60*60*1000,
  withdrawDailyCapUsd: 10,
  withdrawWeeklyCapUsd: 30,
  paidTodayUsd: 0,
  paidWeekUsd: 0,
  lastDayKey: null,
  lastWeekKey: null,
  botUsername: "", // optional: for referral share link
};

const loaded = loadDb();
if (loaded) {
  try {
    if (loaded.ledger) ledger = { ...ledger, ...loaded.ledger };
    if (Array.isArray(loaded.deposits)) {
      deposits.clear();
      for (const [k,v] of loaded.deposits) deposits.set(k,v);
    }
    if (Array.isArray(loaded.userStats)) {
      userStats.clear();
      for (const [k,v] of loaded.userStats) userStats.set(k,v);
    }
    if (Array.isArray(loaded.profiles)) {
      profiles.clear();
      for (const [k,v] of loaded.profiles) profiles.set(k,v);
    }
    if (Array.isArray(loaded.referrals)) {
      referrals.clear();
      for (const [k,v] of loaded.referrals) referrals.set(k,v);
    }
    if (Array.isArray(loaded.leaderboard)) {
      leaderboard.clear();
      for (const [k,v] of loaded.leaderboard) leaderboard.set(k,v);
    }
    if (Array.isArray(loaded.withdrawals)) {
      withdrawals.clear();
      for (const [k,v] of loaded.withdrawals) withdrawals.set(k,v);
    }
  } catch(e) {}
}



function dayKey(ts=Date.now()){
  const d=new Date(ts);
  return `${d.getUTCFullYear()}-${d.getUTCMonth()+1}-${d.getUTCDate()}`;
}
function weekKey(ts=Date.now()){
  const d=new Date(ts);
  const day=(d.getUTCDay()+6)%7;
  const monday=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()-day));
  return `${monday.getUTCFullYear()}-${monday.getUTCMonth()+1}-${monday.getUTCDate()}`;
}
function deepFindString(obj, needle){
  try{
    if(obj == null) return null;
    if(typeof obj === "string"){
      return obj.includes(needle) ? obj : null;
    }
    if(typeof obj !== "object") return null;
    if(Array.isArray(obj)){
      for(const it of obj){
        const r = deepFindString(it, needle);
        if(r) return r;
      }
      return null;
    }
    for(const k of Object.keys(obj)){
      const r = deepFindString(obj[k], needle);
      if(r) return r;
    }
    return null;
  }catch{ return null; }
}

function deepPick(obj, keys){
  // find first value for any key in keys in object tree
  try{
    if(obj == null) return null;
    if(typeof obj !== "object") return null;
    if(Array.isArray(obj)){
      for(const it of obj){
        const r = deepPick(it, keys);
        if(r != null) return r;
      }
      return null;
    }
    for(const k of Object.keys(obj)){
      if(keys.includes(k)) return obj[k];
      const r = deepPick(obj[k], keys);
      if(r != null) return r;
    }
    return null;
  }catch{ return null; }
}

function resetCapsIfNeeded(now=Date.now()){
  const dk=dayKey(now);
  const wk=weekKey(now);
  if(ledger.lastDayKey!==dk){ ledger.paidTodayUsd=0; ledger.lastDayKey=dk; }
  if(ledger.lastWeekKey!==wk){ ledger.paidWeekUsd=0; ledger.lastWeekKey=wk; }
}


const DB_FILE = process.env.DB_FILE || path.join(process.cwd(), "tonzoo_db.json");

const TREASURY = normalizeAddr(process.env.TREASURY_ADDRESS || "");

function usdToNanoTon(usd){
  // Prototype conversion for verification:
  // Provide a fixed TON/USD in your front-end when generating expected ton.
  // Here we accept "any >= expected" if expectedNano provided by client.
  return 0;
}

app.get("/api/health", (req,res)=>res.json({ ok:true, treasury:TREASURY }));

app.post("/api/deposits/create", (req,res)=>{
  const { userId="local", currency="TON", usd=1, expectedNano=0 } = req.body || {};
  const id = "dep_" + uuid().slice(0,8);
  const d = {
    id,
    userId,
    currency,
    usd: Number(usd)||1,
    expectedNano: Number(expectedNano)||0,
    status: "Pending",
    createdAt: Date.now()
  };
  deposits.set(id, d);
  scheduleSave();
  res.json({
    deposit: d,
    pay: {
      address: TREASURY,
      comment: `TONZOO:${id}`,
      expectedNano: d.expectedNano
    }
  });

app.post("/api/leaderboard/report", (req,res)=>{
  const { userId="local", name="Player", visitors=0, prestige=0 } = req.body || {};
  if (!rateLimit(userId)) return res.status(429).json({ ok:false, error:"Rate limited." });

  const now = Date.now();
  const row = leaderboard.get(userId) || { name, visitors:0, prestige:0, updatedAt:0 };
  row.name = String(name || row.name || "Player").slice(0,24);
  row.visitors = Math.max(0, Math.floor(Number(visitors)||0));
  row.prestige = Math.max(0, Math.floor(Number(prestige)||0));
  row.updatedAt = now;
  leaderboard.set(userId, row);
  scheduleSave();
  res.json({ ok:true });
});

app.get("/api/leaderboard/top", (req,res)=>{
  const metric = (req.query.metric || "visitors");
  const list = Array.from(leaderboard.values())
    .filter(r => (Date.now() - (r.updatedAt||0)) < 14*86400000) // 14 days freshness
    .sort((a,b)=> (metric==="prestige" ? (b.prestige-a.prestige) : (b.visitors-a.visitors)))
    .slice(0, 25)
    .map(r => ({ name:r.name, visitors:r.visitors, prestige:r.prestige }));
  res.json({ ok:true, metric, leaderboard:list });
});

app.post("/api/referrals/register", (req,res)=>{
  const { userId="local", referrerId=null } = req.body || {};
  if (!rateLimit(userId)) return res.status(429).json({ ok:false, error:"Rate limited." });

  if (!referrerId || String(referrerId).trim()==="") return res.json({ ok:true });

  const u = String(userId);
  const ref = String(referrerId);

  if (u === ref) return res.status(400).json({ ok:false, error:"Cannot refer yourself." });

  const ur = getReferral(u);
  if (ur.referrerId) return res.json({ ok:true, referrerId: ur.referrerId });

  ur.referrerId = ref;
  const rr = getReferral(ref);
  rr.invitedCount = (rr.invitedCount || 0) + 1;

  scheduleSave();
  res.json({ ok:true, referrerId: ref });
});

app.get("/api/referrals/status", (req,res)=>{
  const userId = String(req.query.userId || "local");
  if (!rateLimit(userId)) return res.status(429).json({ ok:false, error:"Rate limited." });

  const r = getReferral(userId);
  res.json({ ok:true, referral: { userId, referrerId: r.referrerId, invitedCount: r.invitedCount || 0, pendingCoins: r.pendingCoins || 0 } });
});

app.post("/api/referrals/claim", (req,res)=>{
  const { userId="local" } = req.body || {};
  if (!rateLimit(userId)) return res.status(429).json({ ok:false, error:"Rate limited." });

  const r = getReferral(String(userId));
  const coins = Math.floor(r.pendingCoins || 0);
  r.pendingCoins = 0;
  scheduleSave();
  res.json({ ok:true, coins });

app.post("/api/profile/sync", (req,res)=>{
  const { userId="local", name="Player", coinsPurchase=0, visitors=0, prestige=0 } = req.body || {};
  if (!rateLimit(userId)) return res.status(429).json({ ok:false, error:"Rate limited." });

  const uid = String(userId);
  const now = Date.now();
  const p = getProfile(uid);

  p.name = String(name || p.name || "Player").slice(0,24);

  // Soft anti-cheat: cap per-sync increases (but allow spending decreases)
  p.coinsPurchase = clampDelta(p.coinsPurchase, coinsPurchase, 5000);
  p.visitors = clampDelta(p.visitors, visitors, 50000);
  p.prestige = Math.max(0, Math.floor(Number(prestige)||0));
  p.updatedAt = now;

  profiles.set(uid, p);
  scheduleSave();
  res.json({ ok:true, profile: p });
});

app.get("/api/profile/get", (req,res)=>{
  const userId = String(req.query.userId || "local");
  if (!rateLimit(userId)) return res.status(429).json({ ok:false, error:"Rate limited." });
  const p = getProfile(userId);
  res.json({ ok:true, profile: p });
});


});




});

// Poll chain and confirm matching deposits
app.post("/api/demo/confirm", (req,res)=>{
  // Demo-only shortcut: instantly confirm a deposit intent by id (no chain)
  const id = (req.body?.id || "").trim();
  const dep = deposits.get(id);
  if (!dep) return res.status(404).json({ ok:false, error:"Unknown deposit id" });
  if (dep.status === "Confirmed") return scheduleSave();
  res.json({ ok:true, confirmed:[dep], ledger });

  dep.status = "Confirmed";
  dep.confirmedAt = Date.now();
  // update user stats
  try{
    const uid = dep.userId || "local";
    const st = userStats.get(uid) || { firstDepositAt: null, lastDepositAt: null };
    if (!st.firstDepositAt) st.firstDepositAt = dep.confirmedAt || Date.now();
    // referral deposit reward (one-time)
    try{
      const r = getReferral(uid);
      if (r.referrerId && !r.depositRewarded){
        const inviter = getReferral(String(r.referrerId));
        inviter.pendingCoins = (inviter.pendingCoins || 0) + 600;
        r.depositRewarded = true;
      }
    }catch{}

    st.lastDepositAt = dep.confirmedAt || Date.now();
    userStats.set(uid, st);
  }catch{}

  dep.txHash = "DEMO_TX_" + uuid().slice(0,10);

  // split + ledger
  const tAdd = dep.usd * split.treasury;
  const pAdd = dep.usd * split.profit;
  const bAdd = dep.usd * split.buffer;
  dep.split = { tAdd, pAdd, bAdd, coinsAdd: Math.floor(dep.usd * 1000) };

  ledger.treasuryUsd = +(ledger.treasuryUsd + tAdd).toFixed(2);
  ledger.profitUsd = +(ledger.profitUsd + pAdd).toFixed(2);
  ledger.bufferUsd = +(ledger.bufferUsd + bAdd).toFixed(2);

  deposits.set(id, dep);
  scheduleSave();
  resetCapsIfNeeded(Date.now());
  res.json({ ok:true, confirmed:[dep], ledger });
});

app.get("/api/jetton/wallet_address", async (req,res)=>{
  const owner = String(req.query.owner||"").trim();
  const master = String(req.query.master||process.env.USDT_JETTON_MASTER||"").trim();
  if(!owner || !master) return res.status(400).json({ ok:false, error:"owner/master required" });

  try{
    const ownerAddr = Address.parse(owner);
    const masterAddr = master;
    // stack expects slice containing owner address
    const sliceCell = beginCell().storeAddress(ownerAddr).endCell();
    const sliceB64 = sliceCell.toBoc().toString("base64");

    const tcKey = process.env.TONCENTER_KEY || process.env.TONCENTER_API_KEY || "";
    const urlBase = process.env.TONCENTER_URL || "https://toncenter.com/api/v2";
    const url = urlBase.replace(/\/$/,"") + "/runGetMethod" + (tcKey ? ("?api_key=" + encodeURIComponent(tcKey)) : "");
    const r = await fetch(url, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ address: masterAddr, method: "get_wallet_address", stack: [["slice", sliceB64]] })
    });
    const j = await r.json();

    // toncenter returns {ok:true,result:{stack:...}} in some variants; handle both
    const stack = j?.result?.stack || j?.stack || j?.result || null;
    let addrB64 = null;
    if(Array.isArray(stack) && stack.length){
      // common format: [ ["slice", "BASE64..."], ... ]
      if(Array.isArray(stack[0]) && typeof stack[0][1] === "string") addrB64 = stack[0][1];
      // v3-like object
      if(stack[0]?.value) addrB64 = stack[0].value;
    }
    if(!addrB64) return res.status(500).json({ ok:false, error:"Could not parse runGetMethod response", raw:j });

        // Parse address from returned slice cell
    const boc = Buffer.from(addrB64, "base64");
        const [cell] = Cell.fromBoc(boc);
    const s = cell.beginParse();
    const outAddr = s.loadAddress();

    res.json({ ok:true, jettonWallet: outAddr.toString({ urlSafe: true, bounceable: true }) });
  }catch(e){
    console.error(e);
    res.status(500).json({ ok:false, error: String(e?.message||e) });
  }
});

async function checkUsdtDepositsTonApi(treasuryAddr, jettonMaster, depositId){
  const apiKey = process.env.TONAPI_KEY || "";
  if(!apiKey) return null;
  // TONAPI endpoint per docs: /v2/accounts/{account_id}/jettons/{jetton_id}/history
  const base = process.env.TONAPI_URL || "https://tonapi.io";
  const url = base.replace(/\/$/,"") + `/v2/accounts/${encodeURIComponent(treasuryAddr)}/jettons/${encodeURIComponent(jettonMaster)}/history?limit=50`;
  const r = await fetch(url, { headers: { "Authorization": `Bearer ${apiKey}` } });
  const j = await r.json();
  const needle = `TONZOO:${depositId}`;
  const items = j?.events || j?.items || j?.history || j?.transfers || [];
  for(const it of items){
    const hit = deepFindString(it, needle);
    if(!hit) continue;
    // try get tx hash and amount
    const txHash = deepPick(it, ["hash","tx_hash","transaction_hash","txHash","event_id","id"]);
    const amount = deepPick(it, ["amount","jetton_amount","quantity","value"]);
    return { txHash, amount, raw: it };
  }
  return null;
}

async function scanDeposits(limit){
  const txs = await fetchTonTransactions(process.env, TREASURY, limit);
  const found = [];
  for(const tx of txs){
    const c = extractComment(tx.inMsg);
    if(!c) continue;
    if(!c.startsWith("TONZOO:")) continue;
    const id = c.trim().split("TONZOO:")[1]?.trim();
    if(!id) continue;
    const dep = deposits.get(id);
    if(!dep) continue;
    if(dep.status === "Confirmed") continue;

    if(dep.currency === "TON"){
      const nano = extractTonAmountNano(tx.inMsg);
      if(dep.expectedNano > 0 && nano < dep.expectedNano) continue;
      dep.receivedNano = nano;
    }

    dep.status = "Confirmed";
    dep.confirmedAt = Date.now();
    dep.txHash = tx.id;

    // split + ledger
    const tAdd = dep.usd * split.treasury;
    const pAdd = dep.usd * split.profit;
    const bAdd = dep.usd * split.buffer;
    dep.split = { tAdd, pAdd, bAdd, coinsAdd: Math.floor(dep.usd * 1000) };
    ledger.treasuryUsd = +(ledger.treasuryUsd + tAdd).toFixed(2);
    ledger.profitUsd = +(ledger.profitUsd + pAdd).toFixed(2);
    ledger.bufferUsd = +(ledger.bufferUsd + bAdd).toFixed(2);

    deposits.set(id, dep);
    found.push(dep);
  }

  resetCapsIfNeeded(Date.now());
  scheduleSave();
  return { found, ledger, total: deposits.size };
}

app.post("/api/deposits/check", async (req,res)=>{
  try{
    const limit = Math.min(100, Math.max(10, Number(req.body?.limit)||40));
    const r = await scanDeposits(limit);
    res.json({ ok:true, confirmed: r.found, total: r.total, ledger: r.ledger });
  }catch(e){
    res.status(500).json({ ok:false, error: e.message });
  }
});

app.get("/api/deposits/:id", (req,res)=>{
  const dep = deposits.get(req.params.id);
  if(!dep) return res.status(404).json({ ok:false });
  res.json({ ok:true, deposit: dep });
});

app.get("/api/admin/status", (req,res)=>{
  if (!requireAdmin(req,res)) return;
  resetCapsIfNeeded(Date.now());
  res.json({ ok:true, ledger, totals: { deposits: deposits.size, withdrawals: withdrawals.size } });
});

app.post("/api/admin/config", (req,res)=>{
  if (!requireAdmin(req,res)) return;
  const b = req.body || {};
  if (typeof b.withdrawalsPaused === "boolean") ledger.withdrawalsPaused = b.withdrawalsPaused;
  if (typeof b.withdrawFeePct === "number") ledger.withdrawFeePct = Math.max(0, Math.min(0.2, b.withdrawFeePct));
  if (typeof b.withdrawDelayMs === "number") ledger.withdrawDelayMs = Math.max(0, b.withdrawDelayMs);
  if (typeof b.withdrawDailyCapUsd === "number") ledger.withdrawDailyCapUsd = Math.max(0, b.withdrawDailyCapUsd);
  if (typeof b.withdrawWeeklyCapUsd === "number") ledger.withdrawWeeklyCapUsd = Math.max(0, b.withdrawWeeklyCapUsd);
  resetCapsIfNeeded(Date.now());
  scheduleSave();
  res.json({ ok:true, ledger });
});

app.get("/api/admin/withdrawals", (req,res)=>{
  if (!requireAdmin(req,res)) return;
  const status = String(req.query.status || "all");
  const list = Array.from(withdrawals.values())
    .filter(w => status==="all" ? true : (w.status===status))
    .sort((a,b)=> (b.createdAt||0) - (a.createdAt||0))
    .slice(0, 200);
  res.json({ ok:true, withdrawals:list });
});

app.post("/api/admin/withdrawals/approve", (req,res)=>{
  if (!requireAdmin(req,res)) return;
  const { id="" } = req.body || {};
  const w = withdrawals.get(String(id));
  if (!w) return res.status(404).json({ ok:false, error:"Not found" });
  if (w.status === "Paid") return res.status(400).json({ ok:false, error:"Already paid" });
  w.status = "Approved";
  scheduleSave();
  res.json({ ok:true, withdrawal:w });
});

app.post("/api/admin/withdrawals/deny", (req,res)=>{
  if (!requireAdmin(req,res)) return;
  const { id="", reason="Denied" } = req.body || {};
  const w = withdrawals.get(String(id));
  if (!w) return res.status(404).json({ ok:false, error:"Not found" });
  if (w.status === "Paid") return res.status(400).json({ ok:false, error:"Already paid" });

app.post("/api/admin/withdrawals/markPaid", (req,res)=>{
  if (!requireAdmin(req,res)) return;
  const { id="", txHash="", paidBy="manual" } = req.body || {};
  const w = withdrawals.get(String(id));
  if (!w) return res.status(404).json({ ok:false, error:"Not found" });

  if (w.status === "Denied") return res.status(400).json({ ok:false, error:"Denied withdrawals can't be marked paid." });

app.post("/api/admin/withdrawals/setTx", (req,res)=>{
  if (!requireAdmin(req,res)) return;
  const { id="", txHash="" } = req.body || {};
  const w = withdrawals.get(String(id));
  if (!w) return res.status(404).json({ ok:false, error:"Not found" });
  w.txHash = String(txHash || "").slice(0,120);
  scheduleSave();
  res.json({ ok:true, withdrawal: w });
});



  w.status = "Paid";
  w.paidAt = Date.now();
  w.paidBy = String(paidBy || "manual").slice(0,32);
  w.txHash = String(txHash || "").slice(0,120);

  scheduleSave();
  res.json({ ok:true, withdrawal: w });
});


  w.status = "Denied";
  w.notes = String(reason || "Denied").slice(0,120);

  // refund coins to profile
  try{
    const p = getProfile(String(w.userId));
    p.coinsPurchase = (p.coinsPurchase || 0) + (w.coins || 0);
    profiles.set(String(w.userId), p);
  }catch{}
  scheduleSave();
  res.json({ ok:true, withdrawal:w });
});

app.post("/api/admin/treasury/adjust", (req,res)=>{
  if (!requireAdmin(req,res)) return;
  const { treasuryDelta=0, profitDelta=0, bufferDelta=0 } = req.body || {};
  ledger.treasuryUsd = +(Math.max(0, (ledger.treasuryUsd||0) + Number(treasuryDelta||0))).toFixed(2);
  ledger.profitUsd = +(Math.max(0, (ledger.profitUsd||0) + Number(profitDelta||0))).toFixed(2);
  ledger.bufferUsd = +(Math.max(0, (ledger.bufferUsd||0) + Number(bufferDelta||0))).toFixed(2);
  scheduleSave();
  res.json({ ok:true, ledger });
});



app.post("/api/withdrawals/request", (req,res)=>{
  resetCapsIfNeeded(Date.now());
  const now = Date.now();
  const { userId="local", address="", currency="TON", coins=0 } = req.body || {};

  // enforce deposit + cooldown
  const st = userStats.get(userId);
  if (!st || !st.firstDepositAt) {
    return res.status(400).json({ ok:false, error:"Deposit required before withdrawal." });
  }
  const cd = Number(ledger.withdrawDepositCooldownMs || 0);
  if (cd > 0 && (Date.now() - st.firstDepositAt) < cd) {
    const leftMs = cd - (Date.now() - st.firstDepositAt);
    return res.status(400).json({ ok:false, error:"Withdrawal cooldown active.", cooldownMsLeft: leftMs });

app.get("/api/withdrawals/list", (req,res)=>{
  const userId = String(req.query.userId || "local");
  if (!rateLimit(userId)) return res.status(429).json({ ok:false, error:"Rate limited." });
  const list = Array.from(withdrawals.values())
    .filter(w => String(w.userId) === userId)
    .sort((a,b)=> (a.createdAt||0) - (b.createdAt||0))
    .map(w => ({
      id: w.id,
      userId: w.userId,
      wallet: w.address || "",
      currency: w.currency,
      coins: w.coins,
      usd: w.usd,
      feePct: ledger.withdrawFeePct || 0,
      netUsd: w.netUsd,
      processAfter: w.processAfter,
      status: w.status,
      txHash: w.txHash || "",
      paidAt: w.paidAt || null,
      notes: w.notes || "",
    }));
  res.json({ ok:true, withdrawals: list });
});


  }

  if (!rateLimit(userId)) return res.status(429).json({ ok:false, error:"Rate limited." });

  const st2 = ensureWithdrawDaily(userStats.get(userId) || { firstDepositAt:null, lastDepositAt:null, withdrawDay:null, withdrawCount:0, rl:[] });
  const maxW = Number(ledger.withdrawUserDailyMax || 3);
  if ((st2.withdrawCount || 0) >= maxW){
    userStats.set(userId, st2);
    return res.status(400).json({ ok:false, error:"Daily withdrawal limit reached." });
  }

  const coinsInt = Math.max(0, Math.floor(Number(coins)||0));
  if (coinsInt < 1000) return res.status(400).json({ ok:false, error:"Minimum withdrawal is 1,000 coins ($1)." });

  const usdReq = +(coinsInt / 1000).toFixed(2);

  // Profile balance check (server truth)
  const p = getProfile(String(userId));
  if ((p.visitors || 0) < 1000) return res.status(400).json({ ok:false, error:"Need at least 1,000 visitors to withdraw." });
  if ((p.coinsPurchase || 0) < coinsInt) return res.status(400).json({ ok:false, error:"Not enough coins (server balance)." });

  // Deduct coins now (locks value)
  p.coinsPurchase = Math.max(0, (p.coinsPurchase || 0) - coinsInt);
  profiles.set(String(userId), p);

  const fee = +(usdReq * (ledger.withdrawFeePct || 0)).toFixed(2);
  const netUsd = Math.max(0, +(usdReq - fee).toFixed(2));

  const id = "wd_" + uuid().slice(0,10);
  const w = {
    id,
    userId: String(userId),
    address: String(address || ""),
    currency: String(currency || "TON"),
    coins: coinsInt,
    usd: usdReq,
    feeUsd: fee,
    netUsd,
    createdAt: now,
    processAfter: now + Number(ledger.withdrawDelayMs || 0),
    status: "Requested",
    notes: "",
    txHash: "",
    paidBy: "",
    paidAt: null,
  };

  withdrawals.set(id, w);

  // bump daily counter
  const st3 = ensureWithdrawDaily(userStats.get(userId) || { firstDepositAt:null, lastDepositAt:null, withdrawDay:null, withdrawCount:0, rl:[] });
  st3.withdrawCount = (st3.withdrawCount || 0) + 1;
  userStats.set(userId, st3);

  scheduleSave();
  res.json({ ok:true, withdrawal: w, ledger });
});

app.post("/api/withdrawals/process", async (req,res)=>{
  if (!requireAdmin(req,res)) return;
  resetCapsIfNeeded(Date.now());
  const now = Date.now();
  const paid = [];
  for (const w of withdrawals.values()){
    if (w.status !== "Approved") continue;
    if ((w.processAfter||0) > now) continue;
    if (ledger.withdrawalsPaused){ w.status = "Paused"; continue; }
    if (ledger.treasuryUsd < w.netUsd){ w.status = "Insufficient treasury"; continue; }
    if (ledger.paidTodayUsd + w.netUsd > ledger.withdrawDailyCapUsd){ w.status = "Daily cap reached"; continue; }
    if (ledger.paidWeekUsd + w.netUsd > ledger.withdrawWeeklyCapUsd){ w.status = "Weekly cap reached"; continue; }

    // Prototype payout: mark as paid + deduct treasury (real chain send in Phase C2)
    ledger.treasuryUsd = +(ledger.treasuryUsd - w.netUsd).toFixed(2);
    ledger.paidTodayUsd = +(ledger.paidTodayUsd + w.netUsd).toFixed(2);
    ledger.paidWeekUsd = +(ledger.paidWeekUsd + w.netUsd).toFixed(2);

    w.status = "Paid";
    w.paidAt = now;
    w.paidBy = "auto_process";
    w.txHash = "SIM_TX_" + uuid().slice(0,12);
    paid.push(w);
  }
  scheduleSave();
  res.json({ ok:true, paid, ledger });
});

const PORT = Number(process.env.PORT)||8787;
app.listen(PORT, ()=>console.log(`[tonzoo-server] listening on :${PORT}`));

const POLL_MS = Math.max(0, Number(process.env.POLL_INTERVAL_MS || 0));
if (POLL_MS > 0) {
  console.log(`[tonzoo-server] deposit poller enabled: ${POLL_MS}ms`);
  setInterval(async () => {
    try {
      // scan small window frequently
      await scanDeposits(50);
    } catch (e) {
      // keep quiet to avoid spam
    }
  }, POLL_MS);
}function rateLimit(userId){
  const now = Date.now();
  const st = userStats.get(userId) || { firstDepositAt:null, lastDepositAt:null, withdrawDay:null, withdrawCount:0, rl:[] };
  const windowMs = 60*1000;
  st.rl = (st.rl || []).filter(t => (now - t) < windowMs);
  st.rl.push(now);
  userStats.set(userId, st);
  const limit = Number(ledger.apiRateLimitPerMin || 60);
  return st.rl.length <= limit;
}

function getProfile(userId){
  const p = profiles.get(userId) || { name:"Player", coinsPurchase:0, visitors:0, prestige:0, updatedAt:0 };
  profiles.set(userId, p);
  return p;
}

function clampDelta(oldVal, newVal, maxUp){
  const o = Math.floor(Number(oldVal)||0);
  const n = Math.floor(Number(newVal)||0);
  if (n < 0) return o;
  if (n < o) return n; // allow decreases (spends)
  if ((n - o) > maxUp) return o + maxUp;
  return n;
}

function getReferral(userId){
  const r = referrals.get(userId) || { referrerId: null, invitedCount: 0, depositRewarded: false, pendingCoins: 0 };
  referrals.set(userId, r);
  return r;
}

function ensureWithdrawDaily(st){
  const day = Math.floor(Date.now()/86400000);
  if (st.withdrawDay !== day){
    st.withdrawDay = day;
    st.withdrawCount = 0;
  }
  return st;
}



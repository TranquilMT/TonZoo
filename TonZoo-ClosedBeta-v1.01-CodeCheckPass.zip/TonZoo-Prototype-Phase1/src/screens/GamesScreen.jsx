import React, { useMemo, useState } from "react";
import Card from "../components/Card";
import TasksScreen from "./TasksScreen";
import BoostersScreen from "./BoostersScreen";
import AuctionScreen from "./AuctionScreen";

export default function GamesScreen({ gs }) {
  const [sub, setSub] = useState("games");
  const res = gs.state.lastGameResult;

  const content = useMemo(() => {
    if (sub === "tasks") return <TasksScreen gs={gs} />;
    if (sub === "boosters") return <BoostersScreen gs={gs} />;
    if (sub === "auction") return <AuctionScreen gs={gs} />;

    return (
      <div className="stack">
        {res && (
          <Card className="bigCard">
            <h3 style={{ marginTop: 0 }}>Last result</h3>
            <div className="callout">
              <div><b>{res.game.toUpperCase()}</b> — {res.label}</div>
              {res.reels && <div style={{ fontSize: 22, marginTop: 6 }}>{res.reels.join("  ")}</div>}
              <div className="muted tiny" style={{ marginTop: 6 }}>
                Cost: {res.costVisitors || 0} visitors {res.costTickets ? `• ${res.costTickets} tickets` : ''} • Reward: {res.tickets ? `${res.tickets} tickets` : ''}{res.coins ? ` • +${res.coins} 🟩` : ''}
              </div>
            </div>
          </Card>
        )}

        <Card className="bigCard gradPink">
          <h3 style={{ marginTop: 0 }}>Wheel of Fortune</h3>
          <p className="muted">Costs 50 visitors (or free spins). Wins tickets.</p>
          <div className="row">
            <button
              className="btn btnPrimary"
              style={{ width: "100%" }}
              disabled={Math.floor(gs.state.visitors) < 50 && (gs.state.freeWheelSpins || 0) <= 0}
              onClick={gs.actions.playWheel}
            >
              Spin ({(gs.state.freeWheelSpins || 0) > 0 ? "FREE" : "50 👥"})
            </button>
            <div className="pill blue">Free spins: {gs.state.freeWheelSpins || 0}</div>
          </div>
        </Card>

        <Card className="bigCard gradGold">
          <h3 style={{ marginTop: 0 }}>Slot Machine</h3>
          <p className="muted">Costs 100 visitors. Match symbols to win tickets.</p>
          <button
            className="btn btnPrimary"
            style={{ width: "100%" }}
            disabled={Math.floor(gs.state.visitors) < 100}
            onClick={gs.actions.playSlots}
          >
            Spin (100 👥)
          </button>
        </Card>

        <Card className="bigCard gradIce">
          <h3 style={{ marginTop: 0 }}>Tasks</h3>
          <p className="muted">Complete tasks to earn extra tickets/visitors.</p>
          <button className="btn btnSuccess" onClick={() => setSub("tasks")}>Open Tasks</button>
        </Card>

        <Card className="bigCard">
          <h3 style={{ marginTop: 0 }}>Boosters</h3>
          <p className="muted">Temporary boosts for tickets/visitors.</p>
          <button className="btn btnPrimary" onClick={() => setSub("boosters")}>Open Boosters</button>
        </Card>

        <Card className="bigCard">
          <h3 style={{ marginTop: 0 }}>Auction</h3>
          <p className="muted">Bid visitors to win rare rewards.</p>
          <button className="btn btnPrimary" onClick={() => setSub("auction")}>Open Auction</button>
        <Card className="bigCard gradBlue">
  <h3 style={{ marginTop: 0 }}>Card Flip</h3>
  <p className="muted">Costs 400 tickets. Flip to win purchase coins.</p>
  <button
    className="btn btnPrimary"
    style={{ width: "100%" }}
    disabled={(gs.state.tickets || 0) < 400}
    onClick={gs.actions.playCardFlip}
  >
    Flip (400 🎟️)
  </button>
</Card>

<Card className="bigCard gradMint">
  <h3 style={{ marginTop: 0 }}>Coin Rush</h3>
  <p className="muted">Costs 150 visitors. Quick win for purchase coins.</p>
  <button
    className="btn btnPrimary"
    style={{ width: "100%" }}
    disabled={(gs.state.visitors || 0) < 150}
    onClick={gs.actions.playCoinRush}
  >
    Play (150 👥)
  </button>
</Card>

<Card className="bigCard">
  <h3 style={{ marginTop: 0 }}>Ticket Exchange</h3>
  <p className="muted">Exchange tickets into purchase coins (daily capped).</p>
  <div className="row" style={{ gap: 10, justifyContent: "space-between" }}>
    <button className="btn btnPrimary" onClick={() => gs.actions.exchangeTickets(5000)}>
      Exchange 5,000 🎟️
    </button>
    <button className="btn" onClick={() => gs.actions.exchangeTickets(20000)}>
      Exchange Max
    </button>
  </div>
  <div className="muted tiny" style={{ marginTop: 8 }}>
    Daily cap: 20,000 🎟️ • Used today: {gs.state.ticketExchangeUsed || 0} 🎟️
  </div>
</Card>

</Card>
      </div>
    );
  }, [sub, gs, res]);

  return (
    <div className="screen">
      <div className="segTabs">
        <button className={"segBtn " + (sub === "games" ? "active" : "")} onClick={() => setSub("games")}>
          Games
        </button>
        <button className={"segBtn " + (sub === "tasks" ? "active" : "")} onClick={() => setSub("tasks")}>
          Tasks
        </button>
        <button className={"segBtn " + (sub === "boosters" ? "active" : "")} onClick={() => setSub("boosters")}>
          Boosters
        </button>
        <button className={"segBtn " + (sub === "auction" ? "active" : "")} onClick={() => setSub("auction")}>
          Auction
        </button>
      </div>

      {content}
    </div>
  );
}

import React, { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Card from "../../components/Card";
import MotionCarousel from "../../components/MotionCarousel.jsx";
import { ANIMALS } from "../../data/catalog";

export default function AnimalCarousel({ gs }) {
  const s = gs.state;

  const animals = useMemo(() => {
    const list = (s.shopAnimalIds ? ANIMALS.filter(a => s.shopAnimalIds.includes(a.id)) : ANIMALS).filter(Boolean);
    return list;
  }, [s.shopAnimalIds]);

  const [reveal, setReveal] = useState(null); // { id, t }

  const onBuy = (a) => {
    const beforeOwned = s.ownedAnimals?.[a.id] || 0;
    gs.actions.buyAnimal(a.id);
    const afterOwned = (s.ownedAnimals?.[a.id] || 0); // may not update immediately; still do reveal
    // Show reveal overlay always; "New!" if first
    setReveal({ id: a.id, isNew: beforeOwned === 0, t: Date.now() });
    setTimeout(() => setReveal(null), 1700);
  };

  return (
    <MotionCarousel
      items={animals}
      renderItem={(a) => {
        const owned = s.ownedAnimals?.[a.id] || 0;
        const isDepositOnly = !!a.depositOnly;
        const isFeatured = gs.derived.featuredAnimalId === a.id;
        const baseCost = (a.priceVisitors || 0);
        const shownCost = isFeatured ? Math.floor(baseCost * 0.9) : baseCost;
        const affordable = (s.visitors || 0) >= shownCost;
        const canBuy = !a.locked && !isDepositOnly && (a.priceVisitors != null) && affordable;

        const showing = reveal && reveal.id === a.id;

        return (
          <Card className={"animalCard " + rarityTheme(a.rarity)} key={a.id}>
            <div className="animalTop">
              <motion.div
                className="animalIconWrap"
                initial={{ scale: 0.98, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.18 }}
              >
                <img className="animalIcon" src={a.icon || "/animal-icons/penguin.svg"} alt={a.name} />
                <div className="animalGlow" />
              </motion.div>

              <div style={{ flex: 1 }}>
                <div className="row" style={{ justifyContent: "space-between", gap: 10 }}>
                  <div>
                    <div className="cardTitle">{a.name}</div>
                    <div className="muted tiny">{a.rarity || "Normal"} • Works {a.workDays || 0} days</div>
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                    <div className="pill">Owned: {owned}</div>
                    {isFeatured ? <div className="pill pink">Featured</div> : null}
                    {isDepositOnly ? <div className="pill pink">Deposit</div> : null}
                  </div>
                </div>

                <div className="row twoCol" style={{ marginTop: 10 }}>
                  <div>
                    <div className="label">Visitors</div>
                    <div className="pill blue">{a.visitorsPerDay || 0} / day 👥</div>
                  </div>
                  <div>
                    <div className="label">Cost</div>
                    <div className={"pill " + (affordable ? "green" : "gray")}>{shownCost.toLocaleString()} 👥 {isFeatured ? "(10% OFF)" : ""}</div>
                  </div>
                </div>

                <div className="row" style={{ gap: 10, marginTop: 12, justifyContent: "space-between" }}>
                  <div className="muted tiny">
                    Tip: more animals = faster visitors = faster withdrawals.
                  </div>

                  <div className="row" style={{ gap: 10 }}>
                    {isDepositOnly ? (
                      <button className="btn btnGold" onClick={() => gs.actions.openDeposit?.()}>
                        Unlock via deposit
                      </button>
                    ) : (
                      <button
                        className={"btn " + (canBuy ? "btnPrimary" : "")}
                        disabled={!canBuy}
                        onClick={() => onBuy(a)}
                      >
                        {canBuy ? "Buy" : "Need more visitors"}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <AnimatePresence>
              {showing ? (
                <motion.div
                  className="hatchOverlay"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <motion.div
                    className="hatchCard"
                    initial={{ scale: 0.85, rotateY: 60, opacity: 0 }}
                    animate={{ scale: 1, rotateY: 0, opacity: 1 }}
                    exit={{ scale: 1.04, opacity: 0 }}
                    transition={{ type: "spring", stiffness: 520, damping: 32 }}
                  >
                    <div className="hatchHeader">
                      <span className="pill pink">Reveal</span>
                      {reveal?.isNew ? <span className="pill green">New!</span> : <span className="pill">+1</span>}
                    </div>

                    <div className="hatchBody">
                      <motion.div
                        className="hatchIcon"
                        initial={{ scale: 0.9 }}
                        animate={{ scale: [0.9, 1.05, 1] }}
                        transition={{ duration: 0.6 }}
                      >
                        <img src={a.icon || "/animal-icons/penguin.svg"} alt={a.name} />
                      </motion.div>

                      <div className="hatchTitle">{reveal?.isFirst ? "Your First Animal!" : (reveal?.isNew ? "New Animal!" : "Added!")}</div>
                      <div className="hatchName">{a.name}</div>
                      <div className="muted tiny">+{a.visitorsPerDay || 0} visitors/day</div>

                      <motion.div
                        className="hatchRing"
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1.2, opacity: [0, 1, 0] }}
                        transition={{ duration: 1.1 }}
                      />
                      <motion.div
                        className="hatchSparkles"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        ✨ ✨ ✨
                      </motion.div>
                    </div>
                  </motion.div>

                  <ConfettiBurst seed={a.id} />
                </motion.div>
              ) : null}
            </AnimatePresence>
          </Card>
        );
      }}
    />
  );
}

function ConfettiBurst({ seed }) {
  // deterministic-ish particles
  const parts = useMemo(() => {
    const s = String(seed || "x");
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    const rand = () => {
      h = (h * 1664525 + 1013904223) >>> 0;
      return (h % 1000) / 1000;
    };
    return new Array(26).fill(0).map((_, i) => ({
      id: i,
      x: rand() * 100,
      r: rand() * 360,
      s: 0.7 + rand() * 0.7,
      d: rand() * 0.12,
    }));
  }, [seed]);

  return (
    <div className="hatchConfetti">
      {parts.map((p) => (
        <motion.div
          key={p.id}
          className="hatchConfettiPiece"
          style={{ left: `${p.x}%`, transform: `rotate(${p.r}deg)` }}
          initial={{ opacity: 0, y: 0, scale: p.s }}
          animate={{ opacity: [0, 1, 0], y: [-10, -120] }}
          transition={{ duration: 1.0, delay: p.d, ease: "easeOut" }}
        />
      ))}
    </div>
  );
}

function rarityTheme(r) {
  if (r === "Exclusive") return "exclusive";
  if (r === "Special") return "special";
  return "normal";
}

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import Card from "../../components/Card";
import MotionCarousel from "../../components/MotionCarousel.jsx";
import { PAVILIONS } from "../../data/catalog";

export default function PavilionCarousel({ gs }) {
  const s = gs.state;

  return (
    <MotionCarousel
      items={PAVILIONS}
      renderItem={(p) => {
        const owned = s.ownedPavilions[p.id] || 0;
        const canBuy = s.coinsPurchase >= p.priceCoins;

        return (
          <Card className={"carouselCard pavilion"}>
            <AnimatePresence>
              {gs.state.lastBought?.kind === "pavilion" && gs.state.lastBought?.id === p.id && (Date.now() - (gs.state.lastBought?.at||0) < 2200) ? (
                <motion.div className="hatchBurst"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.1 }}
                  transition={{ duration: 0.25 }}
                >
                  <motion.div className="hatchRing" animate={{ rotate: 360 }} transition={{ duration: 1.1, repeat: 1, ease: "linear" }} />
                  <motion.div className="hatchSpark" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: -10 }} transition={{ duration: 0.5 }}>
                    🏗️ Built!
                  </motion.div>
                </motion.div>
              ) : null}
            </AnimatePresence>
            <div className="row" style={{ justifyContent: "space-between" }}>
              <div>
                <div className="cardTitle">{p.name}</div>
                <div className="muted tiny">{p.ticketsPerHour} tickets / hour</div>
              </div>
              <div className="pill">Owned: {owned}</div>
            </div>

            <div className="hr" />

            <div className="row twoCol">
              <div>
                <div className="label">Cost</div>
                <div className="pill blue">{p.priceCoins.toLocaleString()} 🟩</div>
              </div>
              <div>
                <div className="label">Value</div>
                <div className="pill blue">{(p.ticketsPerHour * 24).toLocaleString()} / day 🎟️</div>
              </div>
            </div>

            <div className="hr" />

            <button
              className={"btn " + (canBuy ? "btnPrimary" : "btnDisabled")}
              disabled={!canBuy}
              onClick={() => gs.actions.buyPavilion(p.id)}
            >
              Buy Pavilion
            </button>
          </Card>
        );
      }}
    />
  );
}

import React from "react";
import BalancePanel from "../components/BalancePanel";
import ZooPensPanel from "../components/ZooPensPanel";
import AnimalCarousel from "./parts/AnimalCarousel";

export default function AnimalsScreen({ gs }) {
  return (
    <>
      <BalancePanel gs={gs} onExchange={gs.actions.exchangeTickets} />
      <ZooPensPanel gs={gs} />

      <div className="sectionHeader" style={{ marginTop: 10 }}>
        <h3 style={{ margin: 0 }}>Animals</h3>
        <div className="muted tiny">Swipe to browse. Tap a card to snap. Buy to add to your zoo.</div>
      </div>

      <AnimalCarousel gs={gs} />

      <div className="muted tiny" style={{ marginTop: 10, opacity: 0.9 }}>
        Tip: Your first animal is affordable on purpose — after that you’ll want to grow visitors, unlock zones, and plan upgrades.
      </div>
    </>
  );
}

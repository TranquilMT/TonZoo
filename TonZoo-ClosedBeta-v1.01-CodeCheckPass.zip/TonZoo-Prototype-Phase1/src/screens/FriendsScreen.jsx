import React from "react";
import Card from "../components/Card";
import { BOT_USERNAME, MINIAPP_SHORTNAME } from "../config/app.js";

const MILESTONES = [
  { k: 1, title: "Invite 1 friend", reward: "+500 👥" },
  { k: 5, title: "Invite 5 friends", reward: "+5,000 🎟️" },
  { k: 10, title: "Invite 10 friends", reward: "+300 🟩" },
  { k: 25, title: "Invite 25 friends", reward: "+3,000 👥 +15,000 🎟️" },
  { k: 50, title: "Invite 50 friends", reward: "+1,500 🟩 +30,000 🎟️" },
];

export default function FriendsScreen({ gs }) {
  const r = gs.state.referral || { code: "—", invited: 0, active: 0, claimed: {} };
  const appPart = MINIAPP_SHORTNAME ? `/${MINIAPP_SHORTNAME}` : "";
  const inviteLink = `https://t.me/${BOT_USERNAME}${appPart}?startapp=${encodeURIComponent("ref_" + (r.code || "TZXXXX"))}`;

  const copy = async (txt) => {
    try {
      await navigator.clipboard.writeText(txt);
    } catch {}
  };

  return (
    <div className="screen">
      <div className="stack">
        <Card className="bigCard">
          <h3 style={{ marginTop: 0 }}>Friends</h3>
          <div className="muted tiny">Invite friends → earn rewards (prototype).</div>

          <div className="hr" />

          <div className="callout">
            <div className="muted tiny">Your invite code</div>
            <div style={{ fontWeight: 1000, fontSize: 18, letterSpacing: 1 }}>{r.code || "—"}</div>
            <div className="muted tiny" style={{ marginTop: 6 }}>Invite link</div>
            <div className="pill" style={{ marginTop: 6, wordBreak: "break-all" }}>{inviteLink}</div>
            <div className="muted tiny" style={{ marginTop: 6 }}>
              Set <b>BOT_USERNAME</b> in src/config/app.js with your bot username (and optionally /appname) before production.
            </div>

            <div className="grid2" style={{ marginTop: 10 }}>
              <button className="btn btnPrimary" onClick={() => copy(r.code || "")}>Copy code</button>
              <button className="btn btnPrimary" onClick={() => copy(inviteLink)}>Copy link</button>
            </div>
          </div>

          <div className="row" style={{ marginTop: 12 }}>
            <div className="pill">Referred by: {gs.state.referredBy || "—"}</div>
            <div className="pill blue">Invited: {r.invited || 0}</div>
            <div className="pill blue">Active: {r.active || 0}</div>
          </div>

          <div className="hr" />

          <button className="btn btnSuccess" onClick={gs.actions.simulateInvite}>
            Simulate invite (dev)
          </button>
          <div className="muted tiny" style={{ marginTop: 8 }}>
            This is a prototype button so you can test rewards without a backend.
          </div>
        </Card>

        <Card className="bigCard">
          <h3 style={{ marginTop: 0 }}>Reward ladder</h3>
          <div className="list">
            {MILESTONES.map((m) => {
              const claimed = !!r.claimed?.[m.k];
              const unlocked = (r.invited || 0) >= m.k;
              const canClaim = unlocked && !claimed;

              return (
                <div className="listItem" key={m.k} style={{ alignItems: "flex-start" }}>
                  <div style={{ flex: 1 }}>
                    <b>{m.title}</b>
                    <div className="muted tiny">Reward: <b>{m.reward}</b></div>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
                    {claimed ? (
                      <div className="pill green">Claimed</div>
                    ) : unlocked ? (
                      <div className="pill blue">Unlocked</div>
                    ) : (
                      <div className="pill">Locked</div>
                    )}

                    <button
                      className={"btn " + (canClaim ? "btnSuccess" : "btnDisabled")}
                      disabled={!canClaim}
                      onClick={() => gs.actions.claimReferralMilestone(m.k)}
                      style={{ padding: "10px 12px" }}
                    >
                      Claim
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="bigCard">
          <h3 style={{ marginTop: 0 }}>Dev tools</h3>
          <button className="btn btnDanger" onClick={gs.actions.reset}>Reset save</button>
        </Card>
      </div>
    </div>
  );
}

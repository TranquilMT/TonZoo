import React, { useState } from "react";
import { motion } from "framer-motion";
import Card from "../components/Card";
import { BOOSTERS } from "../data/boosters";
import { ANIMALS } from "../data/catalog";
import Icon from "../components/Icon";


function formatMs(ms){
  const s = Math.floor(ms/1000);
  const h = Math.floor(s/3600);
  const m = Math.floor((s%3600)/60);
  const ss = s%60;
  if (h>0) return `${h}h ${m}m`;
  if (m>0) return `${m}m ${ss}s`;
  return `${ss}s`;
}

function costText(cost) {
  if (!cost) return "Free";
  if (cost.coinsPurchase) return `${cost.coinsPurchase} 🟩`;
  return "—";
}

function activeText(b, now, activeBoosters) {
  if (b.effect?.freeWheelSpins) return null;
  const active = (activeBoosters || []).find((x) => x.id === b.id && (!x.expiresAt || now <= x.expiresAt));
  if (!active) return null;
  const leftMs = Math.max(0, active.expiresAt - now);
  const mins = Math.ceil(leftMs / 60000);
  return `Active • ${mins} min left`;
}

export default function BoostersScreen({ gs }) {
  const [previewItem, setPreviewItem] = useState(null);

  const s = gs.state;
  const now = Date.now();

  return (
    <div className="stack">
      <Card className="bigCard featuredCard">
        <div className="sectionHeader" style={{ marginTop: 0 }}>
          <h3 style={{ marginTop: 0 }}><Icon name="event" /> Featured Animal</h3>
          <div className="muted tiny">Daily spotlight • ends in {formatMs(gs.derived.featuredEndsInMs || 0)}</div>
        </div>

        {(() => {
          const fid = gs.derived.featuredAnimalId;
          const a = ANIMALS.find(x => x.id === fid) || ANIMALS[0];
          if (!a) return null;
          const baseCost = a.priceVisitors || 0;
          const cost = Math.floor(baseCost * 0.9);
          const affordable = (s.visitors || 0) >= cost;
          const owned = (s.ownedAnimals?.[a.id] || 0) > 0;

          return (
            <div className="featuredRow">
              <motion.div
                className="featuredIcon"
                initial={{ scale: 0.98, opacity: 0 }}
                animate={{ scale: [0.98, 1.02, 1], opacity: 1 }}
                transition={{ duration: 0.9 }}
              >
                <img src={a.icon} alt={a.name} />
                <motion.div
                  className="featuredPulse"
                  animate={{ opacity: [0.25, 0.65, 0.25], scale: [0.98, 1.05, 0.98] }}
                  transition={{ duration: 2.2, repeat: Infinity }}
                />
              </motion.div>

              <div style={{ flex: 1 }}>
                <div className="row" style={{ justifyContent: "space-between", gap: 10 }}>
                  <div>
                    <div className="cardTitle">{a.name}</div>
                    <div className="muted tiny">{a.rarity} • {a.visitorsPerDay} visitors/day</div>
                  </div>
                  <div className="row" style={{ gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                    <span className="pill pink">10% OFF</span>
                    {owned ? <span className="pill green">Owned (+5% active)</span> : <span className="pill">Not owned</span>}
                  </div>
                </div>

                <div className="row twoCol" style={{ marginTop: 10 }}>
                  <div>
                    <div className="label">Today</div>
                    <div className={"pill " + (affordable ? "green" : "")}>{cost.toLocaleString()} 👥</div>
                  </div>
                  <div>
                    <div className="label">Regular</div>
                    <div className="pill">{baseCost.toLocaleString()} 👥</div>
                  </div>
                </div>

                <div className="row" style={{ marginTop: 12, justifyContent: "flex-end", gap: 10 }}>
                  <button
                    className={"btn " + (affordable ? "btnPrimary" : "")}
                    disabled={!affordable}
                    onClick={() => gs.actions.buyAnimal(a.id)}
                  >
                    {affordable ? "Quick Buy" : "Need more visitors"}
                  </button>
                </div>
              </div>
            </div>
          );
        })()}
      </Card>
<Card className="bigCard">
  <div className="sectionHeader" style={{ marginTop: 0 }}>
    <h3 style={{ marginTop: 0 }}><Icon name="spark" /> Recommended Picks</h3>
    <div className="muted tiny">Smart suggestions based on ROI, synergies, and what you can afford right now.</div>
  </div>

  {(gs.derived.recommendedAnimals || []).length === 0 ? (
    <div className="muted tiny">No recommendations yet — buy your first animals to unlock suggestions.</div>
  ) : (
    (gs.derived.recommendedAnimals || []).map((a) => {
      const fid = gs.derived.featuredAnimalId;
      const baseCost = a.priceVisitors || 0;
      const cost = (fid && a.id === fid) ? Math.floor(baseCost * 0.9) : baseCost;
      const affordable = (s.visitors || 0) >= cost;
      const owned = (s.ownedAnimals?.[a.id] || 0) > 0;
      const roi = cost > 0 ? ((a.visitorsPerDay || 0) / cost) : 0;

      return (
        <div key={a.id} className="tableRow">
          <div className="row" style={{ justifyContent: "space-between", gap: 10 }}>
            <div className="row" style={{ gap: 10 }}>
              <div className="miniIcon">
                <img src={a.icon || "/animal-icons/penguin.svg"} alt={a.name} />
              </div>
              <div>
                <div style={{ fontWeight: 900 }}>{a.name}</div>
                <div className="muted tiny">
                  {a.visitorsPerDay || 0} / day • ROI {roi.toFixed(3)} • Cost {cost.toLocaleString()} 👥
                </div>
              </div>
            </div>

            <div className="row" style={{ gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
              <span className="pill pink">{a.tag || "Pick"}</span>
              {fid === a.id ? <span className="pill">Featured</span> : null}
              {owned ? <span className="pill green">Owned</span> : null}
              <button
                className={"btn " + (affordable ? "btnPrimary" : "")}
                disabled={!affordable || owned}
                onClick={() => gs.actions.buyAnimal(a.id)}
              >
                {owned ? "Owned" : affordable ? "Buy" : "Need more"}
              </button>
            </div>
          </div>
        </div>
      );
    })
  )}
</Card>

<div className="hr" />
<Card className="bigCard">
  <div className="sectionHeader" style={{ marginTop: 0 }}>
    <h3 style={{ marginTop: 0 }}><Icon name="list" /> Your Plan</h3>
    <div className="muted tiny">Save animals you want next. We’ll notify you when you can afford them.</div>
  </div>
<div className="row" style={{ gap: 10, marginTop: 10, justifyContent: "space-between", flexWrap: "wrap" }}>
  <div className="row" style={{ gap: 10, flexWrap: "wrap" }}>
    <span className="pill">Auto-buy</span>
    <button className={"btn " + (gs.derived.autoBuyPlan ? "btnPrimary" : "")} onClick={() => gs.actions.setAutoBuyPlan(!gs.derived.autoBuyPlan)}>
      {gs.derived.autoBuyPlan ? "ON" : "OFF"}
    </button>
    <span className="pill">Daily limit</span>
    <div className="row" style={{ gap: 6 }}>
      {[1,2,3,5].map(n => (
        <button
          key={n}
          className={"btn " + ((gs.derived.autoBuyDailyLimit === n) ? "btnPrimary" : "")}
          onClick={() => gs.actions.setAutoBuyLimit(n)}
        >
          {n}
        </button>
      ))}
    </div>
  </div>
  <div className="muted tiny">Today: {gs.derived.autoBuySpentToday}/{gs.derived.autoBuyDailyLimit}</div>
</div>


  {(gs.derived.planDetailed || []).length === 0 ? (
    <div className="muted tiny">No plan items yet. Tap “Add to Plan” on a recommendation.</div>
  ) : (
    (gs.derived.planDetailed || []).map(p => {
      const owned = (s.ownedAnimals?.[p.id] || 0) > 0;
      return (
        <div key={p.id} className="tableRow">
          <div className="row" style={{ justifyContent:"space-between", gap: 10 }}>
            <div>
              <div style={{ fontWeight: 900 }}>{p.name}</div>
              <div className="muted tiny">Cost {p.cost.toLocaleString()} 👥</div>
            </div>
            <div className="row" style={{ gap: 8, flexWrap:"wrap", justifyContent:"flex-end" }}>
              {owned ? <span className="pill green">Owned</span> : p.affordable ? <span className="pill green">Affordable</span> : <span className="pill">Saving…</span>}
              <button className="btn" onClick={() => gs.actions.removeFromPlan(p.id)}>Remove</button>
              <button
                className={"btn " + (p.affordable && !owned ? "btnPrimary" : "")}
                disabled={!p.affordable || owned}
                onClick={() => gs.actions.buyAnimal(p.id)}
              >
                {owned ? "Owned" : p.affordable ? "Buy" : "Need more"}
              </button>
            </div>
          </div>
        </div>
      );
    })
  )}

  {(gs.derived.planDetailed || []).length > 0 ? (
    <div className="row" style={{ justifyContent:"flex-end", marginTop: 10 }}>
      <button className="btn" onClick={() => gs.actions.clearPlan()}>Clear Plan</button>
    </div>
  ) : null}
</Card>

<div className="hr" />
<Card className="bigCard">
  <div className="sectionHeader" style={{ marginTop: 0 }}>
    <h3 style={{ marginTop: 0 }}><Icon name="palette" /> Cosmetics Shop</h3>
    <div className="muted tiny">Spend zone tickets on borders, nameplates and icons (visual only).</div>
  </div>

  <div className="row" style={{ gap: 10, flexWrap:"wrap", justifyContent:"space-between" }}>
    <div className="badge"><span className="pill pink">Zone Tickets</span> <b>{(gs.derived.zoneTickets || 0).toLocaleString()} 🏷️</b></div>
    <div className="muted tiny">Earn zone tickets by completing zone quests.</div>
  </div>

  <div className="hr" />

  {(gs.derived.cosmeticsCatalog || []).map(item => {
    const owned = !!gs.derived.cosmeticsOwned?.[item.id];
    const cost = item.cost || 0;
    const canBuy = (gs.derived.zoneTickets || 0) >= cost;
    const equipped = gs.derived.cosmeticsEquipped?.[item.slot] === item.id;

    return (
      <div key={item.id} className="tableRow" onClick={() => setPreviewItem(item)} style={{ cursor: "pointer" }}>
        <div className="row" style={{ justifyContent:"space-between", gap: 10 }}>
          <div>
            <div style={{ fontWeight: 900 }}>{item.emoji} {item.name}</div>
            <div className="muted tiny">{item.desc}</div>
            <div className="muted tiny">Cost: {cost} 🏷️ • Slot: {item.slot}</div>
          </div>

          <div className="row" style={{ gap: 8, flexWrap:"wrap", justifyContent:"flex-end" }}>
            {owned ? <span className="pill green">Owned</span> : <span className="pill">Locked</span>}
            {equipped ? <span className="pill blue">Equipped</span> : null}

            {!owned ? (
              <button className={"btn " + (canBuy ? "btnPrimary" : "")} disabled={!canBuy} onClick={() => gs.actions.buyCosmetic(item.id)}>
                Buy
              </button>
            ) : (
              <button className={"btn " + (!equipped ? "btnPrimary" : "")} disabled={equipped} onClick={() => gs.actions.equipCosmetic(item.slot, item.id)}>
                {equipped ? "Equipped" : "Equip"}
              </button>
            )}

            {owned && equipped ? (
              <button className="btn" onClick={() => gs.actions.equipCosmetic(item.slot, null)}>Unequip</button>
            ) : null}
          </div>
        </div>
      </div>
    );
  })}
</Card>

<div className="hr" />




      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Boosters</h3>
        <div className="muted tiny">
          Boosters cost <b>Coins for purchases</b>.
        </div>

        <div className="hr" />

        <div className="list">
          {BOOSTERS.map((b) => {
            const cost = b.cost?.coinsPurchase || 0;
            const needsDep = !!b.requiresDeposit;
            const depOk = !!s.hasDeposited;
            const canBuy = (s.coinsPurchase >= cost) && (!needsDep || depOk);
            const active = activeText(b, now, s.activeBoosters);

            return (
              <div className="listItem" key={b.id} style={{ alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <b>{b.title}</b>
                  <div className="muted tiny">{b.desc}</div>{b.requiresDeposit && !s.hasDeposited ? <div className="pill pink" style={{marginTop:6,display:'inline-block'}}>Deposit required</div> : null}
                  <div className="muted tiny" style={{ marginTop: 6 }}>
                    Cost: <b>{costText(b.cost)}</b>
                    {active ? <span> • <b>{active}</b></span> : null}
                  </div>
                </div>

                <button
                  className={"btn " + (canBuy ? "btnPrimary" : "btnDisabled")}
                  disabled={!canBuy}
                  onClick={() => gs.actions.buyBooster(b.id)}
                  style={{ padding: "10px 12px", width: 110 }}
                >
                  Buy
                </button>
              </div>
            );
          })}
        </div>
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Active</h3>
        <div className="callout">
          <div><b>Free Wheel spins:</b> {s.freeWheelSpins || 0}</div>
          <div className="muted tiny" style={{ marginTop: 6 }}>
            Timed boosters appear above with remaining time.
          </div>
        </div>
      </Card>
    {previewItem ? (
  <div className="modalOverlay" onClick={() => setPreviewItem(null)}>
    <div className="modalCard" onClick={(e) => e.stopPropagation()}>
      <div className="row" style={{ justifyContent:"space-between", gap: 10 }}>
        <div className="row" style={{ gap: 10, alignItems:"center" }}>
          <span className="pill">{previewItem.emoji} Preview</span>
          <div style={{ fontWeight: 900 }}>{previewItem.name}</div>
        </div>
        <button className="btn" onClick={() => setPreviewItem(null)}>Close</button>
      </div>

      <div className="muted tiny" style={{ marginTop: 6 }}>{previewItem.desc}</div>

      <div className={"previewFrame " + ("border_" + previewItem.id)}>
        <div className="previewInner">
          <div className="muted tiny">This is how your cards will feel with the border equipped.</div>
          <div className="cardTitle" style={{ marginTop: 6 }}>TonZoo Profile</div>
          <div className="row" style={{ gap: 10, marginTop: 10, flexWrap:"wrap" }}>
            <span className="pill pink">Zone Tickets</span>
            <span className="pill green">Visitors/day boosted</span>
            <span className="pill">Cosmetic only</span>
          </div>
        </div>
      </div>

      {(() => {
        const owned = !!gs.derived.cosmeticsOwned?.[previewItem.id];
        const equipped = gs.derived.cosmeticsEquipped?.[previewItem.slot] === previewItem.id;
        const cost = previewItem.cost || 0;
        const canBuy = (gs.derived.zoneTickets || 0) >= cost;

        return (
          <div className="row" style={{ justifyContent:"flex-end", gap: 10, marginTop: 12, flexWrap:"wrap" }}>
            {!owned ? (
              <button className={"btn " + (canBuy ? "btnPrimary" : "")} disabled={!canBuy} onClick={() => gs.actions.buyCosmetic(previewItem.id)}>
                Buy ({cost} 🏷️)
              </button>
            ) : (
              <button className={"btn " + (!equipped ? "btnPrimary" : "")} disabled={equipped} onClick={() => gs.actions.equipCosmetic(previewItem.slot, previewItem.id)}>
                {equipped ? "Equipped" : "Equip"}
              </button>
            )}
            {owned && equipped ? (
              <button className="btn" onClick={() => gs.actions.equipCosmetic(previewItem.slot, null)}>Unequip</button>
            ) : null}
          </div>
        );
      })()}
    </div>
  </div>
) : null}
</div>
  );
}

import React, { useMemo, useState } from "react";
import Card from "../components/Card";
import { ANIMALS, EVENT } from "../data/catalog";

function fmt(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}

function seededRand(seed) {
  let x = seed % 2147483647;
  if (x <= 0) x += 2147483646;
  return () => (x = (x * 16807) % 2147483647) / 2147483647;
}

export default function EventsScreen({ gs }) {
  const s = gs.state;
  const now = Date.now();
  const endsAt = s.eventState?.endsAt || EVENT.endsAt;
  const remaining = Math.max(0, endsAt - now);

  const animal = ANIMALS.find((a) => a.id === EVENT.animalId) || ANIMALS.find((a) => a.eventOnly);
  const canBuy = remaining > 0 && s.visitors >= (animal?.priceVisitors || 0);

  const [name, setName] = useState(s.playerName || "");

  const leaderboard = useMemo(() => {
    const seed = (s.eventState?.leaderboardSeed || 1337) + (s.visitors || 0);
    const rnd = seededRand(seed);
    const bots = ["ZOO_KING", "TON_PANDA", "NEON_LION", "CRYPTO_FOX", "WHALE_001", "PENGUINPRO", "REPTILEX", "CROC_MASTER"];
    const base = Math.max(500, Math.floor((s.visitors || 0) * 1.2));
    const list = bots
      .map((b, i) => ({
        name: b,
        score: base + Math.floor(rnd() * 2500) + i * 120,
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 7);

    list.push({ name: (s.playerName || "You").trim() || "You", score: s.visitors || 0 });
    return list.sort((a, b) => b.score - a.score).slice(0, 8);
  }, [s.eventState?.leaderboardSeed, s.visitors, s.playerName]);

  const quests = s.eventQuests?.list || [];
  const track = s.eventTrack?.tiers || [];
  const pts = s.eventPoints || 0;
  const passOwned = !!s.eventState?.passOwned;

  const progressMax = track.length ? track[track.length - 1].need : 1;
  const pct = Math.max(0, Math.min(1, pts / progressMax));

  const inbox = s.inbox || [];

  return (
    <div className="screen">
      <Card className="bigCard">
        <div className="row" style={{ justifyContent: "space-between" }}>
          <div>
            <h3 style={{ margin: 0 }}>{EVENT.title}</h3>
            <div className="muted tiny">Ends in {fmt(remaining)}</div>
          </div>
          <div className="pill pink">Live</div>
        </div>

        <div className="hr" />

        <div className="row twoCol">
          <div>
            <div className="label">Limited Animal</div>
            <div className="pill blue">{animal?.name || "Event Animal"}</div>
          </div>
          <div>
            <div className="label">Cost</div>
            <div className="pill blue">{(animal?.priceVisitors || 0).toLocaleString()} 👥</div>
          </div>
        </div>

        <div className="hr" />

        <button className={"btn " + (canBuy ? "btnDanger" : "btnDisabled")} disabled={!canBuy} onClick={() => gs.actions.buyEventAnimal(animal.id, animal.priceVisitors)}>
          Buy Limited Animal
        </button>

        <div className="hr" />

        <div className="row" style={{ justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
          <div>
            <div style={{ fontWeight: 950 }}>Event Pass</div>
            <div className="muted tiny">+10% tickets (offline too) + unlock pass track</div>
          </div>
          <button className={"btn " + (passOwned ? "btnSuccess" : "btnPrimary")} onClick={() => gs.actions.buyEventPass(EVENT.passPriceUsd)} disabled={passOwned} style={{ minWidth: 140 }}>
            {passOwned ? "Pass Active" : `Buy Pass ($${EVENT.passPriceUsd})`}
          </button>
        </div>
      </Card>

      <Card className="bigCard" style={{ marginTop: 12 }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 1000 }}>Rewards Track</div>
            <div className="muted tiny">{pts} / {progressMax} points</div>
          </div>
          <div className={"pill " + (passOwned ? "pink" : "")}>{passOwned ? "💎 Pass" : "Free"}</div>
        </div>

        <div className="trackBar">
          <div className="trackFill" style={{ width: `${pct * 100}%` }} />
        </div>

        <div className="hr" />

        {track.map((t) => {
          const freeClaimed = !!s.eventTrack?.claimedFree?.[t.t];
          const passClaimed = !!s.eventTrack?.claimedPass?.[t.t];
          const freeCan = pts >= t.need && !freeClaimed;
          const passCan = pts >= t.need && passOwned && !passClaimed;

          return (
            <div key={t.t} className="trackRow">
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 950 }}>
                  Tier {t.t} <span className="muted tiny">({t.need} pts)</span>
                </div>
                <div className="muted tiny">
                  Free: +{t.free.tickets} 🎟️ • Pass: +{t.pass.tickets} 🎟️
                </div>
              </div>

              <div className="row" style={{ gap: 8 }}>
                <button className={"btn " + (freeCan ? "btnSuccess" : "btnDisabled")} disabled={!freeCan} onClick={() => gs.actions.claimTrackTier(t.t, false)}>
                  {freeClaimed ? "Free ✓" : "Free"}
                </button>
                <button className={"btn " + (passCan ? "btnSuccess" : "btnDisabled")} disabled={!passCan} onClick={() => gs.actions.claimTrackTier(t.t, true)}>
                  {passClaimed ? "Pass ✓" : "Pass"}
                </button>
              </div>
            </div>
          );
        })}
      </Card>

      <Card className="bigCard" style={{ marginTop: 12 }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 1000 }}>Event Quests</div>
            <div className="muted tiny">Daily — earn track points</div>
          </div>
          <div className="pill blue">{s.eventQuests?.dailyKey || ""}</div>
        </div>

        <div className="hr" />

        {quests.map((q) => {
          const done = q.progress >= q.goal;
          const canClaim = done && !q.claimed;
          return (
            <div key={q.id} className="listItem">
              <div style={{ flex: 1 }}>
                <b>{q.title}</b>
                <div className="muted tiny">
                  {q.progress}/{q.goal} • +{q.rewardPts} pts
                </div>
              </div>
              <button className={"btn " + (canClaim ? "btnSuccess" : "btnDisabled")} disabled={!canClaim} onClick={() => gs.actions.claimEventQuest(q.id)}>
                {q.claimed ? "Done" : "Claim"}
              </button>
            </div>
          );
        })}
      </Card>

      <Card className="bigCard" style={{ marginTop: 12 }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 1000 }}>Weekly Leaderboard</div>
            <div className="muted tiny">Prizes delivered on weekly reset → Inbox</div>
          </div>
        </div>

        <div className="hr" />

        <div className="row" style={{ gap: 10, flexWrap: "wrap" }}>
          <label className="field" style={{ flex: 1, minWidth: 200 }}>
            <span>Your name</span>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="TonZooPlayer" maxLength={16} />
          </label>
          <button className="btn btnPrimary" onClick={() => gs.actions.setPlayerName(name)}>
            Save
          </button>
        </div>

        <div className="hr" />

        {leaderboard.map((r, idx) => (
          <div key={idx} className="listItem">
            <div className="pill blue" style={{ width: 44, textAlign: "center" }}>
              {idx + 1}
            </div>
            <div style={{ flex: 1, fontWeight: 900 }}>{r.name}</div>
            <div className="pill">{r.score.toLocaleString()} 👥</div>
          </div>
        ))}
      </Card>

      <Card className="bigCard" style={{ marginTop: 12 }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 1000 }}>Inbox</div>
            <div className="muted tiny">Claim weekly prizes here</div>
          </div>
          <div className="pill">{inbox.length}</div>
        </div>

        <div className="hr" />

        {inbox.length === 0 ? (
          <div className="muted">No messages yet.</div>
        ) : (
          inbox.map((m) => (
            <div key={m.id} className="listItem">
              <div style={{ flex: 1 }}>
                <b>{m.title}</b>
                <div className="muted tiny">{m.body}</div>
              </div>
              <button className="btn btnSuccess" onClick={() => gs.actions.claimInbox(m.id)}>
                Claim
              </button>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}

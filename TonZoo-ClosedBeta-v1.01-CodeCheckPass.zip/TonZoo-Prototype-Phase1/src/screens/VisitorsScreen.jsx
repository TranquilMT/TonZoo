import React, { useEffect, useState } from "react";
import BalancePanel from "../components/BalancePanel";
import Card from "../components/Card";
import Icon from "../components/Icon";

export default function VisitorsScreen({ gs }) {
  const v = Math.floor(gs.state.visitors || 0);
  const vpd = gs.derived.visitorsPerDay || 0;
  const vph = gs.derived.visitorsPerHour || 0;

  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick(t => (t+1)%1000000), 30000);
    return () => clearInterval(id);
  }, []);

  const now = Date.now();
  const boostLeft = Math.max(0, (gs.state.marketingBoostUntil || 0) - now);
  const boostMins = Math.floor(boostLeft / 60000);

  return (
    <>
      <BalancePanel gs={gs} onExchange={gs.actions.exchangeTickets} />

      <div className="sectionHeader">
        <h3 style={{ marginTop: 0 }}>Visitors</h3>
        <div className="muted tiny">Visitors are required to withdraw.</div>
      </div>

      <Card className="bigCard">
<div className="kpiGrid">
  <div className="kpi">
    <div className="row" style={{ justifyContent:"space-between" }}>
      <div className="pill blue"><Icon name="bus" /> Visitors</div>
      <div className="pill">{(gs.state.streakCount || 0)} 🔥</div>
    </div>
    <div style={{ fontSize: 24, fontWeight: 900, marginTop: 8 }}>{v.toLocaleString()} 👥</div>
    <div className="muted tiny">Total visitors</div>
  </div>

  <div className="kpi">
    <div className="pill"><Icon name="attraction" /> Rate</div>
    <div style={{ fontSize: 24, fontWeight: 900, marginTop: 8 }}>{Math.floor(vph).toLocaleString()}/hr</div>
    <div className="muted tiny">Current speed</div>
  </div>

  <div className="kpi">
    <div className="pill"><Icon name="marketing" /> Per day</div>
    <div style={{ fontSize: 24, fontWeight: 900, marginTop: 8 }}>{Math.floor(vpd).toLocaleString()}</div>
    <div className="muted tiny">Estimated / day</div>
  </div>

  <div className="kpi">
    <div className={"pill " + (boostLeft > 0 ? "pink" : "")}><Icon name="boost" /> Boost</div>
    <div style={{ fontSize: 24, fontWeight: 900, marginTop: 8 }}>{boostLeft > 0 ? `${boostMins}m` : "OFF"}</div>
    <div className="muted tiny">Marketing boost</div>
  </div>
</div>

        <div className="hr" />

        <div className="sectionHeader" style={{ marginTop: 0 }}>
          <h3 style={{ marginTop: 0 }}>Daily Check-in</h3>
          <div className="muted tiny">Build a streak to earn bigger bonuses.</div>
        </div>

        <button className="btn btnGold" style={{ width: "100%" }} onClick={() => gs.actions.dailyCheckIn()}>
          <Icon name="checkin" /> Claim daily bonus
        </button>

        <div className="muted tiny" style={{ marginTop: 8 }}>
          Tip: check in once per day to keep your streak. Higher streak = more 👥 + 🎟️.
        </div>

        <div className="hr" />

        <div className="sectionHeader" style={{ marginTop: 0 }}>
          <h3 style={{ marginTop: 0 }}>Upgrades</h3>
          <div className="muted tiny">Spend coins & tickets to grow visitors faster.</div>
        </div>

        <div className="row" style={{ gap: 10, flexWrap: "wrap" }}>
          <div className="pill">Marketing L<b>{gs.state.marketingLevel || 0}</b></div>
          <div className="pill">Attractions L<b>{gs.state.attractionLevel || 0}</b></div>
          <div className={"pill " + (boostLeft > 0 ? "pink" : "")}>
            Boost: <b>{boostLeft > 0 ? `${boostMins}m` : "OFF"}</b>
          </div>
        </div>

        <div className="row" style={{ gap: 10, marginTop: 10, flexWrap: "wrap" }}>
          <button className="btn btnPrimary" onClick={() => gs.actions.buyMarketingUpgrade()}>
            <Icon name="marketing" /> Upgrade Marketing • {(gs.derived.marketingCost||0).toLocaleString()} 🟩
          </button>
          <button className="btn btnPrimary" onClick={() => gs.actions.buyAttractionUpgrade()}>
            <Icon name="attraction" /> Upgrade Attractions • {(gs.derived.attractionCost||0).toLocaleString()} 🟩
          </button>
        </div>

        <div className="row" style={{ gap: 10, marginTop: 10, flexWrap: "wrap" }}>
          <button className="btn btnGold" onClick={() => gs.actions.activateMarketingBoost()}>
            <Icon name="boost" /> Activate 2h Boost • {(gs.derived.boostCostTickets||0).toLocaleString()} 🎟️
          </button>
          <div className="muted tiny" style={{ alignSelf: "center" }}>
            Boost increases visitor rate temporarily.
          </div>
        </div>

        <div className="hr" />

        <div className="callout">
          <div><b>Withdraw rule:</b> need ≥ 1,000 visitors and ≥ 1,000 coins ($1).</div>
          <div className="muted tiny">
            Visitors come from animals + upgrades + daily check-ins. Coins are managed by the server.
          </div>
        </div>
      </Card>
    </>
  );
}

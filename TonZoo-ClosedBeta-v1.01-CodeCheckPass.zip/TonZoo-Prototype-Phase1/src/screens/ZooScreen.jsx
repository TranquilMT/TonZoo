import React from "react";
import BalancePanel from "../components/BalancePanel";
import ZooPensPanel from "../components/ZooPensPanel";
import PavilionCarousel from "./parts/PavilionCarousel";

export default function ZooScreen({ gs }) {
  return (
    <>
      <BalancePanel gs={gs} onExchange={gs.actions.exchangeTickets} />
      <ZooPensPanel gs={gs} />

<div className="row" style={{ gap: 10, justifyContent: "space-between", marginBottom: 12 }}>
  <button className="btn" onClick={() => gs.actions.rerollShop()}>
    {`Reroll Shop (${gs.state.shopRerollsToday||0})`}</button>
  <button className="btn btnPrimary" onClick={() => gs.actions.payUpkeep()}>
    Pay Upkeep
  </button>
</div>


      <div className="sectionHeader">
        <h3 style={{ marginTop: 0 }}>My Zoo</h3>
        <div className="muted tiny">Buy pavilions to generate tickets.</div>
      </div>
      <PavilionCarousel gs={gs} />
    </>
  );
}

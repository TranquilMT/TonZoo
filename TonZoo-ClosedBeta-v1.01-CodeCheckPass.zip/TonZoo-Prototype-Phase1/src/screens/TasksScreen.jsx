import React from "react";
import Card from "../components/Card";
import { DAILY_TASKS, ONETIME_TASKS } from "../data/tasks";

function rewardText(r) {
  const parts = [];
  if (r.tickets) parts.push(`+${r.tickets} 🎟️`);
  if (r.visitors) parts.push(`+${r.visitors} 👥`);
  if (r.coinsPurchase) parts.push(`+${r.coinsPurchase} 🟩`);
  return parts.join("  ");
}

export default function TasksScreen({ gs }) {
  return (
    <div className="stack">
      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Daily tasks</h3>
        <div className="muted tiny">
          Daily tasks reset every 24 hours (we'll align to a fixed reset time later).
        </div>

        <div className="list">
          {DAILY_TASKS.map((t) => (
            <TaskRow key={t.id} task={t} scope="daily" gs={gs} />
          ))}
        </div>
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>One-time tasks</h3>
        <div className="muted tiny">Complete once, then permanently claimed.</div>

        <div className="list">
          {ONETIME_TASKS.map((t) => (
            <TaskRow key={t.id} task={t} scope="one" gs={gs} />
          ))}
        </div>
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Task tips</h3>
        <div className="callout">
          <div><b>Wheel / Slots</b> consume visitors.</div>
          <div className="muted tiny" style={{ marginTop: 6 }}>
            Win tickets → exchange (300 🎟️ → +2 🟩 purchase +1 🟩 withdraw) → withdraw when eligible.
          </div>
        </div>
      </Card>
    </div>
  );
}

function TaskRow({ task, scope, gs }) {
  const s = gs.state;
  const isDaily = scope === "daily";

  const claimed = isDaily ? !!s.dailyClaimed?.[task.id] : !!s.oneClaimed?.[task.id];

  let doneVal = 0;
  let target = task.target;
  let complete = false;

  if (task.kind === "counter") {
    const key = task.event;
    doneVal = isDaily ? (s.dailyProgress?.[key] || 0) : (s.oneProgress?.[key] || 0);
    complete = doneVal >= target;
  } else if (task.kind === "accum") {
    doneVal = Math.floor(s.dailyVisitorsGained || 0);
    complete = doneVal >= target;
  } else if (task.kind === "state_check") {
    doneVal = Math.floor(s[task.stateField] || 0);
    complete = doneVal >= target;
  }

  const canClaim = complete && !claimed;

  return (
    <div className="listItem" style={{ alignItems: "flex-start" }}>
      <div style={{ flex: 1 }}>
        <b>{task.title}</b>
        <div className="muted tiny">{task.desc}</div>
        <div className="muted tiny" style={{ marginTop: 6 }}>
          Progress: <b>{Math.min(doneVal, target)}/{target}</b>
          {"  "}• Reward: <b>{rewardText(task.reward)}</b>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
        {claimed ? (
          <div className="pill green">Claimed</div>
        ) : complete ? (
          <div className="pill blue">Done</div>
        ) : (
          <div className="pill">In progress</div>
        )}

        <button
          className={"btn " + (canClaim ? "btnSuccess" : "btnDisabled")}
          disabled={!canClaim}
          onClick={() => gs.actions.claimTask(task.id, scope)}
          style={{ padding: "10px 12px" }}
        >
          Claim
        </button>
      </div>
    </div>
  );
}

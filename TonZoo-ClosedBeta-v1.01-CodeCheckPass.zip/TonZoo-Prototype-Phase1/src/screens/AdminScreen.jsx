import React, { useEffect, useMemo, useState } from "react";
import Card from "../components/Card";

export default function AdminScreen({ gs, onBack }) {
  const [key, setKey] = useState(localStorage.getItem("tonzoo_admin_key") || "dev");
  const [status, setStatus] = useState(null);
  const [tab, setTab] = useState("requested");
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const headers = useMemo(() => ({ "Content-Type":"application/json", "x-admin-key": key }), [key]);

  const fetchStatus = async () => {
    try{
      const res = await fetch(`/api/admin/status`, { headers });
      const j = await res.json();
      if (j?.ok) setStatus(j);
      else setStatus(null);
    }catch{ setStatus(null); }
  };

  const fetchWithdrawals = async () => {
    try{
      setLoading(true);
      const st = tab==="all" ? "all" : (tab==="requested" ? "Requested" : tab==="approved" ? "Approved" : tab==="paid" ? "Paid" : "Denied");
      const res = await fetch(`/api/admin/withdrawals?status=${encodeURIComponent(st)}`, { headers });
      const j = await res.json();
      if (j?.ok) setRows(j.withdrawals || []);
      else setRows([]);
    }catch{ setRows([]); }
    finally{ setLoading(false); }
  };

  useEffect(() => {
    localStorage.setItem("tonzoo_admin_key", key);
    localStorage.setItem("tonzoo_admin", "1");
  }, [key]);

  useEffect(() => {
    fetchStatus();
    fetchWithdrawals();
    const id = setInterval(() => { fetchStatus(); fetchWithdrawals(); }, 15000);
    return () => clearInterval(id);
  }, [tab, headers]);

  const saveConfig = async (patch) => {
    try{
      const res = await fetch(`/api/admin/config`, { method:"POST", headers, body: JSON.stringify(patch) });
      const j = await res.json();
      if (j?.ok) { setMsg("Saved."); fetchStatus(); }
      else setMsg(j?.error || "Failed.");
    }catch{ setMsg("Failed."); }
  };

  const adjustTreasury = async (delta) => {
    try{
      const res = await fetch(`/api/admin/treasury/adjust`, { method:"POST", headers, body: JSON.stringify(delta) });
      const j = await res.json();
      if (j?.ok) { setMsg("Updated treasury."); fetchStatus(); }
      else setMsg(j?.error || "Failed.");
    }catch{ setMsg("Failed."); }
  };

  const approve = async (id) => {
    await fetch(`/api/admin/withdrawals/approve`, { method:"POST", headers, body: JSON.stringify({ id }) });
    fetchWithdrawals(); fetchStatus();
  };

  const setTx = async (id) => {
    const txHash = prompt("TX hash:") || "";
    if (!txHash) return;
    await fetch(`/api/admin/withdrawals/setTx`, { method:"POST", headers, body: JSON.stringify({ id, txHash }) });
    fetchWithdrawals(); fetchStatus();
  };

  const markPaid = async (id) => {
    const txHash = prompt("TX hash (optional):") || "";
    await fetch(`/api/admin/withdrawals/markPaid`, { method:"POST", headers, body: JSON.stringify({ id, txHash, paidBy: "manual" }) });
    fetchWithdrawals(); fetchStatus();
  };

  const deny = async (id) => {
    const reason = prompt("Reason (optional):") || "Denied";
    await fetch(`/api/admin/withdrawals/deny`, { method:"POST", headers, body: JSON.stringify({ id, reason }) });
    fetchWithdrawals(); fetchStatus();
  };

  const processNow = async () => {
    await fetch(`/api/withdrawals/process`, { method:"POST", headers, body: JSON.stringify({}) });
    fetchWithdrawals(); fetchStatus();
  };

  const L = status?.ledger;

  return (
    <div className="screen">
      <div className="row" style={{ justifyContent:"space-between", alignItems:"center", marginBottom: 10 }}>
        <button className="btn" onClick={onBack}>← Back</button>
        <div className="pill">Admin</div>
      </div>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Admin Key</h3>
        <div className="muted tiny">Default is <b>dev</b>. Change your server ADMIN_KEY for production.</div>
        <div className="row" style={{ gap: 10, marginTop: 10 }}>
          <input
            className="input"
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="ADMIN_KEY"
            style={{ flex: 1 }}
          />
          <button className="btn btnPrimary" onClick={() => { fetchStatus(); fetchWithdrawals(); }}>
            Connect
          </button>
        </div>
        {msg ? <div className="muted tiny" style={{ marginTop: 8 }}>{msg}</div> : null}
      </Card>

      <Card className="bigCard" style={{ marginTop: 12 }}>
        <h3 style={{ marginTop: 0 }}>Treasury</h3>
        <div className="row" style={{ gap: 8, flexWrap:"wrap", marginTop: 8 }}>
          <div className="pill green">Treasury: <b>${(L?.treasuryUsd ?? 0).toFixed(2)}</b></div>
          <div className="pill">Profit: <b>${(L?.profitUsd ?? 0).toFixed(2)}</b></div>
          <div className="pill">Buffer: <b>${(L?.bufferUsd ?? 0).toFixed(2)}</b></div>
          <div className={"pill " + (L?.withdrawalsPaused ? "pink" : "")}>Withdrawals: <b>{L?.withdrawalsPaused ? "Paused" : "Live"}</b></div>
        </div>

        <div className="row" style={{ gap: 10, marginTop: 10, flexWrap:"wrap" }}>
          <button className="btn btnPrimary" onClick={() => adjustTreasury({ treasuryDelta: 10 })}>+ $10 Treasury</button>
          <button className="btn" onClick={() => adjustTreasury({ treasuryDelta: -10 })}>- $10 Treasury</button>
          <button className="btn btnGold" onClick={() => saveConfig({ withdrawalsPaused: !L?.withdrawalsPaused })}>
            Toggle Pause
          </button>
        </div>

        <div className="row" style={{ gap: 10, marginTop: 10, flexWrap:"wrap" }}>
          <button className="btn" onClick={() => saveConfig({ withdrawFeePct: Math.min(0.2, (L?.withdrawFeePct ?? 0.03) + 0.01) })}>Fee +1%</button>
          <button className="btn" onClick={() => saveConfig({ withdrawFeePct: Math.max(0, (L?.withdrawFeePct ?? 0.03) - 0.01) })}>Fee -1%</button>
          <button className="btn" onClick={() => saveConfig({ withdrawDailyCapUsd: (L?.withdrawDailyCapUsd ?? 10) + 5 })}>Daily cap +$5</button>
          <button className="btn" onClick={() => saveConfig({ withdrawDailyCapUsd: Math.max(1, (L?.withdrawDailyCapUsd ?? 10) - 5) })}>Daily cap -$5</button>
        </div>
      </Card>

      <Card className="bigCard" style={{ marginTop: 12 }}>
        <h3 style={{ marginTop: 0 }}>Withdrawals</h3>
        <div className="segTabs" style={{ marginTop: 10 }}>
          <button className={"segBtn " + (tab==="requested" ? "active" : "")} onClick={() => setTab("requested")}>Requested</button>
          <button className={"segBtn " + (tab==="approved" ? "active" : "")} onClick={() => setTab("approved")}>Approved</button>
          <button className={"segBtn " + (tab==="paid" ? "active" : "")} onClick={() => setTab("paid")}>Paid</button>
          <button className={"segBtn " + (tab==="denied" ? "active" : "")} onClick={() => setTab("denied")}>Denied</button>
          <button className={"segBtn " + (tab==="all" ? "active" : "")} onClick={() => setTab("all")}>All</button>
        </div>

        <div className="row" style={{ gap: 10, justifyContent:"space-between", marginTop: 10 }}>
          <button className="btn" onClick={fetchWithdrawals}>Refresh</button>
          <button className="btn btnPrimary" onClick={processNow}>Process Approved</button>
        </div>

        {loading ? <div className="muted" style={{ marginTop: 10 }}>Loading…</div> : null}

        <div className="table">
          {rows.map((w) => (
            <div key={w.id} className="tableRow" style={{ alignItems:"flex-start" }}>
              <div style={{ width: 90 }} className="muted tiny">{w.id}</div>
              <div style={{ flex: 1 }}>
                <div><b>{w.userId}</b> • {w.currency} • ${Number(w.netUsd||0).toFixed(2)} <span className="muted tiny">(${Number(w.usd||0).toFixed(2)} - fee ${Number(w.feeUsd||0).toFixed(2)})</span></div>
                <div className="muted tiny">Coins: {w.coins?.toLocaleString?.() || w.coins} • Status: <b>{w.status}</b></div>
                <div className="muted tiny">Address: {w.address || "-"}</div>
                {w.txHash ? <div className="muted tiny">TX: {w.txHash}</div> : null}
                {w.paidAt ? <div className="muted tiny">Paid: {new Date(w.paidAt).toLocaleString()} • {w.paidBy || ""}</div> : null}
                {w.notes ? <div className="muted tiny">Notes: {w.notes}</div> : null}
              </div>
              <div className="row" style={{ gap: 8 }}>
                {(w.status === "Requested" || w.status === "Approved") ? (
                  <>
                    <button className="btn btnPrimary" onClick={() => approve(w.id)}>Approve</button>
                    <button className="btn" onClick={() => setTx(w.id)}>Set TX</button>
                    <button className="btn btnGold" onClick={() => markPaid(w.id)}>Mark Paid</button>
                    <button className="btn" onClick={() => deny(w.id)}>Deny</button>
                  </>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

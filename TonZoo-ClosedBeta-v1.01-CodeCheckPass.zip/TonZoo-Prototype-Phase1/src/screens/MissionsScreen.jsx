import React from "react";
import Card from "../components/Card";

export default function MissionsScreen({ gs }) {
  const daily = gs.state.missions?.daily || [];

  return (
    <div className="screen">
      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Daily Missions</h3>
        <div className="muted tiny">Resets every day (UTC)</div>
        <div className="hr" />

        {daily.length === 0 ? (
          <div className="muted">All missions completed 🎉</div>
        ) : daily.map(m => {
          const done = m.progress >= m.goal;
          return (
            <div key={m.id} className="listItem">
              <div style={{ flex: 1 }}>
                <b>{m.title}</b>
                <div className="muted tiny">{m.progress}/{m.goal}</div>
              </div>
              <button
                className={"btn " + (done ? "btnSuccess" : "btnDisabled")}
                disabled={!done}
                onClick={() => gs.actions.claimMission("daily", m.id)}
              >
                Claim
              </button>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

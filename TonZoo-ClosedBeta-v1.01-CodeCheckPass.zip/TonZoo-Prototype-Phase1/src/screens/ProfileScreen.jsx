import React, { useEffect, useMemo, useState } from "react";
import AchievementsPanel from "../components/AchievementsPanel.jsx";
import AdminPanel from "../components/AdminPanel.jsx";
import DepositModal from "../components/DepositModal.jsx";
import Card from "../components/Card";
import Icon from "../components/Icon";
import { TonConnectButton, useTonConnectUI, useTonWallet } from "@tonconnect/ui-react";
import { TREASURY_ADDRESS } from "../config/app.js";

export default function ProfileScreen({ gs, allowAdmin, onOpenAdmin }) {
  const [tick, setTick] = useState(0);
  useEffect(() => { const id = setInterval(() => setTick(t => (t+1)%1000000), 30000); return () => clearInterval(id); }, []);

  const [adminOpen, setAdminOpen] = useState(false);
  const [depOpen, setDepOpen] = useState(false);
  const [pin, setPin] = useState("");
  const [achOpen, setAchOpen] = useState(false);
  const [withdrawCoins, setWithdrawCoins] = useState(1000);
  const [withdrawAddress, setWithdrawAddress] = useState("");
  const [withdrawCurrency, setWithdrawCurrency] = useState("TON");

  return (
    <div className="screen">
<Card className={"bigCard profileCard " + (gs?.derived?.cosmeticsEquipped?.border ? ("border_" + gs.derived.cosmeticsEquipped.border) : "")} style={{ marginTop: 12 }}>
  <div className="sectionHeader" style={{ marginTop: 0 }}>
    <h3 style={{ marginTop: 0 }}><Icon name="user" /> Profile</h3>
    <div className="muted tiny">Cosmetics preview + quick equip status.</div>
  </div>

  {(() => {
    const name = (gs.state.playerName && gs.state.playerName.trim()) ? gs.state.playerName : "TonZoo Ranger";
    const eq = gs.derived.cosmeticsEquipped || {};
    const cat = gs.derived.cosmeticsCatalog || [];
    const get = (id) => cat.find(x => x.id === id);
    const border = eq.border ? get(eq.border) : null;
    const nameplate = eq.nameplate ? get(eq.nameplate) : null;
    const icon = eq.profileIcon ? get(eq.profileIcon) : null;

    return (
      <div className="row" style={{ gap: 12, alignItems:"center", flexWrap:"wrap" }}>
        <div className="profileIconBig">
          <div className="profileIconEmoji">{icon ? icon.emoji : "🧑‍🚀"}</div>
        </div>
        <div style={{ flex: 1, minWidth: 220 }}>
          <div className="row" style={{ justifyContent:"space-between", gap: 10, flexWrap:"wrap" }}>
            <div>
              <div className={"profileName " + (nameplate ? "nameplateOn" : "")}>
                {name}
                {nameplate ? <span className="pill blue" style={{ marginLeft: 10 }}>{nameplate.emoji} {nameplate.name}</span> : null}
              </div>
              <div className="muted tiny">User ID: {gs.state.userId || "local"} • Zone Tickets: {(gs.derived.zoneTickets || 0).toLocaleString()} 🏷️</div>
                    {gs.derived.cosmeticSets?.anyActive ? <div className="muted tiny" style={{ marginTop: 6 }}>✨ Set Bonus active (visual)</div> : null}
            </div>
            <div className="row" style={{ gap: 8, flexWrap:"wrap", justifyContent:"flex-end" }}>
              {border ? <span className="pill green">Border: {border.emoji}</span> : <span className="pill">Border: none</span>}
              {icon ? <span className="pill green">Icon: {icon.emoji}</span> : <span className="pill">Icon: default</span>}
            </div>
          </div>

          <div className="row" style={{ gap: 10, marginTop: 12, flexWrap:"wrap" }}>
            <button className="btn btnPrimary" onClick={() => gs.nav.go("shop")}>Open Cosmetics Shop</button>
            <button className="btn" onClick={() => gs.nav.go("animals")}>Zoo Map</button>
          </div>
        </div>
      </div>
    );
  })()}
</Card>

      {allowAdmin ? (
  <Card className="bigCard" style={{ marginTop: 12 }}>
    <div className="sectionHeader">
      <h3 style={{ marginTop: 0 }}>Admin</h3>
      <div className="muted tiny">Treasury + withdrawals moderation.</div>
    </div>
    <button className="btn btnPrimary" style={{ width: "100%" }} onClick={() => onOpenAdmin && onOpenAdmin()}>
      Open Admin Panel
    </button>
  </Card>
) : null}
<Card className="bigCard">
        <div className="row" style={{ alignItems: "flex-start" }}>
          <div>
            <h3 style={{ margin: 0 }}>Profile</h3>
            <div className="muted tiny">TonZoo Player • Prototype build</div>
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <TonConnectButton />
          </div>
        </div>

        <div className="hr" />

<div className="sectionHeader" style={{ marginTop: 4 }}>
  <h3 style={{ marginTop: 0 }}>Request Withdrawal</h3>
  <div className="muted tiny">Choose an amount (coins) and a payout currency.</div>
</div>

<div className="muted tiny" style={{ marginTop: 6 }}>
  Your balance: <b>{(gs.state.coinsPurchase || 0).toLocaleString()} 🟩</b> • Visitors: <b>{(gs.state.visitors || 0).toLocaleString()} 👥</b>
</div>

<div className="row" style={{ gap: 10, flexWrap: "wrap", marginTop: 10 }}>
  <button className="btn" onClick={() => setWithdrawCoins(1000)}>1,000</button>
  <button className="btn" onClick={() => setWithdrawCoins(5000)}>5,000</button>
  <button className="btn" onClick={() => setWithdrawCoins(10000)}>10,000</button>
  <button
    className="btn btnPrimary"
    onClick={() => setWithdrawCoins(Math.max(1000, Math.floor((gs.state.coinsPurchase || 0) / 1000) * 1000))}
  >
    Max
  </button>
</div>

<div style={{ marginTop: 10 }}>
  <input
    className="range"
    type="range"
    min={1000}
    step={1000}
    max={Math.max(1000, Math.floor((gs.state.coinsPurchase || 0) / 1000) * 1000)}
    value={Math.min(withdrawCoins, Math.max(1000, Math.floor((gs.state.coinsPurchase || 0) / 1000) * 1000))}
    onChange={(e) => setWithdrawCoins(parseInt(e.target.value || "1000", 10))}
  />
  <div className="row" style={{ justifyContent: "space-between", marginTop: 6 }}>
    <div className="pill">Coins: <b>{withdrawCoins.toLocaleString()}</b></div>
    <div className="pill green">USD: <b>${(withdrawCoins / 1000).toFixed(2)}</b></div>
  </div>
</div>

<div className="row" style={{ gap: 10, marginTop: 10 }}>
  <select className="input" value={withdrawCurrency} onChange={(e) => setWithdrawCurrency(e.target.value)} style={{ width: 130 }}>
    <option value="TON">TON</option>
    <option value="USDT">USDT</option>
  </select>
  <input
    className="input"
    value={withdrawAddress}
    onChange={(e) => setWithdrawAddress(e.target.value)}
    placeholder={withdrawCurrency === "TON" ? "TON address (EQ…)" : "USDT (TON) address (EQ…)"}
    style={{ flex: 1 }}
  />
</div>

{(() => {
  const feePct = gs.state.withdrawFeePct || 0;
  const usd = withdrawCoins / 1000;
  const fee = usd * feePct;
  const net = Math.max(0, usd - fee);
  const can = (gs.state.hasDeposited || gs.state.firstDepositAt) && (gs.state.visitors || 0) >= 1000 && (gs.state.coinsPurchase || 0) >= withdrawCoins && withdrawCoins >= 1000;
  return (
    <div style={{ marginTop: 10 }}>
      <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
        <div className="pill">Fee: <b>${fee.toFixed(2)}</b> ({Math.round(feePct * 100)}%)</div>
        <div className="pill green">You receive: <b>${net.toFixed(2)}</b></div>
      </div>

      <div className="timeline" style={{ marginTop: 10 }}>
        <div className="tStep active">1 • Requested</div>
        <div className="tStep">2 • Approved</div>
        <div className="tStep">3 • Paid</div>
      </div>

      <button
        className="btn btnGold"
        style={{ width: "100%", marginTop: 10 }}
        disabled={!can || !withdrawAddress.trim()}
        onClick={async () => {
          const coins = Math.max(1000, Math.floor(withdrawCoins / 1000) * 1000);
          const r = await gs.actions.requestWithdrawServer(withdrawAddress.trim(), withdrawCurrency, coins);
          if (r?.ok) {
            gs.actions.fetchWithdrawalsServer && gs.actions.fetchWithdrawalsServer();
          }
        }}
      >
        <Icon name="withdraw" /> Request withdrawal
      </button>

      {!withdrawAddress.trim() ? (
        <div className="muted tiny" style={{ marginTop: 8 }}>Enter a wallet address to continue.</div>
      ) : null}

      {((gs.state.visitors || 0) < 1000) ? (
        <div className="muted tiny" style={{ marginTop: 8 }}>Need at least <b>1,000 visitors</b> to withdraw.</div>
      ) : null}

      {(withdrawCoins > (gs.state.coinsPurchase || 0)) ? (
        <div className="muted tiny" style={{ marginTop: 8 }}>Not enough 🟩 purchase coins.</div>
      ) : null}

      {(!(gs.state.hasDeposited || gs.state.firstDepositAt)) ? (
        <div className="muted tiny" style={{ marginTop: 8 }}>You must deposit at least <b>$1</b> before withdrawing.</div>
      ) : null}
    </div>
  );
})()}

<div className="hr" />

        <div className="row">
          <button className={"btn " + (gs.state.soundOn ? "btnPrimary" : "btnDisabled")} onClick={gs.actions.toggleSound} style={{ padding: "10px 12px" }}>
            {gs.state.soundOn ? "🔊 Sound" : "🔇 Muted"}
          </button>
          <button className="btn btnPrimary" onClick={() => setAchOpen(true)} style={{ padding: "10px 12px" }}>
            🏆 Achievements
          </button>
          <button className="btn btnDanger" onClick={() => setAdminOpen(true)} style={{ padding: "10px 12px" }}>
            🛠 Admin
          </button>
          <button className="btn btnPrimary" onClick={() => setDepOpen(true)} style={{ padding: "10px 12px" }}>
            💳 Deposit
          </button>
          <button
          </button>
          <button className="btn btnDisabled"
          </button>
          <div className="pill blue">Deposit status: {gs.state.hasDeposited ? "Confirmed" : "Not yet"}</div>
          <div className="pill">Rare vouchers: {gs.state.rareAnimalVouchers || 0}</div>
        </div>
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>TON Deposit</h3>
        <div className="muted tiny">
          This is <b>frontend scaffolding</b>. For production, you must verify deposits server-side before crediting users.
        </div>

        <div className="hr" />

        <TonDepositBlock gs={gs} />
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Deposit history</h3>
        <div className="muted tiny">Pending → Confirmed (simulate confirm for now).</div>

        <div className="hr" />

        {(!gs.state.deposits || gs.state.deposits.length === 0) ? (
          <div className="muted">No deposits yet.</div>
        ) : (
          <div className="list">
            {gs.state.deposits.slice().reverse().map((d) => (
              <div className="listItem" key={d.id} style={{ alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <b>{d.amountTon} TON</b>
                  <div className="muted tiny">To: {d.treasury}</div>
                  <div className="muted tiny">
                    Status: <b>{d.status}</b>
                    {d.createdAt ? <> • {new Date(d.createdAt).toLocaleString()}</> : null}
                  </div>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
                  <div className={"pill " + (d.status === "Confirmed" ? "green" : "")}>{d.status}</div>
                  {d.status !== "Confirmed" ? (
                    <button
                      className="btn btnSuccess"
                      onClick={() => gs.actions.confirmDeposit(d.id)}
                      style={{ padding: "10px 12px" }}
                    >
                      Simulate confirm
                    </button>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Withdrawal queue</h3>
        <div className="muted tiny">Requests are queued (server) and processed after the delay.</div>
        <div className="muted tiny" style={{marginTop:6}}>
          Withdrawal fee: <b>{Math.round((gs.state.withdrawFeePct||0)*100)}%</b> • Requires deposit $1+ and 24h cooldown after first deposit.
        </div>

        <div className="hr" />

        {(!gs.state.withdrawals || gs.state.withdrawals.length === 0) ? (
          <div className="muted">No withdrawal requests.</div>
        ) : (
          <div className="list">
            {gs.state.withdrawals.slice().reverse().map((w) => (
              <div className="listItem" key={w.id} style={{ alignItems: "flex-start" }}>
                <div style={{ flex: 1 }}>
                  <b>${w.usd} • {w.coins} withdraw coins</b>
                  <div className="muted tiny">Wallet: {w.wallet}</div>
                  <div className="muted tiny">Currency: <b>{w.currency || "TON"}</b> • Net: <b>${(w.netUsd ?? (w.usd*(1-(w.feePct||0.05)))).toFixed ? (w.netUsd ?? (w.usd*(1-(w.feePct||0.05)))).toFixed(2) : (w.netUsd ?? "")} </b></div>
                  {w.processAfter ? <div className="muted tiny">Process after: {new Date(w.processAfter).toLocaleString()}</div> : null}
                  <div className="muted tiny">Status: <b>{w.status}</b></div>
{(() => {
  const st = String(w.status || "Requested");
  const step = st === "Paid" ? 3 : st === "Approved" ? 2 : st === "Denied" ? 0 : 1;
  const now = Date.now();
  const after = w.processAfter ? new Date(w.processAfter).getTime() : null;
  const msLeft = after ? Math.max(0, after - now) : 0;
  const mins = Math.floor(msLeft / 60000);
  const hrs = Math.floor(mins / 60);
  const disp = after ? (msLeft <= 0 ? "Ready" : (hrs > 0 ? `${hrs}h ${mins % 60}m` : `${mins}m`)) : "";
  return (
    <div style={{ marginTop: 10 }}>
      <div className="timeline">
        <div className={"tStep " + (step >= 1 && st !== "Denied" ? "active" : "")}>1 • Requested</div>
        <div className={"tStep " + (step >= 2 ? "active" : "")}>2 • Approved</div>
        <div className={"tStep " + (step >= 3 ? "active" : "")}>3 • Paid</div>
      </div>
      {st !== "Paid" && st !== "Denied" && after ? (
        <div className="muted tiny" style={{ marginTop: 6 }}>
          Processing window: <b>{disp}</b>
        </div>
      ) : null}
      {st === "Denied" ? (
        <div className="muted tiny" style={{ marginTop: 6 }}>
          Denied{w.notes ? `: ${w.notes}` : "."}
        </div>
      ) : null}
    </div>
  );
})()}

                  {w.txHash ? <div className="muted tiny"><Icon name="tx" /> TX: {w.txHash}</div> : null}
                  {w.paidAt ? <div className="muted tiny">Paid: {new Date(w.paidAt).toLocaleString()}</div> : null}
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
                  <div className={"pill " + (w.status === "Paid" ? "green" : w.status === "Denied" ? "pink" : "")}>
                    {w.status}
                  </div>
                  {null}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Help</h3>
        <div className="grid2">
          <button className="btn btnPrimary" disabled>Community chat</button>
          <button className="btn btnPrimary" disabled>News channel</button>
          <button className="btn btnSuccess" disabled>Support</button>
          <button className="btn btnPrimary" disabled>License Agreement</button>
        </div>
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>Dev tools</h3>
        <button className="btn btnDanger" onClick={gs.actions.reset}>Reset save</button>
      </Card>
    </div>
  );
}

function TonDepositBlock({ gs }) {
  const wallet = useTonWallet();
  const [tonConnectUI] = useTonConnectUI();
  const [amount, setAmount] = useState("0.5");
  const [usd, setUsd] = useState("1");
  const [busy, setBusy] = useState(false);
  const connected = !!wallet?.account?.address;

  const TREASURY = TREASURY_ADDRESS;
  const canSend = connected && !busy && Number(amount) > 0;

  const onSend = async () => {
    if (!canSend) return;
    setBusy(true);
    try {
      const nano = BigInt(Math.floor(Number(amount) * 1e9)).toString();

      await tonConnectUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 360,
        messages: [{ address: TREASURY, amount: nano }],
      });

      gs.actions.recordDeposit({ amountTon: Number(amount), usd: Number(usd), treasury: TREASURY });
    } catch (e) {
      console.warn(e);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <div className="grid2" style={{ gap: 10 }}>
        <label className="field">
          <span>Amount (TON)</span>
          <input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" placeholder="0.5" />
        </label>
        <label className="field">
          <span>Amount (USD)</span>
          <input value={usd} onChange={(e) => setUsd(e.target.value)} inputMode="decimal" placeholder="1" />
        </label>
      </div>

      <button
        className={"btn " + (canSend ? "btnPrimary" : "btnDisabled")}
        disabled={!canSend}
        onClick={onSend}
        style={{ width: "100%", marginTop: 10 }}
      >
        {busy ? "Sending..." : connected ? "Send TON Deposit" : "Connect wallet to deposit"}
      </button>

      <div className="muted tiny" style={{ marginTop: 8 }}>
        Tip: for now you can also use the <b>Top up</b> modal (simulated) to test economy quickly.
      </div>
    <Card className="bigCard" style={{ marginTop: 12 }}>
  <div className="sectionHeader">
    <h3 style={{ marginTop: 0 }}><Icon name="profile" /> Invite Friends</h3>
    <div className="muted tiny">Earn rewards when your friends make their first deposit.</div>
  </div>

  <div className="row" style={{ gap: 10, flexWrap: "wrap", marginTop: 10 }}>
    <div className="pill">Your code: <b>{gs.state.userId}</b></div>
    <div className="pill">Invited: <b>{gs.state.referralInvitedCount || 0}</b></div>
    <div className="pill green">Pending: <b>{gs.state.referralPendingCoins || 0}</b> 🟩</div>
  </div>

  <div className="muted tiny" style={{ marginTop: 10 }}>
    Share link (Telegram): <b>{`ref_${gs.state.userId}`}</b>
  </div>

  <div className="row" style={{ gap: 10, justifyContent: "space-between", marginTop: 10 }}>
    <button
      className="btn btnPrimary"
      onClick={async () => {
        const code = `ref_${gs.state.userId}`;
        try{
          await navigator.clipboard.writeText(code);
          gs.actions.toast && gs.actions.toast("Copied!");
        }catch{
          // fallback
          const ta = document.createElement("textarea");
          ta.value = code; document.body.appendChild(ta);
          ta.select(); document.execCommand("copy");
          document.body.removeChild(ta);
        }
      }}
    >
      Copy Code
    </button>

    <button
      className="btn"
      onClick={() => {
        try{
          const tg = window?.Telegram?.WebApp;
          const shareText = encodeURIComponent(`Join TonZoo! Use my code: ref_${gs.state.userId}`);
          const url = `https://t.me/share/url?text=${shareText}`;
          if (tg?.openTelegramLink) tg.openTelegramLink(url);
          else window.open(url, "_blank");
        }catch{}
      }}
    >
      Share
    </button>

    <button
      className="btn btnGold"
      disabled={(gs.state.referralPendingCoins || 0) <= 0}
      onClick={async () => {
        await gs.actions.claimReferralRewards();
      }}
    >
      Claim
    </button>
  </div>
</Card>
<Card className="bigCard" style={{ marginTop: 12 }}>
  <div className="sectionHeader">
    <h3 style={{ marginTop: 0 }}>Global Leaderboards</h3>
    <div className="muted tiny">Leaderboard (Phase 26). Later we can connect this to server.</div>
  </div>

  <div className="segTabs" style={{ marginTop: 10 }}>
    <button className={"segBtn " + (lbTab === "visitors" ? "active" : "")} onClick={() => setLbTab("visitors")}>
      Visitors
    </button>
    <button className={"segBtn " + (lbTab === "prestige" ? "active" : "")} onClick={() => setLbTab("prestige")}>
      Prestige
    </button>
  </div>

  <div className="table">
    {lbLoading ? <div className="muted">Loading…</div> : null}
          {leaderboard.map((row, i) => (
      <div key={row.name} className="tableRow">
        <div className="muted tiny" style={{ width: 26 }}>{i + 1}</div>
        <div style={{ flex: 1 }}><b>{row.name}</b></div>
        <div className="pill">{row.value.toLocaleString()}</div>
      </div>
    ))}
  </div>
</Card>
</div>
  );
}
const [lbTab, setLbTab] = useState("visitors");
const [lbLoading, setLbLoading] = useState(false);
const [lbRows, setLbRows] = useState(null);

useEffect(() => {
  let alive = true;
  (async () => {
    try{
      setLbLoading(true);
      const res = await fetch(`/api/leaderboard/top?metric=${lbTab}`);
      const j = await res.json();
      if (!alive) return;
      if (j?.ok) setLbRows(j.leaderboard || []);
      else setLbRows(null);
    }catch{
      if (alive) setLbRows(null);
    }finally{
      if (alive) setLbLoading(false);
    }
  })();
  return () => { alive = false; };
}, [lbTab]);


const leaderboard = useMemo(() => {
  // local demo; seeded so it feels stable-ish per user
  const seed = (s.userId || "local").split("").reduce((a,c)=>a+c.charCodeAt(0), 0) + (s.visitors||0) + (gs.derived.prestige||0);
  let x = seed % 2147483647; if (x<=0) x += 2147483646;
  const rnd = () => (x = (x * 16807) % 2147483647) / 2147483647;

  const bots = ["ZOO_KING","TON_PANDA","NEON_LION","CRYPTO_FOX","WHALE_001","PENGUINPRO","REPTILEX","CROC_MASTER"];
  const youName = (s.playerName || "You").trim() || "You";
  const yourVisitors = s.visitors || 0;
  const yourPrestige = gs.derived.prestige || 0;

  const list = bots.map((b,i) => {
    const baseV = Math.max(500, Math.floor(yourVisitors * 1.1));
    const baseP = Math.max(150, Math.floor(yourPrestige * 1.15));
    return {
      name: b,
      visitors: baseV + Math.floor(rnd()*4000) + i*120,
      prestige: baseP + Math.floor(rnd()*2500) + i*60,
    };
  });

  list.push({ name: youName, visitors: yourVisitors, prestige: yourPrestige });

  const sorted = list.sort((a,b)=> (lbTab==="visitors"? b.visitors-a.visitors : b.prestige-a.prestige)).slice(0, 10);
  return sorted.map(r => ({ name: r.name, value: lbTab==="visitors"? r.visitors : r.prestige }));
}, [lbTab, s.userId, s.playerName, s.visitors, gs.derived.prestige]);


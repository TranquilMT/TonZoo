import React, { useMemo, useState } from "react";
import Card from "../components/Card";

function fmtMs(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, "0")}`;
}

export default function AuctionScreen({ gs }) {
  const s = gs.state;
  const a = s.auction;

  const [bid, setBid] = useState("");

  const now = Date.now();
  const timeLeft = a ? (a.endsAt - now) : 0;

  const youAreWinning = a?.highestBidder === "you";
  const yourBid = a?.yourBid || 0;

  const minNextBid = useMemo(() => {
    const inc = a?.minIncrement || 25;
    return Math.max(0, (a?.highestBid || 0) + inc);
  }, [a]);

  const canBid = !!a && timeLeft > 0;

  const bidNum = Math.max(0, Math.floor(Number(bid) || 0));

  const blockedReason = !canBid
    ? "Auction ended. Next one will start soon."
    : bidNum < minNextBid
      ? `Minimum bid is ${minNextBid} visitors.`
      : s.visitors < (bidNum - yourBid)
        ? "Not enough visitors."
        : null;

  return (
    <div className="stack">
      <Card className="bigCard">
        <div className="row">
          <div>
            <h3 style={{ margin: 0 }}>Auction</h3>
            <div className="muted tiny">Bid with visitors. Highest bid wins.</div>
          </div>
          <div className={"pill " + (timeLeft > 0 ? "pink" : "")}>
            {timeLeft > 0 ? `Ends in ${fmtMs(timeLeft)}` : "Ended"}
          </div>
        </div>

        <div className="hr" />

        {!a ? (
          <div className="muted">Loading auction…</div>
        ) : (
          <>
            <div className="callout">
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                <div>
                  <div className="muted tiny">Item</div>
                  <div style={{ fontWeight: 1000, fontSize: 16 }}>
                    {a.itemBadge} {a.itemTitle}
                  </div>
                  <div className="muted tiny" style={{ marginTop: 2 }}>{a.itemDesc}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div className="muted tiny">Current bid</div>
                  <div style={{ fontWeight: 1000, fontSize: 18 }}>{a.highestBid.toLocaleString()} 👥</div>
                  <div className="muted tiny">
                    Leader: <b>{youAreWinning ? "YOU" : "Player"}</b>
                  </div>
                </div>
              </div>
            </div>

            <div className="row" style={{ marginTop: 12 }}>
              <div className="pill blue">Your bid: {yourBid.toLocaleString()} 👥</div>
              <div className={"pill " + (youAreWinning ? "green" : "")}>
                {youAreWinning ? "Winning" : "Outbid"}
              </div>
            </div>

            <div className="hr" />

            <div className="grid2">
              {[minNextBid, minNextBid + 100, minNextBid + 500, minNextBid + 1000].map((v) => (
                <button
                  key={v}
                  className="btn btnPrimary"
                  disabled={!canBid || s.visitors < (v - yourBid)}
                  onClick={() => setBid(String(v))}
                >
                  Bid {v.toLocaleString()}
                </button>
              ))}
            </div>

            <div style={{ marginTop: 12 }}>
              <label className="field">
                <span>Custom bid (visitors)</span>
                <input
                  value={bid}
                  onChange={(e) => setBid(e.target.value)}
                  inputMode="numeric"
                  placeholder={`Min ${String(minNextBid)}`}
                />
              </label>

              <button
                className={"btn " + (!blockedReason ? "btnSuccess" : "btnDisabled")}
                disabled={!!blockedReason}
                onClick={() => {
                  gs.actions.placeAuctionBid(bidNum);
                  setBid("");
                }}
                style={{ marginTop: 10, width: "100%" }}
              >
                Place bid
              </button>

              {blockedReason && <div className="muted tiny" style={{ marginTop: 8 }}>⚠ {blockedReason}</div>}
              <div className="muted tiny" style={{ marginTop: 8 }}>
                Note: In this prototype, other bidders are simulated. Losing bids refund 80% at the end.
              </div>
            </div>
          </>
        )}
      </Card>

      <Card className="bigCard">
        <h3 style={{ marginTop: 0 }}>History</h3>
        {(!s.auctionHistory || s.auctionHistory.length === 0) ? (
          <div className="muted">No auctions completed yet.</div>
        ) : (
          <div className="list">
            {s.auctionHistory.slice().reverse().slice(0, 8).map((h) => (
              <div className="listItem" key={h.id}>
                <div>
                  <b>{h.itemBadge} {h.itemTitle}</b>
                  <div className="muted tiny">
                    {h.winner === "you" ? "You won" : "You lost"} • Final bid: {h.finalBid.toLocaleString()} 👥
                  </div>
                </div>
                <div className="pill">{new Date(h.endedAt).toLocaleString()}</div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

import React from "react";
import { TonConnectUIProvider } from "@tonconnect/ui-react";

/**
 * NOTE:
 * - For production, update public/tonconnect-manifest.json fields (url, iconUrl).
 * - The manifestUrl MUST be accessible over HTTPS when running inside Telegram.
 */
export default function TonConnectProvider({ children }) {
  const manifestUrl = `${window.location.origin}/tonconnect-manifest.json`;

  return (
    <TonConnectUIProvider manifestUrl={manifestUrl}>
      {children}
    </TonConnectUIProvider>
  );
}

export const RARITY_TIER = {
  Normal: "common",
  Special: "rare",
  Exclusive: "legendary",
};

export const RARITY_MULT = {
  common: 1.0,
  rare: 1.5,
  epic: 2.5,
  legendary: 4.0,
};

export const RARITY_LABEL = {
  common: "Common",
  rare: "Rare",
  epic: "Epic",
  legendary: "Legendary",
};

export const RARITY_PRESTIGE = { common: 10, rare: 25, epic: 60, legendary: 140 };

export const PRESTIGE_RANKS = [
  { id: "Rookie", min: 0 },
  { id: "Keeper", min: 250 },
  { id: "Ranger", min: 750 },
  { id: "Director", min: 2000 },
  { id: "Tycoon", min: 5000 },
  { id: "Legend", min: 12000 },
];

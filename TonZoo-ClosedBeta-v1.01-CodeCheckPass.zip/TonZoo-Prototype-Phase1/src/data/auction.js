/**
 * Auction items rotate in single-player prototype.
 * Bids are made with VISITORS.
 * Rewards never mint withdraw-coins directly.
 */
export const AUCTION_DURATION_MS = 5 * 60 * 1000; // 5 minutes

export const AUCTION_ITEMS = [
  {
    id: "ticket_crate_small",
    title: "Ticket Crate",
    desc: "A crate full of tickets.",
    reward: { tickets: 12000 },
    badge: "🎟️",
  },
  {
    id: "ticket_crate_big",
    title: "Mega Ticket Crate",
    desc: "A massive crate full of tickets.",
    reward: { tickets: 35000 },
    badge: "🎟️",
  },
  {
    id: "rare_animal_voucher",
    title: "Rare Animal Voucher",
    desc: "Redeem for a rare animal (Special tier).",
    reward: { rareAnimalVoucher: 1 },
    badge: "🦁",
  },
];

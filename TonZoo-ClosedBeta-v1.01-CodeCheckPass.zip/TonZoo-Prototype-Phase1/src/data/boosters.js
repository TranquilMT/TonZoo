/**
 * Boosters are purchased with Coins for purchases.
 * Effects are applied in accrual (tickets/visitors multipliers).
 */
export const BOOSTERS = [
  {
    id: "tickets_x2_1h",
    title: "2× Tickets (1 hour)",
    desc: "Doubles ticket production for 1 hour.",
    durationMs: 60 * 60 * 1000,
    effect: { ticketsMult: 2 },
    cost: { coinsPurchase: 500 },
  },
  {
    id: "visitors_x2_24h",
    title: "2× Visitors (24 hours)",
    desc: "Doubles visitor attraction for 24 hours.",
    durationMs: 24 * 60 * 60 * 1000,
    effect: { visitorsMult: 2 },
    cost: { coinsPurchase: 1000 },
  },
  {
    id: "wheel_free_spin",
    title: "Wheel Free Spin",
    desc: "Adds 1 free Wheel spin (no visitor cost).",
    durationMs: 0,
    effect: { freeWheelSpins: 1 },
    cost: { coinsPurchase: 300 },
  },
{
    id: "premium_offline_cap_24h",
    title: "Premium: +50% Offline Cap (24h)",
    desc: "Store more offline progress for 24 hours. Requires at least $1 deposit.",
    durationMs: 24 * 60 * 60 * 1000,
    effect: { offlineCapMult: 1.5 },
    requiresDeposit: true,
    cost: { coinsPurchase: 1200 },
  },
  {
    id: "premium_visitors_x2_72h",
    title: "Premium: 2× Visitors (72h)",
    desc: "Doubles visitor attraction for 72 hours. Requires at least $1 deposit.",
    durationMs: 72 * 60 * 60 * 1000,
    effect: { visitorsMult: 2 },
    requiresDeposit: true,
    cost: { coinsPurchase: 2500 },
  },
];


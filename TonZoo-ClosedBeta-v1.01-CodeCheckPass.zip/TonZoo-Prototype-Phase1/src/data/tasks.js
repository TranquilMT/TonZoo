/**
 * Tasks are intentionally simple for Phase 2:
 * - Daily tasks reset every 24h from the first run (we'll refine to fixed daily reset later).
 * - One-time tasks never reset.
 *
 * Rewards are in: tickets, visitors, coinsPurchase
 */
export const DAILY_TASKS = [
  {
    id: "daily_spin_wheel",
    title: "Spin the Wheel",
    desc: "Spin Wheel of Fortune 1 time.",
    kind: "counter",
    target: 1,
    event: "wheel_spin",
    reward: { visitors: 300 },
  },
  {
    id: "daily_spin_slots",
    title: "Spin the Slots",
    desc: "Spin Slot Machine 1 time.",
    kind: "counter",
    target: 1,
    event: "slots_spin",
    reward: { tickets: 500 },
  },
  {
    id: "daily_exchange",
    title: "Exchange Tickets",
    desc: "Exchange tickets 1 time.",
    kind: "counter",
    target: 1,
    event: "exchange",
    reward: { tickets: 300 },
  },
  {
    id: "daily_gain_visitors",
    title: "Gain Visitors",
    desc: "Gain 500 visitors today.",
    kind: "accum",
    target: 500,
    event: "visitors_gained",
    reward: { tickets: 800 },
  },
];

export const ONETIME_TASKS = [
  {
    id: "one_buy_pavilion",
    title: "Build your first Pavilion",
    desc: "Buy any pavilion.",
    kind: "counter",
    target: 1,
    event: "pavilion_bought",
    reward: { tickets: 1500 },
  },
  {
    id: "one_buy_animal",
    title: "Get your first Animal",
    desc: "Buy any animal.",
    kind: "counter",
    target: 1,
    event: "animal_bought",
    reward: { visitors: 600 },
  },
  {
    id: "one_reach_1000_visitors",
    title: "A Crowd is Forming!",
    desc: "Reach 1,000 total visitors.",
    kind: "state_check",
    target: 1000,
    stateField: "visitors",
    reward: { coinsPurchase: 200 },
  },
];

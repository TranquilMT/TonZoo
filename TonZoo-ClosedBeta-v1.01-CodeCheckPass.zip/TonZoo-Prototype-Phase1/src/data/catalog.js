export const PAVILIONS = [
  { id: "mini_farm", name: "Mini Farm", theme: "farm", priceCoins: 17000, ticketsPerHour: 3650 },
  { id: "forest_pavilion", name: "Forest Pavilion", theme: "forest", priceCoins: 45000, ticketsPerHour: 10500 },
  { id: "tropical_aviary", name: "Tropical Aviary", theme: "tropical", priceCoins: 115000, ticketsPerHour: 31000 },
  { id: "arctic_aviary", name: "Arctic Aviary", theme: "arctic", priceCoins: 300000, ticketsPerHour: 89000 },
  { id: "reptile_house", name: "Reptile House", theme: "reptile", priceCoins: 160000, ticketsPerHour: 42000 },
  { id: "croc_swamp", name: "Crocodile Swamp", theme: "croc", priceCoins: 220000, ticketsPerHour: 56000 },
  { id: "savanna_pavilion", name: "Savanna Pavilion", theme: "savanna", priceCoins: 775000, ticketsPerHour: 260000 },
  { id: "big_cats_arena", name: "Big Cats Arena", theme: "cats", priceCoins: 450000, ticketsPerHour: 120000 },

  ,{
    id: "event_neon_fox",
    name: "Neon Fox",
    rarity: "Exclusive",
    visitorsPerDay: 38,
    workDays: 7,
    priceVisitors: 950,
    eventOnly: true
  }

{
  id: "tiger",
  name: "Tiger",
  rarity: "Special",
  visitorsPerDay: 240,
  priceVisitors: 1400,
  workDays: 9,
  icon: "/animal-icons/tiger.svg",
  depositOnly: false
},


{
  id: "zebra",
  name: "Zebra",
  rarity: "Normal",
  visitorsPerDay: 160,
  priceVisitors: 1000,
  workDays: 8,
  icon: "/animal-icons/zebra.svg",
  depositOnly: false
},


{
  id: "giraffe",
  name: "Giraffe",
  rarity: "Normal",
  visitorsPerDay: 180,
  priceVisitors: 1100,
  workDays: 8,
  icon: "/animal-icons/giraffe.svg",
  depositOnly: false
},


{
  id: "seal",
  name: "Seal",
  rarity: "Normal",
  visitorsPerDay: 170,
  priceVisitors: 1050,
  workDays: 8,
  icon: "/animal-icons/seal.svg",
  depositOnly: false
},


{
  id: "polar_bear",
  name: "Polar Bear",
  rarity: "Special",
  visitorsPerDay: 260,
  priceVisitors: 1600,
  workDays: 10,
  icon: "/animal-icons/polarbear.svg",
  depositOnly: false
},


{
  id: "owl",
  name: "Owl",
  rarity: "Normal",
  visitorsPerDay: 150,
  priceVisitors: 900,
  workDays: 7,
  icon: "/animal-icons/owl.svg",
  depositOnly: false
},


{
  id: "reptile",
  name: "Reptile",
  rarity: "Normal",
  visitorsPerDay: 140,
  priceVisitors: 850,
  workDays: 7,
  icon: "/animal-icons/reptile.svg",
  depositOnly: false
},

];


export const ANIMALS = [
  { icon: "/animal-icons/penguin.svg",
  id: "penguin", name: "Penguin", rarityTier: "common",
  rarity: "Normal", maxLevel: 20,
  workDays: 60, visitorsPerDay: 6, priceVisitors: 180 },
  { icon: "/animal-icons/gecko.svg",
  id: "gecko", name: "Gecko", rarityTier: "common",
  rarity: "Normal", maxLevel: 20,
  workDays: 60, visitorsPerDay: 8, priceVisitors: 250 },
  { icon: "/animal-icons/turtle.svg",
  id: "turtle", name: "Turtle", rarityTier: "rare",
  rarity: "Special", maxLevel: 20,
  workDays: 60, visitorsPerDay: 1, priceVisitors: 55 },
  { icon: "/animal-icons/snake.svg",
  id: "snake", name: "Snake", rarityTier: "rare",
  rarity: "Special", maxLevel: 20,
  workDays: 60, visitorsPerDay: 2, priceVisitors: 105 },
  { icon: "/animal-icons/crocodile.svg",
  id: "crocodile", name: "Crocodile", rarityTier: "rare",
  rarity: "Special", maxLevel: 20,
  workDays: 60, visitorsPerDay: 10, priceVisitors: 380 },
  { icon: "/animal-icons/lion.svg",
  id: "lion", name: "Lion", rarityTier: "rare",
  rarity: "Special", maxLevel: 20,
  workDays: 60, visitorsPerDay: 12, priceVisitors: 450 },

  // Deposit-only bonus animal (unlocked after deposit)
  { icon: "/animal-icons/ton_panther.svg",
  id: "ton_panther", name: "TON Panther", rarityTier: "legendary",
  rarity: "Exclusive", maxLevel: 20,
  workDays: 120, visitorsPerDay: 50, priceVisitors: null, depositOnly: true },
];


export const EVENT = {
  id: "neon_week",
  title: "Neon Week",
  endsAt: Date.now() + 1000*60*60*24*3,
  animalId: "event_neon_fox",
  passPriceUsd: 3,
};

/**
 * App configuration (Phase 5)
 * Replace these before production.
 */
export const BOT_USERNAME = "YOUR_BOT"; // e.g. "TonZooBot"
export const MINIAPP_SHORTNAME = ""; // optional, if you use @BotFather Web App short name
export const TREASURY_ADDRESS = import.meta.env.VITE_TREASURY_ADDRESS || ""; // set in .env as VITE_TREASURY_ADDRESS


export function assertTreasuryConfigured(){
  return Boolean(TREASURY_ADDRESS && TREASURY_ADDRESS.length > 10);
}

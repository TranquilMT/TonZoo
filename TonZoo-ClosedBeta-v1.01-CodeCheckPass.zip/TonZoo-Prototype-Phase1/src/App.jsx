import React, { useEffect, useMemo, useState } from "react";
import { useGameState } from "./state/gameState";
import { getStartParam } from "./telegram/webapp.js";
import { tgReady, tgTheme } from "./telegram/theme.js";
import TopBar from "./components/TopBar";
import BottomNav from "./components/BottomNav";
import Modal from "./components/Modal";
import FriendsScreen from "./screens/FriendsScreen";
import MissionsScreen from "./screens/MissionsScreen";
import EventsScreen from "./screens/EventsScreen";
import GamesScreen from "./screens/GamesScreen";
import RewardFX from "./components/RewardFX.jsx";
import IntroStory from "./components/IntroStory.jsx";
import ProfileScreen from "./screens/ProfileScreen";
import AdminScreen from "./screens/AdminScreen";
import ZooShell from "./screens/ZooShell";
import { formatMoneyUSD } from "./lib/format";

export default function App() {
  const gs = useGameState();
  const sp = getStartParam();
  const allowAdmin = (sp === "admin") || (sp && String(sp).startsWith("admin_")) || (localStorage.getItem("tonzoo_admin") === "1");
useEffect(() => {
  const tg = tgReady();
  const apply = () => {
    const { params } = tgTheme();
    const root = document.documentElement;
    if (params?.bg_color) root.style.setProperty("--tg-bg", params.bg_color);
    if (params?.text_color) root.style.setProperty("--tg-text", params.text_color);
    if (params?.hint_color) root.style.setProperty("--tg-hint", params.hint_color);
    if (params?.button_color) root.style.setProperty("--tg-btn", params.button_color);
    if (params?.button_text_color) root.style.setProperty("--tg-btnText", params.button_text_color);
    if (params?.secondary_bg_color) root.style.setProperty("--tg-bg2", params.secondary_bg_color);
  };
  apply();
  try { tg?.onEvent?.("themeChanged", apply); } catch {}
  return () => { try { tg?.offEvent?.("themeChanged", apply); } catch {} };
}, []);


  useEffect(() => {
    gs.actions.appBoot();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const onClick = (e) => {
      if (!gs.state.soundOn) return;
      const el = e.target;
      const btn = el?.closest?.("button");
      if (!btn) return;
      // haptic
      try { navigator.vibrate?.(10); } catch {}
      playClick();
    };
    document.addEventListener("click", onClick, true);
    return () => document.removeEventListener("click", onClick, true);
  }, [gs.state.soundOn]);


  React.useEffect(() => {
    const sp = getStartParam();
    if (sp && sp.startsWith("ref_") && gs.actions?.setReferrer) {
      gs.actions.setReferrer(sp);
    }
  }, [gs.actions]);
  const [tab, setTab] = useState("zoo");

  const [showTopUp, setShowTopUp] = useState(false);
  const [showWithdraw, setShowWithdraw] = useState(false);

  const screen = useMemo(() => {
    switch (tab) {
      case "friends":
        return <FriendsScreen gs={gs} />;
      case "games":
        return <GamesScreen gs={gs} />;
      case "events":
        return <EventsScreen gs={gs} />;
      case "profile":
        return <ProfileScreen gs={gs} />;
      case "zoo":
      default:
        return <ZooShell gs={gs} initialSub="animals" />;
    }
  }, [tab, gs]);

  return (
    <div className={"app$1 " + (gs?.derived?.cosmeticsEquipped?.border ? ("border_" + gs.derived.cosmeticsEquipped.border) : "")}>
      <TopBar
        title="TonZoo"
        onTopUp={() => setShowTopUp(true)}
        onWithdraw={() => setShowWithdraw(true)}
      />

      <div className="content">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            className="screenMotion"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.18 }}
          >
            {screen}
          </motion.div>
        </AnimatePresence>
      </div>

      <BottomNav active={tab} onChange={setTab} />

      <Modal open={showTopUp} title="Top up" onClose={() => setShowTopUp(false)}>
        <div className="callout">
          <div><b>Rate:</b> $1 = 1000 coins</div>
          <div className="muted tiny">
            Top up adds <b>Coins for purchases</b> only. Withdraw coins are earned via ticket exchange.
          </div>
        </div>

        <div className="grid2" style={{ marginTop: 12 }}>
          {[1, 5, 10, 30, 100].map((usd) => (
            <button
              key={usd}
              className="btn btnPrimary"
              onClick={() => {
                gs.actions.simTopUp(usd);
                setShowTopUp(false);
              }}
            >
              Top up {formatMoneyUSD(usd)}
            </button>
          ))}
        </div>

<div className="hr" style={{ marginTop: 14 }} />

<div className="callout">
  <div><b>Simulated TON deposit</b></div>
  <div className="muted tiny">
    Unlocks the deposit-only bonus animal (prototype). No real crypto is used yet.
  </div>
  <button
    className={"btn " + (gs.state.hasDeposited ? "btnDisabled" : "btnPrimary")}
    disabled={gs.state.hasDeposited}
    onClick={() => {
      gs.actions.simulateDeposit();
    }}
    style={{ marginTop: 10, width: "100%" }}
  >
    {gs.state.hasDeposited ? "Deposit confirmed" : "Simulate TON Deposit"}
  </button>
</div>

        <div className="callout" style={{ marginTop: 12 }}>
          <div><b>Bonus:</b> $1 → +300 visitors</div>
          <div className="muted tiny">Exclusive bonus animal unlocks after deposit (Phase 3).</div>
        </div>
      </Modal>

      <Modal open={showWithdraw} title="Withdraw" onClose={() => setShowWithdraw(false)}>
        <p className="muted">
          Phase 1 creates a withdrawal request (Pending). No real payout yet.
        </p>

        <WithdrawForm gs={gs} />

        <div className="hr" />

        <h4 style={{ margin: "8px 0" }}>Withdrawal history</h4>
        {gs.state.withdrawals.length === 0 ? (
          <p className="muted">No withdrawals yet.</p>
        ) : (
          <div className="list">
            {gs.state.withdrawals.slice().reverse().map((w) => (
              <div className="listItem" key={w.id}>
                <div>
                  <b>{formatMoneyUSD(w.usd)}</b> — {w.status}
                  <div className="muted tiny">{new Date(w.createdAt).toLocaleString()}</div>
                </div>
                <div className="pill">{w.wallet.slice(0, 6)}…{w.wallet.slice(-4)}</div>
              </div>
            ))}
          </div>
        )}
      </Modal>
      {!gs.state.tutorialSeen ? <IntroStory gs={gs} /> : null}
      <RewardFX gs={gs} />
    </div>
  );
}

function WithdrawForm({ gs }) {
  const [wallet, setWallet] = useState("");
  const [coins, setCoins] = useState("1000");
  const [withdrawCurrency, setWithdrawCurrency] = useState("TON");

  const minCoins = 1000;
  const coinsNum = Math.max(0, Math.floor(Number(coins) || 0));
  const usd = coinsNum / 1000;

  const canVisitors = gs.state.visitors >= 1000;
  const canCoins = gs.state.coinsWithdraw >= coinsNum && coinsNum >= minCoins;

  const blockedReason = !canVisitors
    ? "Need at least 1000 visitors."
    : !canCoins
      ? `Need at least ${minCoins} withdraw coins and enough balance.`
      : wallet.trim().length < 10
        ? "Enter a wallet address (any text for prototype)."
        : null;

  return (
    <div className="stack">
      <div className="callout">
        <div><b>Available:</b> {Math.floor(gs.state.coinsWithdraw).toLocaleString()} withdraw coins</div>
        <div className="muted tiny">
          Minimum: 1000 coins (= $1) and ≥ 1000 visitors.
        </div>
      </div>

      <label className="field">
        <span>Amount in coins</span>
        <input
          value={coins}
          onChange={(e) => setCoins(e.target.value)}
          inputMode="numeric"
          placeholder="e.g. 1000 (min $1 to withdraw)"
        />
      </label>

      <div className="callout">
        <div><b>Amount in USD:</b> {formatMoneyUSD(usd)}</div>
      </div>

      <label className="field">
        <span>Wallet address</span>
        <input
          value={wallet}
          onChange={(e) => setWallet(e.target.value)}
          placeholder="Paste your TON address (EQ…)"
        />
      </label>

      <button
        className="btn btnSuccess"
        disabled={!!blockedReason}
        onClick={async () => {
          const coinsNum = Math.max(0, Math.floor(Number(coins) || 0));
          // request server withdrawal (currency choice)
          const j = await gs.actions.requestWithdrawServer(wallet, withdrawCurrency, coinsNum);
          const w = j?.withdrawal;
          if (w?.id) {
            gs.actions.requestWithdraw({ id: w.id, wallet, currency: w.currency, usd: w.usd, netUsd: w.netUsd, feePct: w.feePct, processAfter: w.processAfter, coins: coinsNum });
            setWallet("");
            setCoins("1000");
          }
        }}
      >
        Withdraw
      </button>

      {blockedReason && <div className="muted tiny">⚠ {blockedReason}</div>}
    </div>
    {!gs.state.tutorialSeen ? <IntroStory gs={gs} /> : null}
      <RewardFX gs={gs} />
  );
}

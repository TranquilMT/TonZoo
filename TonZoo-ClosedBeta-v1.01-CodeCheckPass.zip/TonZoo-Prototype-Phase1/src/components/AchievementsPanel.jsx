import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import Card from "./Card";

const ACH = [
  { id: "first_animal", title: "First Animal", desc: "Buy your first animal.", reward: 600 },
  { id: "first_pavilion", title: "First Pavilion", desc: "Build your first pavilion.", reward: 600 },
  { id: "first_mission", title: "First Mission", desc: "Complete and claim a mission.", reward: 600 },
  { id: "big_win", title: "Big Win!", desc: "Hit a big win in Wheel or Slots.", reward: 1500 },
];

export default function AchievementsPanel({ gs, open, onClose }) {
  const s = gs.state;
  const unlocked = s.achievements || {};
  const claimed = s.achievementsClaimed || {};

  return (
    <AnimatePresence>
      {open ? (
        <motion.div className="modalOverlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div
            className="achListCard"
            initial={{ scale: 0.96, y: 14, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.98, y: 10, opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
          >
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 1000, fontSize: 18 }}>Achievements</div>
                <div className="muted tiny">Unlock → claim tickets</div>
              </div>
              <button className="btn btnDisabled" onClick={onClose}>Close</button>
            </div>

            <div className="hr" />

            {ACH.map(a => {
              const isUnlocked = !!unlocked[a.id];
              const isClaimed = !!claimed[a.id];
              const canClaim = isUnlocked && !isClaimed;

              return (
                <Card key={a.id} className={"achRow " + (isUnlocked ? "achUnlocked" : "")}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 950, display: "flex", gap: 8, alignItems: "center" }}>
                      <span>{isUnlocked ? "🏆" : "🔒"}</span>
                      <span>{a.title}</span>
                      <span className="pill blue" style={{ marginLeft: "auto" }}>+{a.reward} 🎟️</span>
                    </div>
                    <div className="muted tiny" style={{ marginTop: 4 }}>{a.desc}</div>
                  </div>

                  <button
                    className={"btn " + (canClaim ? "btnSuccess" : "btnDisabled")}
                    disabled={!canClaim}
                    onClick={() => gs.actions.claimAchievement(a.id)}
                    style={{ marginLeft: 10, minWidth: 96 }}
                  >
                    {isClaimed ? "Claimed" : "Claim"}
                  </button>
                </Card>
              );
            })}
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

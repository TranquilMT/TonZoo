import React from "react";
import { motion } from "framer-motion";
import Icon from "./Icon";

const items = [
  { id: "friends", label: "FRIENDS", icon: "👥" },
  { id: "games", label: "GAMES", icon: "👑" },
  { id: "zoo", label: "ZOO", icon: "🤍" },
  { id: "profile", label: "PROFILE", icon: "👤" },
];

export default function BottomNav({ active, onChange }) {
  return (
    <div className="bottomNav">
      {items.map((it) => (
        <button
          key={it.id}
          className={"navBtn " + (active === it.id ? "active" : "")}
          onClick={() => onChange(it.id)}
        >
          <div className="navIcon">{it.icon}</div>
          <div className="navLabel">{it.label}</div>
        </button>
      ))}
    </div>
  );
}

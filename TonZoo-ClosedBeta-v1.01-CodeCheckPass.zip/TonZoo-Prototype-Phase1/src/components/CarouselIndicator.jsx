import React, { useEffect, useState } from "react";

export default function CarouselIndicator({ containerRef, count }) {
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const el = containerRef?.current;
    if (!el) return;

    const onScroll = () => {
      const w = el.clientWidth || 1;
      const x = el.scrollLeft || 0;
      const i = Math.round(x / w);
      setIdx(Math.max(0, Math.min(count - 1, i)));
    };

    onScroll();
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, [containerRef, count]);

  if (count <= 1) return null;

  return (
    <div className="carouselHint">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className={"dot " + (i === idx ? "active" : "")} />
      ))}
    </div>
  );
}

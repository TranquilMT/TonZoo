import React, { useMemo, useState } from "react";
import Modal from "./Modal";
import Card from "./Card";
import { ANIMALS } from "../data/catalog";
import { RARITY_LABEL, RARITY_MULT } from "../data/rarities";
import { tgHaptic } from "../utils/telegram";

function byId(id){ return ANIMALS.find(a => a.id === id); }

export default function ZooPensPanel({ gs }) {
  const s = gs.state;
  const [open, setOpen] = useState(false);
  const [slotId, setSlotId] = useState(null);

  const slots = s.zooSlots || [];
  const placedCounts = useMemo(() => {
    const m = {};
    for (const sl of slots) if (sl?.animalId) m[sl.animalId] = (m[sl.animalId]||0)+1;
    return m;
  }, [slots]);

  const available = useMemo(() => {
    // animals you can place (owned > placed)
    const out = [];
    for (const a of ANIMALS) {
      const owned = s.ownedAnimals?.[a.id] || 0;
      const used = placedCounts[a.id] || 0;
      if (owned > used) out.push({ a, owned, used });
    }
    return out;
  }, [s.ownedAnimals, placedCounts]);

  function openPicker(id){
    setSlotId(id);
    setOpen(true);
  }

  function closePicker(){
    setOpen(false);
    setSlotId(null);
  }

  return (
    <>
      <div className="sectionHeader">
        <h3 style={{ marginTop: 0 }}>Zoo Pens</h3>
        <div className="muted tiny">Only placed animals attract visitors.</div>
        <div className="row" style={{gap:8, marginTop:8, flexWrap:"wrap"}}>
          <div className="pill blue">Prestige: <b>{gs.derived.prestige.toLocaleString()}</b></div>
          <div className="pill">Rank: <b>{gs.derived.prestigeRank}</b></div>
        </div>
        <div className="muted tiny" style={{ marginTop: 6 }}>
          {(() => {
            const now = Date.now();
            const dayKey = (ms) => Math.floor(ms / 86400000);
            const today = dayKey(now);
            const paid = (s.upkeepPaidThroughDay ?? today);
            const late = Math.max(0, today - paid);
            const mult = late > 0 ? 0.5 : 1;
            return (<>
              Upkeep: <b>{late > 0 ? "Overdue" : "Paid"}</b> • Output {Math.round(mult*100)}%
            </>);
          })()}
        </div>
      </div>

      <div className="pensGrid">
        {slots.map((sl) => {
          const def = sl.animalId ? byId(sl.animalId) : null;
          const lvl = sl.animalId ? Math.max(1, Number(s.animalLevels?.[sl.animalId] || 1)) : 1;

          const tier = def?.rarityTier || "common";
          const mult = RARITY_MULT[tier] ?? 1;
          const levelMult = 1 + (lvl - 1) * 0.15;
          const vpd = def ? (def.visitorsPerDay || 0) * mult * levelMult : 0;

          const unlockCost = Math.floor(1500 * Math.pow(Math.max(0, sl.slotId - 1), 1.35));

          return (
            <Card key={sl.slotId} className={"penCard " + (sl.unlocked ? "" : "locked")}>
              <div className="row" style={{ justifyContent: "space-between" }}>
                <div className="muted tiny">Pen #{sl.slotId + 1}</div>
                {!sl.unlocked ? <div className="pill pink">Locked</div> : (def ? <div className="pill blue">{RARITY_LABEL[tier] || tier}</div> : <div className="pill">Empty</div>)}
              </div>

              <div className="penBody" onClick={() => sl.unlocked && openPicker(sl.slotId)}>
                {sl.unlocked ? (
                  def ? (
                    <div className="row" style={{ gap: 10, alignItems: "center" }}>
                      <img src={def.icon} alt="" className="animalIcon"/>
                      <div style={{ flex: 1 }}>
                        <div className="cardTitle" style={{ marginBottom: 2 }}>{def.name}</div>
                        <div className="muted tiny">Lv.{lvl} • {Math.round(vpd).toLocaleString()} / day 👥</div>
                      </div>
                    </div>
                  ) : (
                    <div className="muted" style={{ textAlign: "center", padding: "18px 0" }}>
                      Tap to place an animal
                    </div>
                  )
                ) : (
                  <div style={{ textAlign: "center", padding: "18px 0" }}>
                    <div className="muted tiny">Unlock cost</div>
                    <div className="pill">{unlockCost.toLocaleString()} 🟩</div>
                    <div className="muted tiny" style={{marginTop:6}}>
                      {sl.slotId>=4 && gs.derived.prestige < (sl.slotId===4?750:2000) ? `Need Prestige ${(sl.slotId===4?750:2000)}+` : ""}
                    </div>
                  </div>
                )}
              </div>

              <div className="row" style={{ gap: 8, marginTop: 10, justifyContent: "space-between" }}>
                {!sl.unlocked ? (
                  <button className="btn btnPrimary" onClick={() => { tgHaptic("impact","light"); gs.actions.unlockZooSlot(sl.slotId); }}>
                    Unlock
                  </button>
                ) : def ? (
                  <>
                    <button className="btn" onClick={() => { tgHaptic("selection"); openPicker(sl.slotId); }}>
                      Change
                    </button>
                    <button className="btn" onClick={() => { tgHaptic("impact","light"); gs.actions.removeAnimalSlot(sl.slotId); }}>
                      Remove
                    </button>
                    <button className="btn btnPrimary" onClick={() => { tgHaptic("impact","medium"); gs.actions.levelUpAnimal(def.id); }}>
                      Level Up
                    </button>
                  </>
                ) : (
                  <button className="btn btnPrimary" onClick={() => openPicker(sl.slotId)}>
                    Place
                  </button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      <Modal open={open} onClose={closePicker} width={520}>
        <div className="modalTitle">Select animal for Pen #{(slotId ?? 0) + 1}</div>
        <div className="muted tiny" style={{ marginBottom: 10 }}>
          Available animals are those you own and haven’t placed.
        </div>

        <div className="list">
          {available.length === 0 ? (
            <div className="muted">You don’t have any unplaced animals yet. Buy some first.</div>
          ) : available.map(({ a, owned, used }) => {
            const lvl = Math.max(1, Number(s.animalLevels?.[a.id] || 1));
            const tier = a.rarityTier || "common";
            return (
              <div key={a.id} className="listRow" onClick={() => { tgHaptic("impact","light"); gs.actions.placeAnimalSlot(slotId, a.id); closePicker(); }}>
                <img src={a.icon} alt="" className="animalIcon"/>
                <div style={{ flex: 1 }}>
                  <div className="row" style={{ justifyContent: "space-between" }}>
                    <div><b>{a.name}</b> <span className="muted tiny">Lv.{lvl}</span></div>
                    <div className="pill">{RARITY_LABEL[tier] || tier}</div>
                  </div>
                  <div className="muted tiny">Owned {owned} • Placed {used}</div>
                </div>
              </div>
            );
          })}
        </div>
      </Modal>
    </>
  );
}

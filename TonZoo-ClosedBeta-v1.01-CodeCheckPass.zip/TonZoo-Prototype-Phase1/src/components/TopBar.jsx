import React from "react";
import { getTWA } from "../telegram/webapp.js";

export default function TopBar({ title, onTopUp, onWithdraw }) {
  const onClose = () => {
    const twa = getTWA();
    try {
      if (twa && typeof twa.close === "function") {
        twa.close();
        return;
      }
    } catch {}
    window.history.back();
  };

  return (
    <div className="topBar">
      <div className="topBarLeft">
        <button className="iconBtn" title="Close" onClick={onClose}>✕</button>
        <div className="title">{title}</div>
      </div>
      <div className="topBarRight">
        <button className="btn btnPrimary small" onClick={onTopUp}>Top up</button>
        <button className="btn btnSuccess small" onClick={onWithdraw}>Withdraw</button>
      </div>
    </div>
  );
}

import React from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * Lightweight, non-invasive highlight rings.
 * Uses approximate positions to keep it Telegram-safe.
 */
export default function IntroHighlights({ step }) {
  // step mapping: 1 = Zoo Animals, 2 = Zoo Pavilions, 3 = Games/Missions, 4 = Profile Deposit
  const showZoo = step === 1 || step === 2;
  const showGames = step === 3;
  const showMissions = step === 3;
  const showProfile = step === 4;

  return (
    <div className="hlLayer">
      <AnimatePresence>
        {showZoo ? (
          <motion.div key="zoo" className="hlRing hlZoo" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div className="hlPulse" animate={{ scale: [1, 1.05, 1], opacity: [0.9, 0.6, 0.9] }} transition={{ duration: 1.2, repeat: Infinity }} />
            <div className="hlLabel">Tap Zoo</div>
          </motion.div>
        ) : null}

        {showGames ? (
          <motion.div key="games" className="hlRing hlGames" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div className="hlPulse" animate={{ scale: [1, 1.05, 1], opacity: [0.9, 0.6, 0.9] }} transition={{ duration: 1.2, repeat: Infinity }} />
            <div className="hlLabel">Tap Games</div>
          </motion.div>
        ) : null}

        {showMissions ? (
          <motion.div key="missions" className="hlRing hlMissions" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div className="hlPulse" animate={{ scale: [1, 1.05, 1], opacity: [0.9, 0.6, 0.9] }} transition={{ duration: 1.2, repeat: Infinity }} />
            <div className="hlLabel">Missions</div>
          </motion.div>
        ) : null}

        {showProfile ? (
          <motion.div key="profile" className="hlRing hlProfile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div className="hlPulse" animate={{ scale: [1, 1.05, 1], opacity: [0.9, 0.6, 0.9] }} transition={{ duration: 1.2, repeat: Infinity }} />
            <div className="hlLabel">Deposit</div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}

import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, animate } from "framer-motion";
import CarouselIndicator from "./CarouselIndicator.jsx";

/**
 * Spring swipe carousel:
 * - drag x with snap
 * - active card scales slightly
 * - subtle parallax on inner content
 *
 * Pass renderItem(item, index, activeIndex)
 */
export default function MotionCarousel({ items, renderItem }) {
  const wrapRef = useRef(null);
  const trackRef = useRef(null);
  const [active, setActive] = useState(0);

  const cardW = useMemo(() => {
    const el = wrapRef.current;
    if (!el) return 320;
    // 86% width like previous, minus small gaps
    return Math.floor(el.clientWidth * 0.86);
  }, []);

  const gap = 12;

  const maxIndex = Math.max(0, items.length - 1);

  const snapTo = (i) => {
    const next = Math.max(0, Math.min(maxIndex, i));
    setActive(next);
    const x = -(next * (cardW + gap));
    if (trackRef.current) {
      animate(trackRef.current, { x }, { type: "spring", stiffness: 280, damping: 30 });
    }
  };

  useEffect(() => {
    const onResize = () => snapTo(active);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  // Compute bounds
  const totalW = items.length * cardW + (items.length - 1) * gap;
  const viewportW = wrapRef.current?.clientWidth || 360;
  const leftBound = -(totalW - viewportW);
  const rightBound = 0;

  return (
    <div>
      <div className="motionCarousel" ref={wrapRef}>
        <motion.div
          className="motionTrack"
          ref={trackRef}
          drag="x"
          dragElastic={0.08}
          dragConstraints={{ left: Math.min(leftBound, 0), right: rightBound }}
          onDragEnd={(e, info) => {
            const offset = info.offset.x;
            const velocity = info.velocity.x;

            // Swipe decision: velocity or offset
            const thresh = cardW * 0.18;
            let next = active;

            if (offset < -thresh || velocity < -600) next = active + 1;
            if (offset > thresh || velocity > 600) next = active - 1;

            snapTo(next);
          }}
          style={{ x: 0 }}
        >
          {items.map((it, i) => {
            const isActive = i === active;
            return (
              <motion.div
                key={it.id || i}
                className="motionCard"
                style={{ width: cardW, marginRight: i === maxIndex ? 0 : gap }}
                animate={{
                  scale: isActive ? 1 : 0.98,
                  opacity: isActive ? 1 : 0.92,
                }}
                transition={{ type: "spring", stiffness: 260, damping: 28 }}
                onClick={() => snapTo(i)}
              >
                <motion.div
                  className="motionParallax"
                  animate={{ y: isActive ? 0 : 2 }}
                  transition={{ type: "spring", stiffness: 220, damping: 26 }}
                >
                  {renderItem(it, i, active)}
                </motion.div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>

      <CarouselIndicator
        containerRef={{
          current: {
            clientWidth: cardW + gap,
            scrollLeft: active * (cardW + gap),
            addEventListener: () => {},
            removeEventListener: () => {},
          },
        }}
        count={items.length}
      />
    </div>
  );
}

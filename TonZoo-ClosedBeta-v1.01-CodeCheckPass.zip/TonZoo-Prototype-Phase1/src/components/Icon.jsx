import React from "react";

const ICONS = {
  checkin: (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M20 12c0 4.418-3.582 8-8 8s-8-3.582-8-8 3.582-8 8-8 8 3.582 8 8Z" stroke="currentColor" strokeWidth="2"/>
      <path d="M8 12.2l2.2 2.2L16.5 8.9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  marketing: (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M4 12v6h4l5 3V3L8 6H4v6Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M16 8c1.5 1.5 1.5 6.5 0 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M18.5 6c2.7 2.7 2.7 9.3 0 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  attraction: (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M12 2v20" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M4 9c2-3 6-4 8-4s6 1 8 4" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M4 15c2 3 6 4 8 4s6-1 8-4" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M7 12h10" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  boost: (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M13 2L4 14h7l-1 8 10-14h-7l0-6Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    </svg>
  ),
  withdraw: (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M7 7h10v4H7V7Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M5 11h14v9H5v-9Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M12 14v4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M10.5 16.5 12 18l1.5-1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  tx: (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M7 7h10v10H7V7Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M9 9h6M9 12h6M9 15h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  bus: (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M6 16V6c0-2 3-3 6-3s6 1 6 3v10" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M6 10h12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      <path d="M7 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM17 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z" fill="currentColor"/>
      <path d="M6 16h12v2H6v-2Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    </svg>

zoo: (
  <svg viewBox="0 0 24 24" fill="none">
    <path d="M7 12c0 3 2 6 5 6s5-3 5-6-2-6-5-6-5 3-5 6Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M4.5 9.5c0-1.4 1.1-2.5 2.5-2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M19.5 9.5c0-1.4-1.1-2.5-2.5-2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M9 14c.6.7 1.8 1.2 3 1.2s2.4-.5 3-1.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
),
arcade: (
  <svg viewBox="0 0 24 24" fill="none">
    <path d="M6 9a6 6 0 0 1 12 0v7a3 3 0 0 1-3 3h-1l-2-2h-0l-2 2H9a3 3 0 0 1-3-3V9Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M9 12h2M10 11v2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M15 12h.01" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
    <path d="M17 11h.01" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
  </svg>
),
shop: (
  <svg viewBox="0 0 24 24" fill="none">
    <path d="M6 8l1-3h10l1 3" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M6 8v12h12V8" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M9 8a3 3 0 0 0 6 0" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
),
profile: (
  <svg viewBox="0 0 24 24" fill="none">
    <path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M4 20c1.6-4 14.4-4 16 0" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
),
visitors: (
  <svg viewBox="0 0 24 24" fill="none">
    <path d="M8 11a3 3 0 1 0-3-3 3 3 0 0 0 3 3Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M16 11a3 3 0 1 0-3-3 3 3 0 0 0 3 3Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M2 20c1-3 8-3 9 0" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M13 20c1-3 8-3 9 0" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
),
mission: (
  <svg viewBox="0 0 24 24" fill="none">
    <path d="M7 4h10v16H7V4Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M9 8h6M9 12h6M9 16h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
),
event: (
  <svg viewBox="0 0 24 24" fill="none">
    <path d="M7 3v3M17 3v3" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M4 7h16v13H4V7Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M8 11h8M8 15h5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
),
trophy: (
  <svg viewBox="0 0 24 24" fill="none">
    <path d="M8 4h8v3a4 4 0 1 1-8 0V4Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M6 4H4v2a4 4 0 0 0 4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M18 4h2v2a4 4 0 0 1-4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M10 17h4v3h-4v-3Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    <path d="M8 20h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
),

  ),
};

export default function Icon({ name, size=18, className="" }) {
  const node = ICONS[name] || null;
  return (
    <span className={"ic " + className} style={{ width:size, height:size }}>
      {node ? React.cloneElement(node, { width:size, height:size }) : null}
    </span>
  );
}

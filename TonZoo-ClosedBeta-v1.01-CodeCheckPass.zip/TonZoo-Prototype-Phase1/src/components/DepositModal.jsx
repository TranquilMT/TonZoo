import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Card from "./Card";
import { TonConnectButton, useTonConnectUI } from "@tonconnect/ui-react";
import { tgBackButton, tgHaptic } from "../utils/telegram";
import DemoTonConnect from "./DemoTonConnect";
import { beginCell, Address, toNano } from "@ton/core";
import { useTonWallet } from "@tonconnect/ui-react";

function nanoTonFromUsd(usd) {
  // Prototype conversion (client-side): 1 TON ~= $5 (adjust later / use price oracle)
  const ton = (Number(usd) || 1) / 5;
  return Math.floor(ton * 1e9);
}

export default function DepositModal({ gs, open, onClose }) {
  const [usd, setUsd] = useState(1);
  const [walletMode, setWalletMode] = useState("demo");
  const [demoOpen, setDemoOpen] = useState(false);
  const [demoReq, setDemoReq] = useState(null);
  const [tonConnectUI] = useTonConnectUI();
  const [currency, setCurrency] = useState("TON");
  const intents = gs.state.depositIntents || {};

  const lastIntent = useMemo(() => {
    const arr = Object.values(intents).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));
    return arr[0] || null;
  }, [intents]);

  async function autoCheckDeposits(gs, attempts=8){
    for(let i=0;i<attempts;i++){
      try{
        const r = await gs.actions.checkDeposits();
        if(r?.confirmed?.length) return true;
      }catch{}
      await new Promise(res=>setTimeout(res, 1500));
    }
    return false;
  }

  const expectedNano = useMemo(() => (currency === "TON" ? nanoTonFromUsd(usd) : 0), [currency, usd]);

  return (
    <AnimatePresence>
      {open ? (
        <motion.div className="modalOverlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div className="achListCard" initial={{ scale: 0.96, y: 14, opacity: 0 }} animate={{ scale: 1, y: 0, opacity: 1 }} exit={{ scale: 0.98, y: 10, opacity: 0 }}>
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 1000, fontSize: 18 }}>Deposit</div>
                {!assertTreasuryConfigured() ? (
        <div className="callout" style={{ marginBottom: 10 }}>
          <div><b>Treasury not configured.</b></div>
          <div className="muted tiny">Set <b>VITE_TREASURY_ADDRESS</b> in your .env before using real deposits.</div>
        </div>
      ) : null}

      <div className="muted tiny">TON + USDT (B2 auto-verify)</div>
              </div>
              <button className="btn btnDisabled" onClick={onClose}>Close</button>
            </div>

            <div className="hr" />

            <div className="row twoCol">
              <label className="field">
                <span>Amount (USD)</span>
                <input type="number" min={1} value={usd} onChange={(e)=>setUsd(Number(e.target.value))} />
              </label>
              <label className="field">
                <span>Wallet Mode</span>
                <select value={walletMode} onChange={(e)=>setWalletMode(e.target.value)}>
                  <option value="demo">Demo Wallet</option>
                  <option value="real">Real TonConnect</option>
                </select>
              </label>
              <label className="field">
                <span>Currency</span>
                <select value={currency} onChange={(e)=>setCurrency(e.target.value)}>
                  <option value="TON">TON</option>
                  <option value="USDT">USDT (TON)</option>
                </select>
              </label>
            </div>

            <button className="btn btnPrimary" onClick={async ()=>{ await gs.actions.createDepositIntent(currency, usd, expectedNano); }}>
              Create Deposit Request
            </button>

            <div className="hr" />

            {walletMode === "real" ? (
              <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                <div>
                  <div style={{ fontWeight: 950 }}>Connect Wallet</div>
                  <div className="muted tiny">Real TonConnect for TON transfers (USDT via TonConnect next phase)</div>
                </div>
                <TonConnectButton />
              </div>
            ) : null}

            {lastIntent ? (
              <Card className="achRow">
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 950 }}>Send Payment</div>
                  <div className="muted tiny">Send to address below with the exact comment (required for auto-verify)</div>
                  <div className="hr" />
                  <div className="muted tiny">Address</div>
                  <div style={{ fontFamily: "monospace", fontSize: 12, wordBreak: "break-all" }}>{lastIntent.pay?.address}</div>
                  <div className="muted tiny" style={{ marginTop: 8 }}>Comment</div>
                  <div style={{ fontFamily: "monospace", fontSize: 12 }}>{lastIntent.pay?.comment}</div>
                  <div className="muted tiny" style={{ marginTop: 8 }}>
                    {currency === "TON" ? `Expected: ${(expectedNano/1e9).toFixed(3)} TON (prototype)` : "Expected: send USDT with same comment (prototype)"}
                  </div>
                </div>
              </Card>
            ) : (
              <div className="muted">Create a deposit request to see payment details.</div>
            )}

            <div className="hr" />

            <div className="row" style={{ gap: 10, flexWrap: "wrap" }}>
            <button className="btn btnSuccess" onClick={async ()=>{ await gs.actions.checkDeposits(); }} style={{ flex: 1, minWidth: 180 }}>
              Check Deposits (auto-verify)
            </button>
            <button className="btn btnPrimary" onClick={async ()=>{
                if(!lastIntent?.id) return;
                if(walletMode === "demo"){
                  setDemoReq({ depositId: lastIntent.id, currency, usd, amountNano: expectedNano, address: lastIntent.pay?.address, comment: lastIntent.pay?.comment });
                  setDemoOpen(true);
                  return;
                }
                if (currency === "USDT") {
  // Real USDT jetton transfer via TonConnect
  try {
    const owner = wallet?.account?.address || wallet?.address;
    if (!owner) {
      window.alert("Please connect your wallet first.");
      return;
    }
    const master = (import.meta?.env?.VITE_USDT_JETTON_MASTER || "").trim();
    if (!master) {
      window.alert("USDT master not set. Add VITE_USDT_JETTON_MASTER in .env and server USDT_JETTON_MASTER.");
      return;
    }
    // ask server to compute sender jetton wallet address from owner+master
    const r = await fetch(`${API_BASE}/api/jetton/wallet_address?owner=${encodeURIComponent(owner)}&master=${encodeURIComponent(master)}`);
    const jj = await r.json();
    const jettonWallet = jj?.jettonWallet;
    if (!jettonWallet) {
      window.alert("Could not resolve your USDT jetton wallet address.");
      return;
    }
    // amount: USDT has 6 decimals
    const jettonAmount = BigInt(Math.round(Number(usd) * 1e6));
    const dest = Address.parse(lastIntent.pay?.address); // treasury owner address
    const responseDest = Address.parse(owner);

    const forwardPayload = beginCell()
      .storeUint(0, 32) // comment opcode
      .storeStringTail(lastIntent.pay?.comment || "")
      .endCell();

    const body = beginCell()
      .storeUint(0xf8a7ea5, 32)
      .storeUint(0, 64)
      .storeCoins(jettonAmount)
      .storeAddress(dest)
      .storeAddress(responseDest)
      .storeBit(0) // no custom payload
      .storeCoins(toNano("0.02")) // forward ton amount for notification
      .storeBit(1) // store forward payload as ref
      .storeRef(forwardPayload)
      .endCell();

    await tonConnectUI.sendTransaction({
      validUntil: Math.floor(Date.now() / 1000) + 600,
      messages: [
        {
          address: jettonWallet,
          amount: toNano("0.05").toString(), // fees
          payload: body.toBoc().toString("base64"),
        },
      ],
    });
  } catch (e) {
    console.error(e);
    window.alert("USDT transaction cancelled or failed.");
  }
  return;
}
                try{
                  await tonConnectUI.sendTransaction({
                    validUntil: Math.floor(Date.now()/1000) + 600,
                    messages: [{
                      address: lastIntent.pay?.address,
                      amount: String(expectedNano),
                      payload: lastIntent.pay?.comment,
                    }]
                  });
                  tgHaptic('impact','medium');
                  await autoCheckDeposits(gs, 10);
                }catch(e){
                  console.error(e);
                  window.alert("Transaction cancelled or failed.");
                }
              }} style={{ flex: 1, minWidth: 180 }}>
              Pay
            </button>
          </div>

          <div className="muted tiny" style={{ marginTop: 10 }}>
            Demo Pay confirms the last deposit request instantly (no blockchain).
          </div>

          <div className="hr" />

          <button className="btn btnSuccess" onClick={async ()=>{ await gs.actions.checkDeposits(); }}>
              Check Deposits (auto-verify)
            </button>

            <div className="muted tiny" style={{ marginTop: 10 }}>
              In Phase C we will wire true TON Connect transfers + jetton parsing for USDT.
            </div>
          </motion.div>
        </motion.div>
      ) : null}

      <DemoTonConnect
        open={demoOpen}
        onClose={() => setDemoOpen(false)}
        request={demoReq}
        onApprove={async () => {
          if (demoReq?.depositId) await gs.actions.demoConfirmDeposit(demoReq.depositId);
        }}
      />
    </AnimatePresence>
  );
}

import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Card from "./Card";
import IntroHighlights from "./IntroHighlights.jsx";

const SCENES = [
  {
    title: "TonZoo",
    body: "Build a neon zoo. Collect animals. Grow visitors. Win rewards.",
    emoji: "🦁",
    hint: "Tap Next",
  },
  {
    title: "Buy your first animal",
    body: "We gave you enough visitors to buy exactly 1 animal so you can learn the loop.",
    emoji: "🐧",
    hint: "Zoo → Animals",
  },
  {
    title: "Build pavilions",
    body: "Pavilions generate tickets while you play (and even while you're offline).",
    emoji: "🏟️",
    hint: "Zoo → Pavilions",
  },
  {
    title: "Missions & games",
    body: "Complete daily missions and play mini-games to boost your zoo faster.",
    emoji: "🎰",
    hint: "Games + Missions",
  },
  {
    title: "Withdraw rule",
    body: "To request a withdrawal, you must deposit at least $1 total (anti-abuse).",
    emoji: "🔒",
    hint: "Profile → Deposit",
  },
];

export default function IntroStory({ gs }) {
  const [mode, setMode] = useState("cinematic"); // cinematic -> steps
  const [i, setI] = useState(0);

  const s = useMemo(() => SCENES[Math.min(i, SCENES.length - 1)], [i]);
  const done = i >= SCENES.length - 1;

  useEffect(() => {
    if (mode !== "cinematic") return;
    const t = setTimeout(() => setMode("steps"), 2400);
    return () => clearTimeout(t);
  }, [mode]);

  return (
    <div className="introOverlay2">
      <AnimatePresence mode="wait">
        {mode === "cinematic" ? (
          <motion.div
            key="cinematic"
            className="cinematic"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="logoBurst"
              initial={{ scale: 0.7, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut" }}
            >
              <div className="logoMark">🦁</div>
              <div className="logoText">TonZoo</div>
              <div className="logoTag">TON • Zoo • Web3</div>
            </motion.div>

            <motion.div
              className="zoomLine"
              initial={{ opacity: 0, scaleX: 0.2 }}
              animate={{ opacity: 1, scaleX: 1 }}
              transition={{ delay: 0.25, duration: 0.55 }}
            />

            <motion.div
              className="cinematicHint"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.35 }}
            >
              Entering Zoo…
            </motion.div>
          </motion.div>
        ) : (
          <>
            <IntroHighlights step={i} />
            <motion.div
            key="steps"
            className="introWrap2"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
          >
            <Card className="bigCard introCard2">
              <div className="introTop2">
                <div className="pill pink">Intro</div>
                <div className="muted tiny">{i + 1} / {SCENES.length}</div>
              </div>

              <div className="introCenter2">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={i}
                    className="introEmoji2"
                    initial={{ opacity: 0, y: 10, scale: 0.9 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.92 }}
                    transition={{ duration: 0.25 }}
                  >
                    {s.emoji}
                  </motion.div>
                </AnimatePresence>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={s.title}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    transition={{ duration: 0.22 }}
                  >
                    <h2 className="introTitle2">{s.title}</h2>
                    <div className="muted introBody2">{s.body}</div>
                    <div className="introHintPill">{s.hint}</div>
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="introBars2">
                {SCENES.map((_, idx) => (
                  <div key={idx} className={"bar2 " + (idx <= i ? "on" : "")} />
                ))}
              </div>

              <div className="introBtns2">
                <button className={"btn " + (i === 0 ? "btnDisabled" : "btnPrimary")} disabled={i === 0} onClick={() => setI((x) => Math.max(0, x - 1))}>
                  Back
                </button>
                <button
                  className={"btn " + (done ? "btnSuccess" : "btnPrimary")}
                  onClick={() => {
                    if (!done) setI((x) => Math.min(SCENES.length - 1, x + 1));
                    else gs.actions.finishTutorial();
                  }}
                >
                  {done ? "Enter Zoo" : "Next"}
                </button>
              </div>

              <button className="btn btnDisabled introSkip2" onClick={gs.actions.finishTutorial}>
                Skip
              </button>
            </Card>
          </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

import React, { useMemo, useState } from "react";
import Card from "./Card";

const STEPS = [
  { title: "Welcome to TonZoo", body: "Build pavilions to generate tickets, and buy animals to attract visitors. Visitors are your main fuel." },
  { title: "Zoo → Pavilions", body: "Buy pavilions to increase tickets/hour. Tickets accrue automatically over time." },
  { title: "Zoo → Animals", body: "Buy animals to generate visitors/day. Visitors are used for mini-games and animal purchases." },
  { title: "Games", body: "Spin Wheel, play Slots, and bid in Auction to win more tickets and rewards." },
  { title: "Exchange & Withdraw", body: "Exchange tickets into coins. Withdraw requires ≥ 1000 visitors and ≥ 1000 withdraw coins (prototype queue)." },
];

export default function TutorialOverlay({ gs }) {
  const [i, setI] = useState(0);
  const step = useMemo(() => STEPS[Math.min(i, STEPS.length - 1)], [i]);
  const done = i >= STEPS.length - 1;

  return (
    <div className="tutorialOverlay">
      <div className="tutorialWrap">
        <Card className="bigCard tutorialCard">
          <div className="tutorialTop">
            <div className="pill pink">Tutorial</div>
            <div className="muted tiny">{i + 1} / {STEPS.length}</div>
          </div>

          <h3 style={{ marginTop: 12 }}>{step.title}</h3>
          <div className="muted" style={{ marginTop: 8, lineHeight: 1.35 }}>{step.body}</div>

          <div className="hr" style={{ marginTop: 14 }} />

          <div className="tutorialBtns">
            <button className={"btn " + (i === 0 ? "btnDisabled" : "btnPrimary")} disabled={i === 0} onClick={() => setI((x) => Math.max(0, x - 1))}>
              Back
            </button>
            <button className={"btn " + (done ? "btnSuccess" : "btnPrimary")} onClick={() => { if (!done) setI((x) => Math.min(STEPS.length - 1, x + 1)); else gs.actions.finishTutorial(); }}>
              {done ? "Start playing" : "Next"}
            </button>
          </div>

          <button className="btn btnDisabled tutorialSkip" onClick={gs.actions.finishTutorial}>Skip</button>
        </Card>
      </div>
    </div>
  );
}

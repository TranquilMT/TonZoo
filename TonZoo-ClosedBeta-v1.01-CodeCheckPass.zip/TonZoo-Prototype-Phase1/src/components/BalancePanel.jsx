import React from "react";

export default function BalancePanel({ gs, onExchange }) {
  const s = gs.state;
  const d = gs.derived;

  return (
    <div className="balancePanel">
      <div className="balanceGrid">
        <div className="balBox">
          <div className="balLabel">Coins for purchases</div>
          <div className="balValue">{Math.floor(s.coinsPurchase).toLocaleString()} 🟩</div>
        </div>
        <div className="balBox">
          <div className="balLabel">Coins for withdrawal</div>
          <div className="balValue">{Math.floor(s.coinsWithdraw).toLocaleString()} 🟩</div>
        </div>
        <div className="balBox">
          <div className="balLabel">Tickets</div>
          <div className="balValue">{Math.floor(s.tickets).toLocaleString()} 🎟️</div>
        </div>
        <div className="balBox">
          <div className="balLabel">Visitors</div>
          <div className="balValue">{Math.floor(s.visitors).toLocaleString()} 👥</div>
        </div>
      </div>

      <div className="muted tiny" style={{ marginTop: 8 }}>
        Producing <b>{d.ticketsPerHour.toLocaleString()}</b> tickets/hour •
        Attracting <b> {d.visitorsPerDay.toLocaleString()}</b> visitors/day
      </div>

      <button
        className="btn btnPrimary"
        style={{ marginTop: 10 }}
        onClick={onExchange}
        disabled={Math.floor(s.tickets) < 300}
      >
        Exchange tickets (300 🎟️ → +2 🟩 purchase +1 🟩 withdraw)
      </button>
    </div>
  );
}

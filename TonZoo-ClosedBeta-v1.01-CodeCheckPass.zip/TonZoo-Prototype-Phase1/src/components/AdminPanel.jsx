import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Card from "./Card";

export default function AdminPanel({ gs, open, onClose }) {
  const s = gs.state;
  const [usd, setUsd] = useState(5);
  const [fee, setFee] = useState(s.withdrawFeePct ?? 0.05);
  const [delayH, setDelayH] = useState(Math.round((s.withdrawDelayMs ?? 0) / 3600000));
  const [capD, setCapD] = useState(s.withdrawDailyCapUsd ?? 10);
  const [capW, setCapW] = useState(s.withdrawWeeklyCapUsd ?? 50);

  const split = s.treasurySplit || { treasury: 0.6, profit: 0.3, buffer: 0.1 };

  return (
    <AnimatePresence>
      {open ? (
        <motion.div className="modalOverlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div
            className="achListCard"
            initial={{ scale: 0.96, y: 14, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.98, y: 10, opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
          >
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 1000, fontSize: 18 }}>Admin Console</div>
                <div className="muted tiny">Treasury simulation • Phase A</div>
              </div>
              <button className="btn btnDisabled" onClick={onClose}>Close</button>
            </div>

            <div className="hr" />

            <Card className="achRow">
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 950 }}>Balances</div>
                <div className="muted tiny">Treasury funds withdrawals • Profit is yours • Buffer for spikes</div>
              </div>
              <div className="row" style={{ gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                <div className="pill blue">🏦 ${Number(s.treasuryUsd||0).toFixed(2)}</div>
                <div className="pill">💼 ${Number(s.profitUsd||0).toFixed(2)}</div>
                <div className="pill pink">🧪 ${Number(s.bufferUsd||0).toFixed(2)}</div>
                <button className="btn btnPrimary" onClick={gs.actions.refreshLedger} style={{ padding: "8px 10px" }}>↻ Sync</button>
              </div>
            </Card>

            <div className="hr" />

            <div className="row twoCol">
              <label className="field">
                <span>Sim deposit (USD)</span>
                <input type="number" value={usd} min={1} onChange={(e)=>setUsd(Number(e.target.value))} />
              </label>

              <button className="btn btnPrimary" onClick={()=>gs.actions.simDeposit(usd, undefined, "")}>
                Demo Deposit → Split + Coins
              </button>
            </div>

            <div className="hr" />

            <Card className="achRow">
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 950 }}>Withdrawal Engine</div>
                <div className="muted tiny">
                  Fee {(Number(s.withdrawFeePct??0)*100).toFixed(1)}% • Delay {Math.round((s.withdrawDelayMs||0)/3600000)}h • Caps ${s.withdrawDailyCapUsd}/day • ${s.withdrawWeeklyCapUsd}/week
                </div>
              </div>
              <button className={"btn " + (s.withdrawalsPaused ? "btnDanger" : "btnSuccess")} onClick={gs.actions.adminToggleWithdrawals}>
                {s.withdrawalsPaused ? "Paused" : "Active"}
              </button>
            </Card>

            <div className="hr" />

            <div className="row twoCol">
              <label className="field">
                <span>Fee %</span>
                <input type="number" step="0.01" min="0" max="0.2" value={fee} onChange={(e)=>setFee(Number(e.target.value))} />
              </label>
              <label className="field">
                <span>Delay (hours)</span>
                <input type="number" min="0" value={delayH} onChange={(e)=>setDelayH(Number(e.target.value))} />
              </label>
              <label className="field">
                <span>Daily cap (USD)</span>
                <input type="number" min="0" value={capD} onChange={(e)=>setCapD(Number(e.target.value))} />
              </label>
              <label className="field">
                <span>Weekly cap (USD)</span>
                <input type="number" min="0" value={capW} onChange={(e)=>setCapW(Number(e.target.value))} />
              </label>
            </div>

            <button
              className="btn btnPrimary"
              onClick={() => gs.actions.adminSetTreasuryConfig({
                withdrawFeePct: fee,
                withdrawDelayMs: Math.max(0, delayH) * 3600000,
                withdrawDailyCapUsd: capD,
                withdrawWeeklyCapUsd: capW
              })}
            >
              Save Withdrawal Settings
            </button>

            <div className="hr" />

            <button className="btn btnSuccess" onClick={gs.actions.processWithdrawalsServer}>
              Process Ready Withdrawals (server)
            </button>

            <div className="hr" />

            <div className="muted tiny">
              Split: Treasury {(split.treasury*100).toFixed(0)}% / Profit {(split.profit*100).toFixed(0)}% / Buffer {(split.buffer*100).toFixed(0)}%
              <br/>
              Next phases will add real TON/USDT verification + on-chain payouts.
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

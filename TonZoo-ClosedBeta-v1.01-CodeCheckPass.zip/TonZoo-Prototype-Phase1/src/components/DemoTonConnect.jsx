import React, { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { tgBackButton, tgHaptic } from "../utils/telegram";

export default function DemoTonConnect({ open, onClose, request, onApprove }) {
  React.useEffect(() => {
    if (!open) return;
    const off = tgBackButton(true, () => onClose?.());
    return () => off?.();
  }, [open]);
  const summary = useMemo(() => {
    if (!request) return null;
    const ton = request.amountNano ? (request.amountNano / 1e9).toFixed(3) : "0.000";
    return {
      title: request.currency === "USDT" ? "USDT Transfer" : "TON Transfer",
      amount: request.currency === "USDT" ? `$${request.usd} USDT (prototype)` : `${ton} TON`,
      to: request.address,
      comment: request.comment,
    };
  }, [request]);

  return (
    <AnimatePresence>
      {open ? (
        <motion.div className="modalOverlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div className="achListCard" initial={{ scale: 0.96, y: 14, opacity: 0 }} animate={{ scale: 1, y: 0, opacity: 1 }} exit={{ scale: 0.98, y: 10, opacity: 0 }}>
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 1000, fontSize: 18 }}>Demo TON Wallet</div>
                <div className="muted tiny">Demo TonConnect flow (testing)</div>
              </div>
              <button className="btn btnDisabled" onClick={onClose}>Close</button>
            </div>

            <div className="hr" />

            {summary ? (
              <div style={{ fontSize: 13 }}>
                <div className="pill blue" style={{ display: "inline-flex", marginBottom: 8 }}>{summary.title}</div>
                <div><b>Amount:</b> {summary.amount}</div>
                <div style={{ wordBreak: "break-all" }}><b>To:</b> {summary.to}</div>
                <div style={{ fontFamily: "monospace", marginTop: 6 }}><b>Comment:</b> {summary.comment}</div>
              </div>
            ) : (
              <div className="muted">No request.</div>
            )}

            <div className="hr" />

            <div className="row" style={{ gap: 10 }}>
              <button className="btn btnDanger" onClick={onClose} style={{ flex: 1 }}>Reject</button>
              <button className="btn btnSuccess" onClick={() => { tgHaptic('impact','light'); onApprove?.(); onClose?.(); }} style={{ flex: 1 }}>
                Approve (demo)
              </button>
            </div>

            <div className="muted tiny" style={{ marginTop: 10 }}>
              Demo mode confirms the deposit intent instantly (no blockchain).
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

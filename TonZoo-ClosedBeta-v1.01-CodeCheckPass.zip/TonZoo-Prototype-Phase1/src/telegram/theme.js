import WebApp from "@twa-dev/sdk";

/**
 * Minimal Telegram WebApp helpers.
 * Works in Telegram and in normal browser (returns safe fallbacks).
 */
export function tgReady(){
  try{
    const tg = window?.Telegram?.WebApp || WebApp;
    tg?.ready?.();
    tg?.expand?.();
    return tg;
  }catch{
    return null;
  }
}

export function tgTheme(){
  try{
    const tg = window?.Telegram?.WebApp || WebApp;
    const params = tg?.themeParams || {};
    const colorScheme = tg?.colorScheme || "light";
    return { params, colorScheme };
  }catch{
    return { params: {}, colorScheme: "light" };
  }
}

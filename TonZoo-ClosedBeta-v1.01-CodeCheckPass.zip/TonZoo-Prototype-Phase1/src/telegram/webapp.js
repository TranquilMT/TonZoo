/**
 * Telegram Mini App helper
 * Uses window.Telegram.WebApp if running inside Telegram.
 * Falls back gracefully for normal browser testing.
 */
import WebApp from "@twa-dev/sdk";

export function getTWA() {
  const twa = (window?.Telegram?.WebApp) ? window.Telegram.WebApp : null;
  return twa || WebApp || null;
}

export function isInTelegram() {
  return !!(window?.Telegram?.WebApp);
}

export function initTelegramUI() {
  const twa = getTWA();
  try {
    if (!twa) return;

    if (typeof twa.ready === "function") twa.ready();
    if (typeof twa.expand === "function") twa.expand();

    if (typeof twa.setHeaderColor === "function") twa.setHeaderColor("#0b1020");
    if (typeof twa.setBackgroundColor === "function") twa.setBackgroundColor("#0b1020");
  } catch {
    // ignore
  }
}

export function getTelegramUser() {
  const twa = getTWA();
  try {
    const unsafe = twa?.initDataUnsafe;
    const user = unsafe?.user;
    if (!user) return null;
    return {
      id: user.id,
      first_name: user.first_name,
      last_name: user.last_name,
      username: user.username,
      language_code: user.language_code,
    };
  } catch {
    return null;
  }
}

export function getStartParam() {
  // Telegram can provide start parameter in different places:
  // - initDataUnsafe.start_param
  // - URL param tgWebAppStartParam
  try {
    const twa = getTWA();
    const sp = twa?.initDataUnsafe?.start_param;
    if (sp) return String(sp);
  } catch {}

  try {
    const url = new URL(window.location.href);
    const sp2 = url.searchParams.get("tgWebAppStartParam");
    if (sp2) return String(sp2);
  } catch {}

  return null;
}

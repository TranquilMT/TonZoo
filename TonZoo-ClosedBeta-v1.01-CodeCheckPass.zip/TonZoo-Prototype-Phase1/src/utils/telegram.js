export function getTg() {
  if (typeof window === "undefined") return null;
  return window.Telegram?.WebApp || null;
}

export function tgReady() {
  const tg = getTg();
  try { tg?.ready?.(); } catch {}
  try { tg?.expand?.(); } catch {}
  return tg;
}

export function tgHaptic(type = "impact", style = "light") {
  const tg = getTg();
  try {
    if (!tg?.HapticFeedback) return;
    if (type === "impact") tg.HapticFeedback.impactOccurred(style);
    if (type === "notification") tg.HapticFeedback.notificationOccurred(style);
    if (type === "selection") tg.HapticFeedback.selectionChanged();
  } catch {}
}

export function tgBackButton(show, onClick) {
  const tg = getTg();
  if (!tg?.BackButton) return () => {};
  try {
    if (show) tg.BackButton.show();
    else tg.BackButton.hide();
  } catch {}
  const handler = () => onClick?.();
  try { tg.onEvent?.("backButtonClicked", handler); } catch {}
  return () => { try { tg.offEvent?.("backButtonClicked", handler); } catch {} };
}

export function tgTheme() {
  const tg = getTg();
  const p = tg?.themeParams || {};
  const isDark = !!tg?.isDarkTheme;
  return { params: p, isDark };
}

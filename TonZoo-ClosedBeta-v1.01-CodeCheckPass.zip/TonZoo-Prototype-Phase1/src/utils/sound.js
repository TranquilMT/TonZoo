let ctx = null;

function ensure() {
  if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
  return ctx;
}

function tone(freq, dur=0.08, type="sine", gain=0.06) {
  const ac = ensure();
  const o = ac.createOscillator();
  const g = ac.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.value = gain;
  o.connect(g);
  g.connect(ac.destination);
  const t0 = ac.currentTime;
  g.gain.setValueAtTime(gain, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.start(t0);
  o.stop(t0 + dur + 0.02);
}

export function playClick() { tone(520, 0.05, "triangle", 0.05); }
export function playPop() { tone(740, 0.06, "sine", 0.055); }
export function playWin() { tone(880, 0.09, "square", 0.05); setTimeout(()=>tone(1040, 0.08, "square", 0.04), 60); }
export function playCelebrate() { tone(660, 0.08, "triangle", 0.045); setTimeout(()=>tone(990, 0.08, "triangle", 0.045), 70); setTimeout(()=>tone(1320, 0.09, "triangle", 0.04), 140); }

impfunction ensureVisitorsLoop(state){
  const now = Date.now();
  const today = dayKey(now);
  if (state.lastCheckInDay == null) state.lastCheckInDay = null;
  if (state.streakDay == null) state.streakDay = null;
  if (state.streakCount == null) state.streakCount = 0;
  if (state.marketingLevel == null) state.marketingLevel = 0;
  if (state.attractionLevel == null) state.attractionLevel = 0;
  if (state.marketingBoostUntil == null) state.marketingBoostUntil = 0;
  if (state.lastVisitorEventAt == null) state.lastVisitorEventAt = 0;
  // If streak day is far behind, reset
  if (state.streakDay && state.streakDay !== today){
    const yd = dayKey(now - 86400000);
    if (state.streakDay !== yd){
      state.streakCount = 0;
    }
  }
  return state;
}

function marketingUpgradeCost(level){
  const base = 250;
  return Math.floor(base * Math.pow(1.55, level));
}
function attractionUpgradeCost(level){
  const base = 400;
  return Math.floor(base * Math.pow(1.65, level));
}
function marketingBoostCost(){
  return 800;
}

function ensureAutoBuy(state){
  const today = dayKey(Date.now());
  if (state.autoBuyDay !== today){
    state.autoBuyDay = today;
    state.autoBuySpentToday = 0;
  }
  if (state.autoBuyDailyLimit == null) state.autoBuyDailyLimit = 3;
  return state;
}

function maybeAutoBuyPlan(state){
  if (!state.autoBuyPlan) return state;
  state = ensureAutoBuy(state);
  const plan = state.buyPlan || [];
  if (!plan.length) return state;

  const visitors = state.visitors || 0;
  let buysLeft = Math.max(0, (state.autoBuyDailyLimit || 0) - (state.autoBuySpentToday || 0));
  if (buysLeft <= 0) return state;

  // Try buy from last -> first? We'll buy first item in list that is affordable and not already owned
  for (const id of [...plan]){
    const owned = (state.ownedAnimals && (state.ownedAnimals[id] || 0) > 0);
    if (owned) continue;
    const cost = planCost(state, id);
    if (visitors >= cost){
      // perform buy using the same reducer action by dispatching internally is hard; replicate minimal buy logic here:
      // We'll invoke reducer by calling internal purchase helper if exists, else dispatch via ui action.
      // Since this is in reducer-less context, we can just enqueue an internal action via uiEvents, and the UI will offer a one-tap.
      // Better: apply a direct state mutation for auto-buy (simple & safe).
      state.visitors = visitors - cost;
      state.ownedAnimals = state.ownedAnimals || {};
      state.ownedAnimals[id] = (state.ownedAnimals[id] || 0) + 1;
      state.autoBuySpentToday = (state.autoBuySpentToday || 0) + 1;

      state = pushUiEvent(state, { type:"celebrate" });
      state = pushUiEvent(state, { type:"pop", variant:"green", text:"Auto-bought!" });
      state = pushIcon(state, { emoji:"🛒", text:String(id).replace("_"," ") });
      pushToast(state, `Auto-bought ${String(id).replace("_"," ")} from your Plan`);
      // remove from plan after buy
      state.buyPlan = (state.buyPlan || []).filter(x => x !== id);
      // unlock collections/synergy checks
      state = maybeUnlockCollections(state, Date.now());
      // only one auto-buy per tick to avoid bursts
      return state;
    }
  }
  return state;
}

function ensurePhase37(state){
  const now = Date.now();
  const today = dayKey(now);
  if (!state.collectionRewards) state.collectionRewards = {};
  state = normalizeCollections(state);
  if (state.featuredDay !== today || !state.featuredAnimalId){
    // pick a deterministic featured animal daily (non-deposit-only)
    const list = (state.shopAnimalIds && state.shopAnimalIds.length)
      ? state.shopAnimalIds
      : (typeof ANIMAL_IDS !== "undefined" ? ANIMAL_IDS : null);
    // We don't have catalog ids here; use ownedAnimals keys + a fallback fixed set
    const fallback = ["lion","penguin","crocodile","reptile","tiger","zebra","giraffe","seal","polar_bear","owl"];
    const pool = (list && Array.isArray(list) && list.length) ? list : fallback;
    let h = 0;
    const s = String(today);
    for (let i=0;i<s.length;i++) h = (h*31 + s.charCodeAt(i)) >>> 0;
    const pick = pool[h % pool.length];
    state.featuredDay = today;
    state.featuredAnimalId = pick;
  }
  return state;
}

function normalizeCollections(state){
  if (!state.collectionRewards) state.collectionRewards = {};
  const r = state.collectionRewards;
  Object.keys(r).forEach(k => {
    if (r[k] === true){
      r[k] = { unlockedAt: Date.now(), claimed: true, title: k, bonus: "" };
    } else if (typeof r[k] === "object" && r[k]){
      if (r[k].claimed == null) r[k].claimed = false;
      if (r[k].unlockedAt == null) r[k].unlockedAt = Date.now();
    }
  });
  return state;
}

function listSynergies(state){
  const owned = state.ownedAnimals || {};
  const has = (id) => (owned[id] || 0) > 0;
  const need = (ids) => ids.filter(id => !has(id));
  const make = (key, title, ids, mult, desc) => {
    const missing = need(ids);
    const active = missing.length === 0;
    return { key, title, ids, mult, desc, active, missing };
  };
  return [
    make("predator", "Predator Pack", ["lion","crocodile","reptile"], 1.08, "+8% visitors/day"),
    make("ice", "Ice Crew", ["penguin","seal","polar_bear"], 1.10, "+10% visitors/day"),
    make("savannah", "Savannah Set", ["lion","zebra","giraffe"], 1.06, "+6% visitors/day"),
    make("night", "Night Watch", ["owl","reptile"], 1.04, "+4% visitors/day"),
  ];
}

function bestSynergySuggestion(state){
  const list = listSynergies(state);
  const owned = state.ownedAnimals || {};
  const costOf = (id) => {
    // prices live in catalog at runtime in UI; here approximate with fallback
    const fallback = { lion:1200, crocodile:1150, reptile:850, penguin:900, seal:1050, polar_bear:1600, zebra:1000, giraffe:1100, owl:900, tiger:1400 };
    return fallback[id] || 1000;
  };
  const visitors = state.visitors || 0;
  // pick synergy with smallest missing count, tie -> cheapest next missing
  const candidates = list
    .filter(s => !s.active)
    .map(s => {
      const nextId = s.missing[0] || null;
      const nextCost = nextId ? costOf(nextId) : 999999;
      const canAfford = nextId ? visitors >= nextCost : false;
      return { ...s, nextId, nextCost, canAfford, missingCount: s.missing.length };
    })
    .sort((a,b) => (a.missingCount - b.missingCount) || (a.nextCost - b.nextCost));
  return candidates[0] || null;
}

function calcSynergyMult(state){
  // simple synergy calc based on owned animals
  const owned = state.ownedAnimals || {};
  const has = (id, n=1) => (owned[id] || 0) >= n;
  let mult = 1;
  // Predator Pack
  if (has("lion") && has("crocodile") && has("reptile")) mult *= 1.08;
  // Ice Crew
  if (has("penguin") && has("seal") && has("polar_bear")) mult *= 1.10;
  // Savannah Set
  if (has("zebra") && has("giraffe") && has("lion")) mult *= 1.06;
  // Night Watch
  if (has("owl") && has("reptile")) mult *= 1.04;
  return mult;
}
function planCost(state, id){
  const featuredId = state.featuredAnimalId;
  const fallback = { lion:1200, crocodile:1150, reptile:850, penguin:900, seal:1050, polar_bear:1600, zebra:1000, giraffe:1100, owl:900, tiger:1400 };
  let cost = fallback[id] || 1000;
  if (featuredId && id === featuredId) cost = Math.floor(cost * 0.9);
  return cost;
}

function updatePlanNotifications(state){
  const plan = state.buyPlan || [];
  const visitors = state.visitors || 0;
  if (!state.planNotified) state.planNotified = {};
  for (const id of plan){
    const cost = planCost(state, id);
    const key = String(id);
    const affordable = visitors >= cost;
    if (affordable && !state.planNotified[key]){
      state.planNotified[key] = true;
      state = pushUiEvent(state, { type:"pop", variant:"green", text:"Plan item affordable!" });
      state = pushIcon(state, { emoji:"✅", text:String(id).replace("_"," ") });
      pushToast(state, `You can now afford ${String(id).replace("_"," ")} — tap Buy in your Plan`);
    }
    if (!affordable){
      state.planNotified[key] = false;
    }
  }
  return state;
}

function recommendAnimals(state){
  // Recommendations based on ROI + synergy completion + affordability.
  const owned = state.ownedAnimals || {};
  const visitors = state.visitors || 0;
  const featuredId = state.featuredAnimalId;
  const fallback = [
    { id:"penguin", name:"Penguin", visitorsPerDay:150, priceVisitors:900 },
    { id:"reptile", name:"Reptile", visitorsPerDay:140, priceVisitors:850 },
    { id:"lion", name:"Lion", visitorsPerDay:220, priceVisitors:1200 },
    { id:"crocodile", name:"Crocodile", visitorsPerDay:190, priceVisitors:1150 },
    { id:"zebra", name:"Zebra", visitorsPerDay:160, priceVisitors:1000 },
    { id:"giraffe", name:"Giraffe", visitorsPerDay:180, priceVisitors:1100 },
    { id:"seal", name:"Seal", visitorsPerDay:170, priceVisitors:1050 },
    { id:"polar_bear", name:"Polar Bear", visitorsPerDay:260, priceVisitors:1600 },
    { id:"owl", name:"Owl", visitorsPerDay:150, priceVisitors:900 },
    { id:"tiger", name:"Tiger", visitorsPerDay:240, priceVisitors:1400 },
  ];
  const price = (a) => {
    let base = a.priceVisitors || 0;
    if (featuredId && a.id === featuredId) base = Math.floor(base * 0.9);
    return base;
  };
  const roi = (a) => {
    const c = Math.max(1, price(a));
    return (a.visitorsPerDay || 0) / c;
  };
  const notOwned = fallback.filter(a => (owned[a.id]||0) === 0);

  // Best ROI
  const bestRoi = [...notOwned].sort((a,b)=>roi(b)-roi(a))[0] || null;

  // Cheapest affordable upgrade
  const affordable = notOwned
    .map(a => ({...a, cost: price(a)}))
    .filter(a => visitors >= a.cost)
    .sort((a,b)=>a.cost-b.cost)[0] || null;

  // Synergy completion suggestion (from existing helper)
  const syn = bestSynergySuggestion(state);
  const synergyNext = syn && syn.nextId ? fallback.find(a=>a.id===syn.nextId) : null;

  const recs = [];
  if (bestRoi) recs.push({ type:"roi", tag:"Best ROI", ...bestRoi });
  if (synergyNext) recs.push({ type:"synergy", tag:`Complete ${syn.title}`, ...synergyNext });
  if (affordable) recs.push({ type:"affordable", tag:"Affordable now", ...affordable });

  // De-dup by id
  const seen = new Set();
  const out = [];
  for (const r of recs){
    if (!r || seen.has(r.id)) continue;
    seen.add(r.id);
    out.push(r);
  }
  return out;
}


function seededPick(arr, seedStr){
  let h = 2166136261 >>> 0;
  for (let i=0;i<seedStr.length;i++){
    h ^= seedStr.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return arr[h % arr.length];
}

function questTemplates(){
  return {
    entrance: [
      { type:"checkin", target: 1, title:"Do a daily check-in", reward:{ tickets: 120, boostMin: 15 } },
      { type:"visitorsEarn", target: 1200, title:"Earn 1,200 visitors", reward:{ tickets: 180, badge:"entrance" } },
    ],
    safari: [
      { type:"ownAny", ids:["lion","zebra","giraffe","tiger"], target: 1, title:"Own a Safari animal", reward:{ tickets: 220, boostMin: 30, badge:"safari" } },
      { type:"zoneLevel", zone:"safari", target: 2, title:"Upgrade Safari Zone to Lv.2", reward:{ tickets: 260, boostMin: 30 } },
      { type:"visitorsEarn", target: 2500, title:"Earn 2,500 visitors", reward:{ tickets: 260 } },
    ],
    arctic: [
      { type:"ownAny", ids:["penguin","seal","polar_bear"], target: 1, title:"Own an Arctic animal", reward:{ tickets: 220, boostMin: 30, badge:"arctic" } },
      { type:"zoneLevel", zone:"arctic", target: 2, title:"Upgrade Arctic Dome to Lv.2", reward:{ tickets: 280, boostMin: 30 } },
      { type:"visitorsEarn", target: 2800, title:"Earn 2,800 visitors", reward:{ tickets: 260 } },
    ],
    reptile_house: [
      { type:"ownAny", ids:["reptile","crocodile"], target: 1, title:"Own a Reptile animal", reward:{ tickets: 200, boostMin: 30, badge:"reptile_house" } },
      { type:"zoneLevel", zone:"reptile_house", target: 2, title:"Upgrade Reptile House to Lv.2", reward:{ tickets: 240, boostMin: 30 } },
      { type:"visitorsEarn", target: 2200, title:"Earn 2,200 visitors", reward:{ tickets: 240 } },
    ],
    aviary: [
      { type:"ownAny", ids:["owl","penguin"], target: 1, title:"Own a Bird (Owl/Penguin)", reward:{ tickets: 200, boostMin: 30, badge:"aviary" } },
      { type:"zoneLevel", zone:"aviary", target: 2, title:"Upgrade Aviary to Lv.2", reward:{ tickets: 240, boostMin: 30 } },
      { type:"visitorsEarn", target: 2200, title:"Earn 2,200 visitors", reward:{ tickets: 240 } },
    ],
  };
}

function makeQuestId(zoneId, idx, day){
  return `${zoneId}:${day}:${idx}`;
}

function ensureZoneQuests(state){
  if (!state.zoneQuests) state.zoneQuests = {};
  if (!state.zoneBadges) state.zoneBadges = {};
  if (state.zoneQuestBoostMult == null) state.zoneQuestBoostMult = 1;
  if (state.totalVisitorsEarned == null) state.totalVisitorsEarned = 0;

  const today = dayKey(Date.now());
  const dayChanged = state.zoneQuestsDay !== today;

  if (dayChanged){
    state.zoneQuestsDay = today;
    // generate 2 quests per zone each day
    const t = questTemplates();
    const defs = zoneDefs();
    for (const d of defs){
      const zoneId = d.id;
      const pool = t[zoneId] || [];
      if (!pool.length) continue;
      // deterministic picks based on day + zone
      const q1 = seededPick(pool, `${today}:${zoneId}:a`);
      const q2 = seededPick(pool, `${today}:${zoneId}:b`);
      const chosen = [q1, q2[0] === q1[0] ? pool[(pool.indexOf(q2)+1)%pool.length] : q2].slice(0,2);

      state.zoneQuests[zoneId] = chosen.map((q, i) => ({
        id: makeQuestId(zoneId, i, today),
        zoneId,
        type: q.type,
        ids: q.ids || null,
        zone: q.zone || zoneId,
        target: q.target,
        title: q.title,
        reward: q.reward || { tickets: 150 },
        claimed: false,
      }));
    }
  }

  // ensure zones exist
  state = ensureZones(state);
  return state;
}

function questProgress(state, q){
  const owned = state.ownedAnimals || {};
  const z = state.zones || {};
  if (q.type === "ownAny"){
    const ids = q.ids || [];
    return ids.reduce((acc,id)=>acc+((owned[id]||0)>0?1:0),0) >= 1 ? q.target : 0;
  }
  if (q.type === "zoneLevel"){
    const zoneId = q.zone || q.zoneId;
    const lvl = (z[zoneId] && z[zoneId].level) ? z[zoneId].level : 0;
    return Math.min(q.target, lvl);
  }
  if (q.type === "visitorsEarn"){
    return Math.min(q.target, Math.floor(state.totalVisitorsEarned || 0));
  }
  if (q.type === "checkin"){
    // daily check-in event sets lastCheckInDayKey; if equals today progress 1
    return state.lastCheckInDayKey === dayKey(Date.now()) ? 1 : 0;
  }
  return 0;
}

function isQuestComplete(state, q){
  return questProgress(state, q) >= (q.target || 1);
}

function cosmeticSetBonuses(state){
  const owned = state.cosmeticsOwned || {};
  const badges = state.zoneBadges || {};
  const eq = state.cosmeticsEquipped || {};
  const has = (id) => !!owned[id];
  const on = (slot, id) => eq && eq[slot] === id;

  const bonuses = {
    safari: { active: has("border_safari_gold") && !!badges.safari, equipped: on("border","border_safari_gold") },
    arctic: { active: has("border_arctic_ice") && !!badges.arctic, equipped: on("border","border_arctic_ice") },
    reptile_house: { active: has("border_reptile_neon") && !!badges.reptile_house, equipped: on("border","border_reptile_neon") },
    aviary: { active: has("border_aviary_sky") && !!badges.aviary, equipped: on("border","border_aviary_sky") },
    entrance: { active: has("nameplate_founder") && !!badges.entrance, equipped: on("nameplate","nameplate_founder") },
  };

  const anyActive = Object.values(bonuses).some(b => b.active);
  return { anyActive, bonuses };
}

function cosmeticsCatalog(){
  return [
    { id:"border_safari_gold", zone:"safari", slot:"border", name:"Safari Gold Border", emoji:"🦁", cost: 500, desc:"Gold border with safari vibe." },
    { id:"border_arctic_ice", zone:"arctic", slot:"border", name:"Arctic Ice Border", emoji:"🐧", cost: 500, desc:"Icy border glow." },
    { id:"border_reptile_neon", zone:"reptile_house", slot:"border", name:"Reptile Neon Border", emoji:"🐊", cost: 450, desc:"Neon green reptile frame." },
    { id:"border_aviary_sky", zone:"aviary", slot:"border", name:"Aviary Sky Border", emoji:"🦉", cost: 450, desc:"Sky blue feather frame." },
    { id:"nameplate_founder", zone:"entrance", slot:"nameplate", name:"Founder Nameplate", emoji:"🏛️", cost: 600, desc:"Clean premium nameplate." },
    { id:"icon_map_pin", zone:"entrance", slot:"profileIcon", name:"Map Pin Icon", emoji:"🗺️", cost: 350, desc:"Cute profile icon." },
  ];
}

function applyQuestReward(state, q){
  const now = Date.now();
  const r = q.reward || {};
  const tickets = Number(r.tickets || 0);
  if (tickets > 0) state.tickets = (state.tickets || 0) + tickets;
  // cosmetics currency
  const zt = Math.max(0, Math.floor(tickets * 0.35));
  state.zoneTickets = (state.zoneTickets || 0) + zt;

  const boostMin = Number(r.boostMin || 0);
  if (boostMin > 0){
    state.zoneQuestBoostMult = 1.10;
    state.zoneQuestBoostUntil = Math.max(state.zoneQuestBoostUntil || 0, now + boostMin * 60 * 1000);
  }
  if (r.badge){
    state.zoneBadges[r.badge] = true;
  }

  state = pushUiEvent(state, { type:"celebrate" });
  state = pushUiEvent(state, { type:"pop", variant:"green", text:`Quest claimed!` });
  if (tickets) state = pushIcon(state, { emoji:"🎟️", text:`+${tickets}` });
  if (boostMin) state = pushIcon(state, { emoji:"⚡", text:`+10% ${boostMin}m` });
  if (r.badge) state = pushIcon(state, { emoji:"🏅", text:"Badge" });
  pushToast(state, "Zone quest reward claimed!");
  return state;
}

function zoneDefs(){
  return [
    { id:"entrance", name:"Entrance Plaza", emoji:"🏛️", unlockCost: 0, baseBonus: 0.00, levelBonus: 0.01, maxLevel: 10, desc:"Core hub. Level it for small permanent bonuses." },
    { id:"safari", name:"Safari Zone", emoji:"🦁", unlockCost: 5000, baseBonus: 0.04, levelBonus: 0.015, maxLevel: 10, desc:"Big cats & savannah vibes. Boosts visitors/day." },
    { id:"arctic", name:"Arctic Dome", emoji:"🐧", unlockCost: 7000, baseBonus: 0.05, levelBonus: 0.015, maxLevel: 10, desc:"Penguins & polar friends. Boosts visitors/day." },
    { id:"reptile_house", name:"Reptile House", emoji:"🐊", unlockCost: 4500, baseBonus: 0.03, levelBonus: 0.012, maxLevel: 10, desc:"Cold-blooded collection. Boosts visitors/day." },
    { id:"aviary", name:"Aviary", emoji:"🦉", unlockCost: 5500, baseBonus: 0.035, levelBonus: 0.012, maxLevel: 10, desc:"Bird paradise. Boosts visitors/day." },
  ];
}

function ensureZones(state){
  if (!state.zones){
    state.zones = { entrance:{ unlocked:true, level:1 } };
  }
  const defs = zoneDefs();
  for (const d of defs){
    if (!state.zones[d.id]){
      state.zones[d.id] = { unlocked: d.id==="entrance", level: d.id==="entrance" ? 1 : 0 };
    }
  }
  return state;
}

function zoneMult(state){
  const z = state.zones || {};
  const defs = zoneDefs();
  let mult = 1;
  for (const d of defs){
    const s = z[d.id];
    if (!s || !s.unlocked) continue;
    const lvl = Math.max(0, Number(s.level || 0));
    const bonus = (d.baseBonus || 0) + (d.levelBonus || 0) * Math.max(0, lvl-1);
    mult *= (1 + bonus);
  }
  return mult;
}

function zoneUnlockRequirements(state, zoneId){
  // simple gating by owned animals types: safari needs lion or zebra, arctic needs penguin, reptile_house needs reptile/croc, aviary needs owl/penguin
  const owned = state.ownedAnimals || {};
  const hasAny = (ids) => ids.some(id => (owned[id]||0)>0);
  if (zoneId==="safari") return { ok: hasAny(["lion","zebra","giraffe","tiger"]), text:"Requires owning a Safari animal (Lion/Zebra/Giraffe/Tiger)." };
  if (zoneId==="arctic") return { ok: hasAny(["penguin","seal","polar_bear"]), text:"Requires owning an Arctic animal (Penguin/Seal/Polar Bear)." };
  if (zoneId==="reptile_house") return { ok: hasAny(["reptile","crocodile"]), text:"Requires owning a Reptile animal (Reptile/Crocodile)." };
  if (zoneId==="aviary") return { ok: hasAny(["owl","penguin"]), text:"Requires owning a Bird (Owl/Penguin)." };
  return { ok: true, text:"" };
}

function zoneUpgradeCost(zoneId, nextLevel){
  // cost in visitors; scales
  const base = { entrance: 1200, safari: 2400, arctic: 2600, reptile_house: 2000, aviary: 2100 }[zoneId] || 2000;
  return Math.floor(base * Math.pow(1.35, Math.max(0,nextLevel-1)));
}

function calcCollectionMult(state){
  const owned = state.ownedAnimals || {};
  let mult = 1;
  // Collection bonuses (permanent once unlocked; stored in collectionRewards)
  const r = state.collectionRewards || {};
  if (r.reptile_3) mult *= 1.02;
  if (r.birds_3) mult *= 1.02;
  if (r.bigcats_3) mult *= 1.03;
  return mult;
}

function maybeUnlockCollections(state, now){
  const owned = state.ownedAnimals || {};
  const r = state.collectionRewards || (state.collectionRewards = {});
  const countIds = (ids) => ids.reduce((acc,id)=>acc+(owned[id]||0),0);

  const newly = [];
  const mark = (key, title, bonus) => {
    if (!r[key]) r[key] = { unlockedAt: now, claimed: false, title, bonus };
    if (r[key].claimed) return;
    newly.push({ key, title, bonus });
  };

  if (countIds(["reptile","crocodile"]) >= 3) mark("reptile_3", "Reptile Collector", "+2% visitors/day");
  if (countIds(["penguin","owl"]) >= 3) mark("birds_3", "Bird Keeper", "+2% visitors/day");
  if (countIds(["lion","tiger"]) >= 3) mark("bigcats_3", "Big Cats", "+3% visitors/day");

  if (newly.length){
    // notify player to claim
    state = pushUiEvent(state, { type:"pop", variant:"pink", text:"Collection unlocked!" });
    state = pushIcon(state, { emoji:"🏆", text:"Claim reward" });
    newly.forEach(n => pushToast(state, `${n.title} unlocked — ${n.bonus} (tap Claim)`));
  }
  return state;
}

function ensureTicketExchange(state){
  const today = dayKey(Date.now());
  if (state.ticketExchangeDay == null) state.ticketExchangeDay = today;
  if (state.ticketExchangeUsed == null) state.ticketExchangeUsed = 0;
  if (state.ticketExchangeDay !== today){
    state.ticketExchangeDay = today;
    state.ticketExchangeUsed = 0;
  }
  return state;
}

function ticketExchangeRateCoins(tickets){
  // 1000 tickets -> 100 coinsPurchase
  return Math.floor((tickets / 1000) * 100);
}

ort React, { useEffect, useMemo, useReducer } from "react";
import { PAVILIONS, ANIMALS } from "../data/catalog";
import { RARITY_MULT, RARITY_PRESTIGE, PRESTIGE_RANKS } from "../data/rarities";
import { DAILY_TASKS, ONETIME_TASKS } from "../data/tasks";
import { BOOSTERS } from "../data/boosters";
import { AUCTION_DURATION_MS, AUCTION_ITEMS } from "../data/auction";
import { nowMs } from "../lib/time";

const LS_KEY = "tonzoo_v59_state";
const API_BASE = import.meta?.env?.VITE_API_BASE || "http://localhost:8787";
const DAY_MS = 24 * 60 * 60 * 1000;

const REF_MILESTONES = [
  { k: 1, title: "Invite 1 friend", reward: { visitors: 500 } },
  { k: 5, title: "Invite 5 friends", reward: { tickets: 5000 } },
  { k: 10, title: "Invite 10 friends", reward: { coinsPurchase: 300 } },
  { k: 25, title: "Invite 25 friends", reward: { visitors: 3000, tickets: 15000 } },
  { k: 50, title: "Invite 50 friends", reward: { coinsPurchase: 1500, tickets: 30000 } },
];

const initial = {
  coinsPurchase: 0,
  coinsWithdraw: 0,
  tickets: 0,
  visitors: 180,

  ownedPavilions: {},
  ownedAnimals: {},

  // Phase 24: Zoo pens + progression
  zooSlots: Array.from({ length: 6 }).map((_, i) => ({ slotId: i, unlocked: i < 2, animalId: null })),
  animalLevels: {},
  shopAnimalIds: null,
  shopRerollDay: null,
  shopRerollsToday: 0,
  upkeepPaidThroughDay: null,
  // Phase 35 visitors loop
  lastCheckInDay: null,
  streakDay: null,
  streakCount: 0,
  marketingLevel: 0,
  attractionLevel: 0,
  marketingBoostUntil: 0,
  lastVisitorEventAt: 0,
  // Phase 37
  featuredDay: null,
  featuredAnimalId: null,
  collectionRewards: {},
  buyPlan: [],
  planNotified: {},
  autoBuyPlan: false,
  autoBuyDailyLimit: 3,
  autoBuySpentToday: 0,
  // Phase 44
  // Phase 45
  zoneQuestsDay: null,
  zoneQuests: {},
  zoneBadges: {},
  zoneQuestBoostUntil: 0,
  zoneQuestBoostMult: 1,
  zoneTickets: 0,
  cosmeticsOwned: {},
  cosmeticsEquipped: { border: null, nameplate: null, profileIcon: null },
  cosmeticPresets: {
    p1: { name: "Preset 1", slots: { border: null, nameplate: null, profileIcon: null } },
    p2: { name: "Preset 2", slots: { border: null, nameplate: null, profileIcon: null } },
    p3: { name: "Preset 3", slots: { border: null, nameplate: null, profileIcon: null } },
  },


  totalVisitorsEarned: 0,

  zones: {
    entrance: { unlocked: true, level: 1 },
    safari: { unlocked: false, level: 0 },
    arctic: { unlocked: false, level: 0 },
    reptile_house: { unlocked: false, level: 0 },
    aviary: { unlocked: false, level: 0 },
  },

  autoBuyDay: null,




  ticketExchangeDay: null,
  ticketExchangeUsed: 0,

  offlineCapMs: 8 * 60 * 60 * 1000,



  lastAccrueAt: nowMs(),
  lastActiveAt: Date.now(),

  withdrawals: [],

  lastGameResult: null,
  freeWheelSpins: 0,

  activeBoosters: [],

  dailyResetAt: nowMs(),
  dailyProgress: {},
  dailyClaimed: {},
  oneProgress: {},
  oneClaimed: {},
  dailyVisitorsGained: 0,

  // Auction
  auction: null,
  auctionHistory: [],
  rareAnimalVouchers: 0,

  deposits: [],
  depositIntents: {},
  lastDepositCheckAt: 0,
  depositUsdTotal: 0,

  // Treasury system (Phase A)
  treasuryUsd: 0,
  profitUsd: 0,
  bufferUsd: 0,
  treasurySplit: { treasury: 0.60, profit: 0.30, buffer: 0.10 },
  withdrawalsPaused: false,
  withdrawFeePct: 0.05,
  withdrawDelayMs: 24 * 60 * 60 * 1000,
  withdrawDailyCapUsd: 10,
  withdrawWeeklyCapUsd: 50,
  withdrawalsPaidUsdToday: 0,
  withdrawalsPaidUsdWeek: 0,
  lastWithdrawCapDay: dayKey(),
  lastWithdrawCapWeek: weekKey(),

  // UI FX + onboarding
  uiEvents: [],
  onboarding: { step: 1 },
  tutorialSeen: false,
  soundOn: true,

  // Achievements
  achievements: {},
  achievementsClaimed: {},
  lastBought: { kind: null, id: null, at: 0 },

  // Daily / Offline / Missions
  dailyLogin: { lastDay: null, streak: 0 },
  missions: {
    daily: [
      { id: "buy_animal", title: "Buy 1 animal", goal: 1, progress: 0, reward: { tickets: 500 } },
      { id: "play_game", title: "Play 3 games", goal: 3, progress: 0, reward: { tickets: 800 } },
    ],
    weekly: []
  },

  // Deposit gate
  hasDeposited: false,
  bonusAnimalClaimed: false,

  // Events / leaderboard
  playerName: "",
  userId: "local",
  referrerId: null,
  referralPendingCoins: 0,
  referralInvitedCount: 0,
  eventState: { endsAt: Date.now() + 1000 * 60 * 60 * 24 * 3, passOwned: false, weeklyKey: weekKey(), leaderboardSeed: 1337 },
  eventPoints: 0,
  eventTrack: {
    tiers: [
      { t: 1, need: 200, free: { tickets: 400 }, pass: { tickets: 800 } },
      { t: 2, need: 500, free: { tickets: 600 }, pass: { tickets: 1200 } },
      { t: 3, need: 900, free: { tickets: 900 }, pass: { tickets: 1800 } },
      { t: 4, need: 1400, free: { tickets: 1200 }, pass: { tickets: 2400 } },
      { t: 5, need: 2000, free: { tickets: 1800 }, pass: { tickets: 3600 } }
    ],
    claimedFree: {},
    claimedPass: {}
  },
  eventQuests: {
    dailyKey: dayKey(),
    list: [
      { id: "eq_buy", title: "Buy 1 animal", goal: 1, progress: 0, rewardPts: 120, claimed: false },
      { id: "eq_play", title: "Play 5 games", goal: 5, progress: 0, rewardPts: 180, claimed: false },
      { id: "eq_claim", title: "Claim 1 mission", goal: 1, progress: 0, rewardPts: 120, claimed: false },
    ]
  },
  inbox: [],

  // Referrals (prototype)
  referral: {
    code: null,
    invited: 0,
    active: 0,
    claimed: {},
  },
  referredBy: null,
};

function loadState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return initial;
    const parsed = JSON.parse(raw);
    return ensureReferralCode({ ...initial, ...parsed });
  } catch {
    return ensureReferralCode(initial);
  }
}


function saveState(s) {
  localStorage.setItem(LS_KEY, JSON.stringify(s));
}


function weekKey(ts = Date.now()) {
  const d = new Date(ts);
  const day = (d.getUTCDay() + 6) % 7; // Mon=0
  const monday = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - day));
  return `${monday.getUTCFullYear()}-${monday.getUTCMonth()+1}-${monday.getUTCDate()}`;
}

function dayKey(ts = Date.now()) {
  const d = new Date(ts);
  return `${d.getUTCFullYear()}-${d.getUTCMonth()+1}-${d.getUTCDate()}`;
}



function summonEvent(state, kind, id) {
  return pushUiEvent(state, { type: "summon", kind, id });
}


function addInbox(state, item) {
  return { ...state, inbox: [item, ...(state.inbox || [])].slice(0, 20) };
}

function unlockAchievement(state, id, title) {
  if (state.achievements?.[id]) return state;
  let next = { ...state, achievements: { ...(state.achievements || {}), [id]: true } };
  next = pushUiEvent(next, { type: "achievement", title, id });
  next = pushUiEvent(next, { type: "celebrate" });
  return next;
}

function pushIcon(state, { emoji, text }) {
  return pushUiEvent(state, { type: "icon", emoji, text });
}

function pushUiEvent(state, ev) {
  const e = { id: (action.id || (crypto.randomUUID?.() || String(Math.random()))), at: nowMs(), ...ev };
  const next = { ...state, uiEvents: [ ...(state.uiEvents || []), e ].slice(-8) };
  return next;
}

function ensureReferralCode(state) {
  const existing = state?.referral?.code;
  if (existing) return state;
  const code = ("TZ" + Math.random().toString(36).slice(2, 8)).toUpperCase();
  return { 
    ...state,
    referral: { ...(state.referral || {}), code }
  };
}

function detectReferrerId(){
  try{
    const tg = window?.Telegram?.WebApp;
    const sp = tg?.initDataUnsafe?.start_param || tg?.initDataUnsafe?.startParam;
    if (!sp) return null;
    const s = String(sp);
    if (s.startsWith("ref_")) return s.slice(4);
  }catch{}
  return null;
}

function detectUserId(){
  try{
    const tg = window?.Telegram?.WebApp;
    const id = tg?.initDataUnsafe?.user?.id;
    if (id) return String(id);
  }catch{}
  return "local";
}

function ensureZooSystems(state){
  if (!state.zooSlots) {
    state.zooSlots = Array.from({ length: 6 }).map((_, i) => ({
      slotId: i,
      unlocked: i < 2, // start with 2 unlocked
      animalId: null,
    }));
  }
  if (!state.animalLevels) state.animalLevels = {};
  return state;
}

function placedCounts(state){
  const m = {};
  for(const sl of state.zooSlots || []){
    if(!sl?.animalId) continue;
    m[sl.animalId] = (m[sl.animalId]||0)+1;
  }
  return m;
}

function levelFor(state, animalId){
  return Math.max(1, Number(state.animalLevels?.[animalId] || 1));
}

function levelUpCostCoins(animalId, nextLevel){
  const base = 200;
  return Math.floor(base * Math.pow(nextLevel, 1.35));
}

function unlockSlotCostCoins(slotId){
  // slotId 0-1 are free, starting from 2 cost grows
  const idx = Math.max(0, slotId - 1);
  return Math.floor(1500 * Math.pow(idx, 1.35));
}

function ticketsPerHourTotal(state) {
  let total = 0;
  for (const p of PAVILIONS) {
    const count = state.ownedPavilions[p.id] || 0;
    total += p.ticketsPerHour * count;
  }
  const upMult = upkeepMultiplier(state, now || Date.now());
  return total * upMult;
}

function visitorsPerDayTotal(state, now) {
  state = ensureZooSystems(state);
  state = ensureShop(state);
  if (state.upkeepPaidThroughDay == null) state.upkeepPaidThroughDay = dayKey(now);

  const placed = (state.zooSlots || []).filter(s => s.unlocked && s.animalId);
  let total = 0;

  for (const slot of placed) {
    const def = ANIMALS.find(a => a.id === slot.animalId);
    if (!def) continue;

    const tier = def.rarityTier || "common";
    const rarityMult = RARITY_MULT[tier] ?? 1;

    const lvl = levelFor(state, def.id);
    const levelMult = 1 + (lvl - 1) * 0.15;

    total += (def.visitorsPerDay || 0) * rarityMult * levelMult;
  }

  // Upgrades + boost
  const attractionMult = 1 + (state.attractionLevel || 0) * 0.08;
  const synergyMult = calcSynergyMult(state);
  const collectionMult = calcCollectionMult(state);
  const featuredOwned = (state.ownedAnimals && state.featuredAnimalId) ? ((state.ownedAnimals[state.featuredAnimalId] || 0) > 0) : false;
  const featuredMult = featuredOwned ? 1.05 : 1;
  const zonesMult = zoneMult(state);
  const questBoostMult = (state.zoneQuestBoostUntil && Date.now() < state.zoneQuestBoostUntil) ? (state.zoneQuestBoostMult || 1.10) : 1;
  const marketingMult = (state.marketingBoostUntil && now < state.marketingBoostUntil) ? 1.35 : 1;
  const streakMult = 1 + Math.min(10, (state.streakCount || 0)) * 0.02;
  return total * attractionMult * marketingMult * streakMult * synergyMult * collectionMult * featuredMult * zonesMult * questBoostMult;
}

function activeEffects(state, now) {
  let ticketsMult = 1;
  let visitorsMult = 1;

  for (const b of state.activeBoosters || []) {
    if (b.expiresAt && now > b.expiresAt) continue;
    if (b.effect?.ticketsMult) ticketsMult *= b.effect.ticketsMult;
    if (b.effect?.visitorsMult) visitorsMult *= b.effect.visitorsMult;
  }

  let offlineCapMult = 1;
  for (const b of state.activeBoosters || []) {
    if (b.expiresAt && now > b.expiresAt) continue;
    if (b.effect?.offlineCapMult) offlineCapMult *= b.effect.offlineCapMult;
  }
  return { ticketsMult, visitorsMult, offlineCapMult };
}

function expireBoosters(state, now) {
  const keep = (state.activeBoosters || []).filter((b) => !b.expiresAt || now <= b.expiresAt);
  if (keep.length === (state.activeBoosters || []).length) return state;
  return { ...state, activeBoosters: keep };
}

function resetDailyIfNeeded(state, now) {
  const resetAt = state.dailyResetAt || now;
  if (now - resetAt < DAY_MS) return state;

  return {
    ...state,
    dailyResetAt: now,
    dailyProgress: {},
    dailyClaimed: {},
    dailyVisitorsGained: 0,
  };
}

function accrue(state, now) {
  state = resetDailyIfNeeded(state, now);
  state = expireBoosters(state, now);
  state = advanceAuction(state, now);

  const last = state.lastAccrueAt || now;
  const dtMsRaw = Math.max(0, now - last);
  
  const maxOffline = (state.offlineCapMs || (8 * 60 * 60 * 1000)) * (eff.offlineCapMult || 1);
  const dtMs = Math.min(dtMsRaw, maxOffline);

  const tph = ticketsPerHourTotal(state);
  const vpd = visitorsPerDayTotal(state, now);

  const eff = activeEffects(state, now);

  const ticketsAdd = (tph / 3600000) * dtMs * eff.ticketsMult;
  const visitorsAdd = (vpd / 86400000) * dtMs * eff.visitorsMult;

  const dailyVisitorsGained = (state.dailyVisitorsGained || 0) + visitorsAdd;

  return {
    ...state,
    tickets: state.tickets + ticketsAdd,
    visitors: state.visitors + visitorsAdd,
    dailyVisitorsGained,
    lastAccrueAt: now,
  };
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function bumpCounter(mapObj, key, by = 1) {
  return { ...mapObj, [key]: (mapObj?.[key] || 0) + by };
}

function applyReward(state, reward) {
  const r = reward || {};
  let next = {
    ...state,
    tickets: state.tickets + (r.tickets || 0),
    visitors: state.visitors + (r.visitors || 0),
    coinsPurchase: state.coinsPurchase + (r.coinsPurchase || 0),
  };

  if (r.rareAnimalVoucher) {
    next.rareAnimalVouchers = (next.rareAnimalVouchers || 0) + r.rareAnimalVoucher;
  }

  return next;
}

function pickAuctionItem(seed = 0) {
  const idx = Math.abs(seed) % AUCTION_ITEMS.length;
  return AUCTION_ITEMS[idx];
}

function startNewAuction(state, now) {
  const seed = (state.auctionHistory?.length || 0) + Math.floor(now / 1000);
  const item = pickAuctionItem(seed);

  const baseBid = randInt(100, 350);
  return {
    ...state,
    auction: {
      id: "auc_" + (crypto.randomUUID?.() || String(Math.random())),
      startsAt: now,
      endsAt: now + AUCTION_DURATION_MS,
      itemId: item.id,
      itemTitle: item.title,
      itemDesc: item.desc,
      itemBadge: item.badge,
      reward: item.reward,
      highestBid: baseBid,
      highestBidder: "bot",
      yourBid: 0,
      minIncrement: 25,
      lastBotBidAt: now,
      settled: false,
    },
  };
}

function settleAuction(state, auction, now) {
  // Refund rule: if you lose, refund 80% of your bid.
  // If you win, no refund; you keep the reward.
  const youWon = auction.highestBidder === "you";
  let next = { ...state };

  if (youWon) {
    next = applyReward(next, auction.reward);
    next = pushUiEvent(next, { type: "toast", title: "Auction won", body: auction.itemTitle });
    next = pushUiEvent(next, { type: "celebrate" });
  } else {
    const refund = Math.floor((auction.yourBid || 0) * 0.8);
    next.visitors += refund;
    next = pushUiEvent(next, { type: "pop", variant: "blue", text: `Auction lost` });
    next = pushIcon(next, { emoji: "👥", text: `Refund +${refund}` });
  }

  next.auctionHistory = [
    ...(next.auctionHistory || []),
    {
      id: auction.id,
      itemId: auction.itemId,
      itemTitle: auction.itemTitle,
      itemBadge: auction.itemBadge,
      finalBid: auction.highestBid,
      winner: auction.highestBidder === "you" ? "you" : "bot",
      endedAt: now,
    },
  ];

  next.auction = null;
  return next;
}

function maybeBotBid(auction, now) {
  // Bot bids every 6-14 seconds, with some randomness.
  const elapsed = now - (auction.lastBotBidAt || auction.startsAt);
  const interval = randInt(6000, 14000);
  if (elapsed < interval) return auction;
  if (now >= auction.endsAt) return auction;

  // If bot already winning, sometimes chill.
  const chill = randInt(1, 100) <= 35;
  if (auction.highestBidder === "bot" && chill) {
    return { ...auction, lastBotBidAt: now };
  }

  const inc = auction.minIncrement || 25;
  const extra = randInt(0, 6) * inc;
  const newBid = auction.highestBid + inc + extra;

  return {
    ...auction,
    highestBid: newBid,
    highestBidder: "bot",
    lastBotBidAt: now,
  };
}

function advanceAuction(state, now) {
  // ensure auction exists
  if (!state.auction) {
    return startNewAuction(state, now);
  }

  const a = state.auction;

  // If ended and not settled -> settle and start next after short delay (we start immediately for prototype)
  if (now >= a.endsAt) {
    return startNewAuction(settleAuction(state, a, now), now);
  }

  // update bot bids
  const nextA = maybeBotBid(a, now);
  if (nextA === a) return state;
  return { ...state, auction: nextA };
}

function reducer(state, action) {
  const now = nowMs();
  let s = accrue(state, now);

  
switch (action.type) {

    case "APP_BOOT": {
      let next = { ...s };
      const now = Date.now();

      // Offline progress (tickets per hour)
      const hoursAway = Math.max(0, (now - (s.lastActiveAt || now)) / 36e5);
      if (hoursAway > 0.05) {
        const mult = (s.eventState?.passOwned) ? 1.1 : 1.0;
      const ticketsGained = Math.floor(hoursAway * (s.ticketsPerHour || 0) * mult);
        if (ticketsGained > 0) {
          next.tickets += ticketsGained;
          next = pushUiEvent(next, { type: "toast", title: "Offline progress", body: `+${ticketsGained} tickets while away` });
          next = pushIcon(next, { emoji: "🎟️", text: `+${ticketsGained}` });
        }
      }

      // Weekly reset (leaderboard)
      const wk = weekKey(now);
      if ((s.eventState?.weeklyKey || wk) !== wk) {
        // Determine last week's rank (approx) and grant prizes (prototype)
        const playerScore = s.visitors || 0;
        const seed = (s.eventState?.leaderboardSeed || 1337) + playerScore;
        let x = seed % 2147483647; if (x<=0) x += 2147483646;
        const rnd = () => (x = (x * 16807) % 2147483647) / 2147483647;
        const base = Math.max(500, Math.floor(playerScore * 1.2));
        const bots = Array.from({length:7}).map((_,i)=> (base + Math.floor(rnd()*2500) + i*120));
        const all = bots.concat([playerScore]).sort((a,b)=>b-a);
        const rank = all.indexOf(playerScore) + 1;

        let prize = 0;
        if (rank === 1) prize = 4000;
        else if (rank === 2) prize = 2500;
        else if (rank === 3) prize = 1500;
        else if (rank <= 8) prize = 600;

        if (prize > 0) {
          next = addInbox(next, { id: "lb_" + (s.eventState?.weeklyKey || "wk"), title: "Leaderboard Prize", body: `Rank #${rank} — +${prize} tickets`, tickets: prize, createdAt: now });
          next = pushUiEvent(next, { type: "toast", title: "Weekly prize", body: `Rank #${rank} reward added to Inbox` });
        }

        next.eventState = { ...(next.eventState || {}), weeklyKey: wk, leaderboardSeed: Math.floor(Math.random()*999999) };
        next = pushUiEvent(next, { type: "toast", title: "Weekly reset", body: "Leaderboard refreshed" });
      }

      // withdraw cap reset
      const dk2 = dayKey(now);
      const wk2 = weekKey(now);
      if ((s.lastWithdrawCapDay || dk2) !== dk2) {
        next.withdrawalsPaidUsdToday = 0;
        next.lastWithdrawCapDay = dk2;
      }
      if ((s.lastWithdrawCapWeek || wk2) !== wk2) {
        next.withdrawalsPaidUsdWeek = 0;
        next.lastWithdrawCapWeek = wk2;
      }

      // Event quests reset (daily)
      const dk = dayKey(now);
      if ((s.eventQuests?.dailyKey || dk) !== dk) {
        next.eventQuests = {
          dailyKey: dk,
          list: [
            { id: "eq_buy", title: "Buy 1 animal", goal: 1, progress: 0, rewardPts: 120, claimed: false },
            { id: "eq_play", title: "Play 5 games", goal: 5, progress: 0, rewardPts: 180, claimed: false },
            { id: "eq_claim", title: "Claim 1 mission", goal: 1, progress: 0, rewardPts: 120, claimed: false }
          ]
        };
        next = pushUiEvent(next, { type: "toast", title: "Event quests", body: "New daily quests available" });
      }

      // Daily login
      const today = dayKey(now);
      if (s.dailyLogin.lastDay !== today) {
        const streak = s.dailyLogin.lastDay ? s.dailyLogin.streak + 1 : 1;
        next.dailyLogin = { lastDay: today, streak };
        const reward = 300 + Math.min(7, streak) * 200;
        next.tickets += reward;
        next = pushUiEvent(next, { type: "toast", title: `Daily login Day ${streak}`, body: `+${reward} tickets` });
        next = pushIcon(next, { emoji: "🔥", text: `Streak ${streak}` });
        if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      }

      next.lastActiveAt = now;
      return next;
    }


    case "ACK_UI_EVENT": {
      const id = action.id;
      if (!id) return s;
      return { ...s, uiEvents: (s.uiEvents || []).filter((e) => e.id !== id) };
    }

    case "ADVANCE_ONBOARDING": {
      const step = (s.onboarding?.step || 0) + 1;
      return { ...s, onboarding: { step } };
    }

    case "CLAIM_ACHIEVEMENT": {
      const { id } = action;
      if (!id) return s;
      if (!s.achievements?.[id]) return s;
      if (s.achievementsClaimed?.[id]) return s;
      // simple rewards
      const reward = (id === "big_win") ? 1500 : 600;
      let next = { ...s, tickets: s.tickets + reward, achievementsClaimed: { ...(s.achievementsClaimed||{}), [id]: true } };
      next = pushUiEvent(next, { type: "toast", title: "Achievement claimed", body: `+${reward} tickets` });
      next = pushIcon(next, { emoji: "🏆", text: `+${reward}` });
      return next;
    }

    
case "SET_PLAYER_NAME": {
      const name = (action.name || "").slice(0, 16);
      return { ...s, playerName: name };
    }

    case "BUY_EVENT_PASS": {
      const price = Number(action.priceUsd) || 3;
      if ((s.depositUsdTotal || 0) < price) {
        let out = pushUiEvent(s, { type: "toast", title: "Event Pass", body: `Deposit $${price} total to buy pass.` });
        out = pushIcon(out, { emoji: "💎", text: `$${price}` });
        return out;
      }
      let next = { ...s, eventState: { ...(s.eventState || {}), passOwned: true } };
      next = pushUiEvent(next, { type: "toast", title: "Event Pass", body: "Pass activated (+10% tickets)" });
      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      return next;
    }

    case "BUY_EVENT_ANIMAL": {
      const id = action.id;
      const price = Number(action.priceVisitors) || 950;
      const now = Date.now();
      if (now > (s.eventState?.endsAt || 0)) {
        return pushUiEvent(s, { type: "toast", title: "Event ended", body: "This animal is no longer available." });
      }
      if (s.visitors < price) return s;
      let next = { ...s, visitors: s.visitors - price };
      next.ownedAnimals = { ...(s.ownedAnimals || {}), [id]: (s.ownedAnimals?.[id] || 0) + 1 };
      next.lastBought = { kind: "animal", id, at: now };
      let out = summonEvent(next, "animal", id);
      out = pushUiEvent(out, { type: "toast", title: "Limited animal bought", body: "Neon Fox joined your zoo" });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

    case "CLAIM_INBOX": {
      const id = action.id;
      const item = (s.inbox || []).find((x) => x.id === id);
      if (!item) return s;
      let next = { ...s, inbox: (s.inbox || []).filter((x) => x.id !== id) };
      if (item.tickets) {
        next.tickets += item.tickets;
        next = pushIcon(next, { emoji: "📬", text: `+${item.tickets}` });
      }
      next = pushUiEvent(next, { type: "toast", title: "Claimed", body: item.title });
      return next;
    }

    case "CLAIM_EVENT_QUEST": {
      const id = action.id;
      const q = (s.eventQuests?.list || []).find((x) => x.id === id);
      if (!q || q.claimed || q.progress < q.goal) return s;
      let next = { ...s };
      next.eventPoints = (s.eventPoints || 0) + (q.rewardPts || 0);
      next.eventQuests = { ...s.eventQuests, list: (s.eventQuests?.list || []).map((x) => (x.id === id ? { ...x, claimed: true } : x)) };
      next = pushUiEvent(next, { type: "toast", title: "Quest complete", body: `+${q.rewardPts} event points` });
      next = pushIcon(next, { emoji: "✨", text: `+${q.rewardPts}` });
      return next;
    }

    case "CLAIM_TRACK_TIER": {
      const tier = Number(action.tier);
      const isPass = !!action.isPass;
      const t = (s.eventTrack?.tiers || []).find((x) => x.t === tier);
      if (!t) return s;
      if ((s.eventPoints || 0) < t.need) return s;

      const claimedMap = isPass ? (s.eventTrack?.claimedPass || {}) : (s.eventTrack?.claimedFree || {});
      if (claimedMap[tier]) return s;
      if (isPass && !s.eventState?.passOwned) return s;

      const reward = isPass ? t.pass : t.free;
      let next = { ...s };
      if (reward?.tickets) next.tickets += reward.tickets;

      next.eventTrack = {
        ...s.eventTrack,
        claimedFree: isPass ? (s.eventTrack?.claimedFree || {}) : { ...(s.eventTrack?.claimedFree || {}), [tier]: true },
        claimedPass: isPass ? { ...(s.eventTrack?.claimedPass || {}), [tier]: true } : (s.eventTrack?.claimedPass || {}),
      };

      next = pushUiEvent(next, { type: "toast", title: "Track reward", body: `Tier ${tier} claimed` });
      next = pushIcon(next, { emoji: isPass ? "💎" : "🎁", text: `+${reward?.tickets || 0}` });
      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      return next;
    }

    case "CREATE_DEPOSIT_INTENT": {
      const dep = action.deposit;
      const pay = action.pay;
      if (!dep?.id) return s;
      const intents = { ...(s.depositIntents || {}), [dep.id]: { ...dep, pay } };
      let out = { ...s, depositIntents: intents };
      out = pushUiEvent(out, { type: "toast", title: "Deposit created", body: `Send with comment TONZOO:${dep.id}` });
      return out;
    }

    case "APPLY_CONFIRMED_DEPOSITS": {
      const list = action.confirmed || [];
      if (!Array.isArray(list) || list.length === 0) return s;
      let next = { ...s, lastDepositCheckAt: Date.now() };

      for (const dep of list) {
        if (!dep?.id) continue;
        // prevent double apply
        if ((next.deposits || []).some((d) => d.id === dep.id && d.status === "Confirmed")) continue;

        const usd = Math.max(1, Number(dep.usd) || 1);
        const ssplit = (dep.split || null);
        const tAdd = ssplit ? Number(ssplit.tAdd||0) : (usd * (split.treasury ?? 0.6));
        const pAdd = ssplit ? Number(ssplit.pAdd||0) : (usd * (split.profit ?? 0.3));
        const bAdd = ssplit ? Number(ssplit.bAdd||0) : (usd * (split.buffer ?? 0.1));
        const coinsAdd = ssplit ? Math.floor(Number(ssplit.coinsAdd||0)) : Math.floor(usd * 1000);

        next.deposits = [...(next.deposits || []), { ...dep, status: "Confirmed" }];
        next.hasDeposited = true;
        next.depositUsdTotal = (next.depositUsdTotal || 0) + usd;
        next.treasuryUsd = (next.treasuryUsd || 0) + tAdd;
        next.profitUsd = (next.profitUsd || 0) + pAdd;
        next.bufferUsd = (next.bufferUsd || 0) + bAdd;
        next.coinsPurchase = (next.coinsPurchase || 0) + coinsAdd;
        next.coins = (next.coins || 0) + coinsAdd;
      }

      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      next = pushUiEvent(next, { type: "toast", title: "Deposit confirmed", body: "Coins credited" });
      return next;
    }

    case "APPLY_SERVER_LEDGER": {
      const l = action.ledger;
      if (!l) return s;
      return {
        ...s,
        treasuryUsd: Number(l.treasuryUsd || 0),
        profitUsd: Number(l.profitUsd || 0),
        bufferUsd: Number(l.bufferUsd || 0),
        withdrawalsPaused: !!l.withdrawalsPaused,
        withdrawFeePct: Number(l.withdrawFeePct ?? s.withdrawFeePct),
        withdrawDelayMs: Number(l.withdrawDelayMs ?? s.withdrawDelayMs),
        withdrawDailyCapUsd: Number(l.withdrawDailyCapUsd ?? s.withdrawDailyCapUsd),
        withdrawWeeklyCapUsd: Number(l.withdrawWeeklyCapUsd ?? s.withdrawWeeklyCapUsd),
        withdrawalsPaidUsdToday: Number(l.paidTodayUsd ?? s.withdrawalsPaidUsdToday),
        withdrawalsPaidUsdWeek: Number(l.paidWeekUsd ?? s.withdrawalsPaidUsdWeek),
      };
    }

    case "ADMIN_SET_TREASURY_CONFIG": {
      const next = { ...s };
      if (action.split) next.treasurySplit = { ...next.treasurySplit, ...action.split };
      if (typeof action.withdrawFeePct === "number") next.withdrawFeePct = Math.max(0, Math.min(0.2, action.withdrawFeePct));
      if (typeof action.withdrawDelayMs === "number") next.withdrawDelayMs = Math.max(0, action.withdrawDelayMs);
      if (typeof action.withdrawDailyCapUsd === "number") next.withdrawDailyCapUsd = Math.max(0, action.withdrawDailyCapUsd);
      if (typeof action.withdrawWeeklyCapUsd === "number") next.withdrawWeeklyCapUsd = Math.max(0, action.withdrawWeeklyCapUsd);
      return next;
    }

    case "ADMIN_TOGGLE_WITHDRAWALS": {
      return { ...s, withdrawalsPaused: !s.withdrawalsPaused };
    }

    case "ADMIN_PROCESS_READY": {
      // Process any Ready withdrawals if delay passed & treasury has enough
      const now2 = now;
      const feePct = s.withdrawFeePct ?? 0.05;
      const delay = s.withdrawDelayMs ?? (24*60*60*1000);

      // reset caps if day/week changed
      let next = { ...s };
      const dk = dayKey(now2);
      const wk = weekKey(now2);
      if ((next.lastWithdrawCapDay || dk) !== dk) { next.withdrawalsPaidUsdToday = 0; next.lastWithdrawCapDay = dk; }
      if ((next.lastWithdrawCapWeek || wk) !== wk) { next.withdrawalsPaidUsdWeek = 0; next.lastWithdrawCapWeek = wk; }

      const capDay = next.withdrawDailyCapUsd ?? 10;
      const capWeek = next.withdrawWeeklyCapUsd ?? 50;

      const ws = (next.withdrawals || []).map((w) => ({ ...w }));
      for (const w of ws) {
        if (w.status !== "Pending") continue;
        if ((w.processAfter || 0) > now2) continue;

        const usd = Number(w.usd) || 0;
        const net = Math.max(0, +(usd * (1 - feePct)).toFixed(2));

        if (next.withdrawalsPaused) { w.status = "Paused"; continue; }
        if ((next.treasuryUsd || 0) < net) { w.status = "Insufficient treasury"; continue; }
        if ((next.withdrawalsPaidUsdToday || 0) + net > capDay) { w.status = "Daily cap reached"; continue; }
        if ((next.withdrawalsPaidUsdWeek || 0) + net > capWeek) { w.status = "Weekly cap reached"; continue; }

        // pay
        next.treasuryUsd = +( (next.treasuryUsd || 0) - net ).toFixed(2);
        next.withdrawalsPaidUsdToday = +( (next.withdrawalsPaidUsdToday || 0) + net ).toFixed(2);
        next.withdrawalsPaidUsdWeek = +( (next.withdrawalsPaidUsdWeek || 0) + net ).toFixed(2);
        w.status = "Paid";
        w.paidAt = now2;
        w.netUsd = net;
      }

      next.withdrawals = ws;
      next = pushUiEvent(next, { type: "toast", title: "Admin", body: "Processed ready withdrawals" });
      return next;
    }

    case "TOGGLE_SOUND": {

      return { ...s, soundOn: !s.soundOn };
    }

    case "FINISH_TUTORIAL": {
      return { ...s, tutorialSeen: true };
    }

    case "RESET":
      return { ...initial, lastAccrueAt: now, dailyResetAt: now };

    case "__TICK__":
      // Just accrue (includes auction advance)
      return s;

    case "BUY_PAVILION": {
      const p = PAVILIONS.find((x) => x.id === action.id);
      if (!p) return s;
      if (s.coinsPurchase < p.priceCoins) return s;

      const next = {
        ...s,
        coinsPurchase: s.coinsPurchase - p.priceCoins,
        ownedPavilions: { ...s.ownedPavilions, [p.id]: (s.ownedPavilions[p.id] || 0) + 1 },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "pavilion_bought", 1);
      next.oneProgress = bumpCounter(next.oneProgress, "pavilion_bought", 1);
      next.lastBought = { kind: "pavilion", id: action.id, at: Date.now() };
      let out = summonEvent(next, "pavilion", action.id);
      out = pushUiEvent(out, { type: "pop", variant: "blue", text: "Pavilion bought" });
      out = pushIcon(out, { emoji: "🎟️", text: "+ tickets/hr" });
      out = unlockAchievement(out, "first_pavilion", "First Pavilion");
      return out;
    }

    
case "BUY_ANIMAL": {

      const a = ANIMALS.find((x) => x.id === action.id);
      if (!a || a.locked) return s;
      if (a.priceVisitors == null) return s;
      if (s.visitors < a.priceVisitors) return s;

      const next = {
        ...s,
        visitors: s.visitors - a.priceVisitors,
        ownedAnimals: { ...s.ownedAnimals, [a.id]: (s.ownedAnimals[a.id] || 0) + 1 },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "animal_bought", 1);
      next.oneProgress = bumpCounter(next.oneProgress, "animal_bought", 1);
      
// Mission progress
if (next.missions?.daily) {
  next.missions.daily = next.missions.daily.map(m =>
    m.id === "buy_animal" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m
  );
}

let out = pushUiEvent(next, { type: "pop", variant: "pink", text: "Animal bought" });

      out = pushIcon(out, { emoji: "👥", text: "+ visitors/day" });
      return out;
    }

    case "EXCHANGE_TICKETS": {
      const batch = Math.floor(s.tickets / 300);
      if (batch <= 0) return s;

      const next = {
        ...s,
        tickets: s.tickets - batch * 300,
        coinsPurchase: s.coinsPurchase + batch * 2,
        coinsWithdraw: s.coinsWithdraw + batch * 1,
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "exchange", 1);
      let out = pushUiEvent(next, { type: "toast", title: "Exchanged tickets", body: `+${batch*2} purchase coins, +${batch} withdraw coins` });
      out = pushIcon(out, { emoji: "🟩", text: `+${batch*2}` });
      out = pushIcon(out, { emoji: "⬜", text: `+${batch}` });
      return out;
    }

    case "SIM_TOPUP": {
      const usd = Math.max(0, Number(action.usd) || 0);
      const visitorsAdd = Math.floor(usd * 300);

      return {
        ...s,
        coinsPurchase: s.coinsPurchase + Math.floor(usd * 1000),
        visitors: s.visitors + visitorsAdd,
        dailyVisitorsGained: (s.dailyVisitorsGained || 0) + visitorsAdd,
      };
    }

    case "BUY_BOOSTER": {
      const b = BOOSTERS.find((x) => x.id === action.id);
      if (b?.requiresDeposit && !s.hasDeposited) {
        pushToast(s, "Deposit $1+ to unlock premium boosters.");
        return s;
      }
      if (!b) return s;

      const cost = b.cost?.coinsPurchase || 0;
      if (s.coinsPurchase < cost) return s;

      let next = { ...s, coinsPurchase: s.coinsPurchase - cost };

      if (b.effect?.freeWheelSpins) {
        next.freeWheelSpins = (next.freeWheelSpins || 0) + b.effect.freeWheelSpins;
      }

      if (b.durationMs && (b.effect?.ticketsMult || b.effect?.visitorsMult)) {
        next.activeBoosters = [
          ...(next.activeBoosters || []),
          { id: b.id, effect: b.effect, expiresAt: now + b.durationMs },
        ];
      }

      return next;
    }

    
case "PLAY_WHEEL": {

      const cost = 50;
      const hasFree = (s.freeWheelSpins || 0) > 0;

      if (!hasFree && s.visitors < cost) return s;

      const outcomes = [
        { tickets: 0, weight: 20, label: "Try Again" },
        { tickets: 200, weight: 25, label: "+200 tickets" },
        { tickets: 500, weight: 20, label: "+500 tickets" },
        { tickets: 1000, weight: 18, label: "+1,000 tickets" },
        { tickets: 2000, weight: 12, label: "+2,000 tickets" },
        { tickets: 5000, weight: 5, label: "+5,000 tickets" },
      ];

      const totalW = outcomes.reduce((a, b) => a + b.weight, 0);
      let r = randInt(1, totalW);
      let pick = outcomes[0];
      for (const o of outcomes) {
        r -= o.weight;
        if (r <= 0) { pick = o; break; }
      }

      const next = {
        ...s,
        visitors: hasFree ? s.visitors : (s.visitors - cost),
        freeWheelSpins: hasFree ? (s.freeWheelSpins - 1) : s.freeWheelSpins,
        tickets: s.tickets + pick.tickets,
        lastGameResult: { game: "wheel", label: pick.label, tickets: pick.tickets, costVisitors: hasFree ? 0 : cost, at: now },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "wheel_spin", 1);
      const celebrate = (pick.tickets || 0) >= 2000;
      
// Mission progress
if (next.missions?.daily) {
  next.missions.daily = next.missions.daily.map(m =>
    m.id === "play_game" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m
  );
}

let out = pushUiEvent(next, { type: "pop", variant: celebrate ? "green" : "blue", text: `Wheel win` });

      out = pushIcon(out, { emoji: "🎟️", text: `+${pick.tickets}` });
      if (celebrate) {
        out = pushUiEvent(out, { type: "celebrate" });
        out = unlockAchievement(out, "big_win", "Big Win!");
      }
      return out;
    }

    case "PLAY_SLOTS": {
      const cost = 100;
      if (s.visitors < cost) return s;

      const symbols = ["🦁", "🐧", "🐍", "🐊", "🦜", "🦓"];
      const a = symbols[randInt(0, symbols.length - 1)];
      const b = symbols[randInt(0, symbols.length - 1)];
      const c = symbols[randInt(0, symbols.length - 1)];

      let winTickets = 0;
      let label = "No win";

      if (a === b && b === c) {
        winTickets = 6000;
        label = "JACKPOT! +6,000 tickets";
      } else if (a === b || b === c || a === c) {
        winTickets = 1500;
        label = "Win! +1,500 tickets";
      } else {
        winTickets = 200;
        label = "+200 tickets";
      }

      const next = {
        ...s,
        visitors: s.visitors - cost,
        tickets: s.tickets + winTickets,
        lastGameResult: {
          game: "slots",
          label,
          reels: [a, b, c],
          tickets: winTickets,
          costVisitors: cost,
          at: now,
        },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "slots_spin", 1);
      const celebrate = winTickets >= 6000;
      let out = pushUiEvent(next, { type: "pop", variant: celebrate ? "green" : "blue", text: "Slots result" });
      out = pushIcon(out, { emoji: "🎟️", text: `${winTickets >= 0 ? "+" : ""}${winTickets}` });
      out = pushUiEvent(out, { type: "toast", title: "Slots", body: label });
      if (celebrate) {
        out = pushUiEvent(out, { type: "celebrate" });
        out = unlockAchievement(out, "big_win", "Big Win!");
      }
      return out;
    }

    case "PLACE_AUCTION_BID": {
      const bid = Math.max(0, Math.floor(Number(action.bid) || 0));
      if (!s.auction) return s;

      const a = s.auction;
      if (now >= a.endsAt) return s;

      const minNext = (a.highestBid || 0) + (a.minIncrement || 25);
      if (bid < minNext) return s;

      // Additional visitors needed beyond your current bid (escrow)
      const delta = Math.max(0, bid - (a.yourBid || 0));
      if (s.visitors < delta) return s;

      return {
        ...s,
        visitors: s.visitors - delta,
        auction: {
          ...a,
          yourBid: bid,
          highestBid: bid,
          highestBidder: "you",
        },
      };
    }

    case "CLAIM_TASK": {
      const { taskId, scope } = action;
      const isDaily = scope === "daily";

      const def = isDaily
        ? DAILY_TASKS.find((t) => t.id === taskId)
        : ONETIME_TASKS.find((t) => t.id === taskId);

      if (!def) return s;

      if (isDaily && s.dailyClaimed?.[taskId]) return s;
      if (!isDaily && s.oneClaimed?.[taskId]) return s;

      let done = false;

      if (def.kind === "counter") {
        const key = def.event;
        const val = isDaily ? (s.dailyProgress?.[key] || 0) : (s.oneProgress?.[key] || 0);
        done = val >= def.target;
      } else if (def.kind === "accum") {
        const val = s.dailyVisitorsGained || 0;
        done = val >= def.target;
      } else if (def.kind === "state_check") {
        const val = s[def.stateField] || 0;
        done = val >= def.target;
      }

      if (!done) return s;

      let next = applyReward(s, def.reward);

      if (isDaily) {
        next.dailyClaimed = { ...(next.dailyClaimed || {}), [taskId]: true };
      } else {
        next.oneClaimed = { ...(next.oneClaimed || {}), [taskId]: true };
      }

      return next;
    }
case "RECORD_DEPOSIT": {
      const amountTon = Math.max(0, Number(action.amountTon) || 0);
      if (amountTon <= 0) return s;

      const dep = {
        id: "dep_" + (crypto.randomUUID?.() || String(Math.random())),
        amountTon: Number(amountTon.toFixed(4)),
        usd: Math.max(0, Number(action.usd) || 0),
        treasury: action.treasury || "",
        status: "Pending",
        createdAt: now,
      };

      return { ...s, deposits: [...(s.deposits || []), dep] };
    }

    case "CONFIRM_DEPOSIT": {
      const id = action.id;
      const deps = (s.deposits || []).map((d) =>
        d.id === id ? { ...d, status: "Confirmed", confirmedAt: now } : d
      );
      const dep = (s.deposits || []).find((d) => d.id === id);
      const usd = Math.max(0, Number(dep?.usd) || 0) || 1; // fallback to $1 minimum for prototype
      const wasConfirmed = (dep?.status === "Confirmed");
      if (wasConfirmed) return s;

      const split = s.treasurySplit || { treasury: 0.6, profit: 0.3, buffer: 0.1 };
      const tAdd = usd * (split.treasury ?? 0.6);
      const pAdd = usd * (split.profit ?? 0.3);
      const bAdd = usd * (split.buffer ?? 0.1);
      const coinsAdd = Math.floor(usd * 1000);
      let out = { ...s, deposits: deps, hasDeposited: true, depositUsdTotal: (s.depositUsdTotal || 0) + usd,
        treasuryUsd: (s.treasuryUsd || 0) + tAdd,
        profitUsd: (s.profitUsd || 0) + pAdd,
        bufferUsd: (s.bufferUsd || 0) + bAdd,
        coinsPurchase: (s.coinsPurchase || 0) + coinsAdd,
        coins: (s.coins || 0) + coinsAdd,
      };
      out = pushUiEvent(out, { type: "toast", title: "Deposit confirmed", body: "Deposit-only animal unlocked" });
      out = pushIcon(out, { emoji: "💎", text: "Unlocked" });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

    case "PROCESS_WITHDRAWAL": {
      const { id, status } = action;
      if (!id || !status) return s;
      const ws = (s.withdrawals || []).map((w) =>
        w.id === id ? { ...w, status } : w
      );
      return { ...s, withdrawals: ws };
    }

    case "SIM_DEPOSIT": {
      const usd = Math.max(1, Number(action.usd) || 1);
      const amountTon = Math.max(0.1, Number(action.amountTon) || Number((usd / 5).toFixed(3))); // rough
      const id = "dep_" + (crypto.randomUUID?.() || String(Math.random()));
      const dep = {
        id,
        amountTon: Number(amountTon.toFixed(4)),
        usd,
        treasury: action.treasury || "",
        status: "Confirmed",
        createdAt: now,
        confirmedAt: now,
      };

      // split
      const split = s.treasurySplit || { treasury: 0.6, profit: 0.3, buffer: 0.1 };
      const tAdd = usd * (split.treasury ?? 0.6);
      const pAdd = usd * (split.profit ?? 0.3);
      const bAdd = usd * (split.buffer ?? 0.1);

      // credit purchased coins ($1 = 1000 coins)
      const coinsAdd = Math.floor(usd * 1000);

      let out = {
        ...s,
        deposits: [...(s.deposits || []), dep],
        hasDeposited: true,
        depositUsdTotal: (s.depositUsdTotal || 0) + usd,
        treasuryUsd: (s.treasuryUsd || 0) + tAdd,
        profitUsd: (s.profitUsd || 0) + pAdd,
        bufferUsd: (s.bufferUsd || 0) + bAdd,
        coinsPurchase: (s.coinsPurchase || 0) + coinsAdd,
        coins: (s.coins || 0) + coinsAdd,
      };

      out = pushUiEvent(out, { type: "toast", title: "Demo deposit", body: `+$${usd} → +${coinsAdd} coins` });
      out = pushIcon(out, { emoji: "💰", text: `+$${usd}` });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

case "CLAIM_BONUS_ANIMAL": {
  // Claim deposit-only bonus animal once for free (1A)
  if (!s.hasDeposited) return s;
  if (s.bonusAnimalClaimed) return s;
  const id = "ton_panther";
  return {
    ...s,
    bonusAnimalClaimed: true,
    ownedAnimals: { ...s.ownedAnimals, [id]: (s.ownedAnimals[id] || 0) + 1 },
  };
}

case "SET_REFERRER": {
      const code = (action.code || "").trim();
      if (!code) return s;
      // prevent self-ref (when referral code exists)
      if (code && s.referral?.code && code === s.referral.code) return s;
      if (s.referredBy) return s; // only set once in prototype
      return { ...s, referredBy: code };
    }

    case "SIM_REF_INVITE": {

  const invited = (s.referral?.invited || 0) + 1;
  // In prototype, randomly mark some invited as active
  const active = (s.referral?.active || 0) + (Math.random() < 0.6 ? 1 : 0);
  return {
    ...s,
    referral: { ...(s.referral || {}), invited, active, claimed: (s.referral?.claimed || {}) },
  };
}

case "CLAIM_REF_MILESTONE": {
  const k = Number(action.k) || 0;
  const m = REF_MILESTONES.find((x) => x.k === k);
  if (!m) return s;
  const claimed = !!s.referral?.claimed?.[k];
  if (claimed) return s;
  if ((s.referral?.invited || 0) < k) return s;

  const next = applyReward(s, m.reward);
  return {
    ...next,
    referral: {
      ...(next.referral || {}),
      claimed: { ...(next.referral?.claimed || {}), [k]: true },
    },
  };
}


    
case "CLAIM_MISSION": {
  const { scope, id } = action;
  const list = s.missions?.[scope] || [];
  const m = list.find(x => x.id === id);
  if (!m || m.progress < m.goal) return s;

  let next = { ...s };
  if (m.reward?.tickets) {
    next.tickets += m.reward.tickets;
    next = pushIcon(next, { emoji: "🎯", text: `+${m.reward.tickets}` });
  }
  next.missions[scope] = list.filter(x => x.id !== id);
  next = pushUiEvent(next, { type: "toast", title: "Mission complete", body: m.title });
      // Event quest progress
      if (next.eventQuests?.list) {
        next.eventQuests = { ...next.eventQuests, list: next.eventQuests.list.map(q => q.id === "eq_claim" ? { ...q, progress: Math.min(q.goal, q.progress + 1) } : q) };
      }
  next = pushUiEvent(next, { type: "celebrate" });
  return next;
}

case "REQUEST_WITHDRAW": {

      const wallet = (action.wallet || "").trim();
      const coins = Math.max(0, Math.floor(Number(action.coins) || 0));
      const feePct = s.withdrawFeePct ?? 0.05;
      const delay = s.withdrawDelayMs ?? (24*60*60*1000);
      if (coins < 1000) return s;
      if ((s.depositUsdTotal || 0) < 1) return s;
      if (s.withdrawalsPaused) return s;
      if (s.visitors < 1000) return s;
      if (s.coinsWithdraw < coins) return s;
      const usd = +(coins / 1000).toFixed(2);
      const net = Math.max(0, +(usd * (1 - feePct)).toFixed(2));
      if (wallet.length < 10) return s;

      const next = {
        ...s,
        coinsWithdraw: s.coinsWithdraw - coins,
        withdrawals: [
          ...s.withdrawals,
          {
            id: (action.id || (crypto.randomUUID?.() || String(Math.random()))),
            processAfter: now + delay,
            feePct,
            netUsd: net,
            wallet,
            coins,
            usd: coins / 1000,
            status: "Pending",
            createdAt: now,
          },
        ],
      };
      let out = pushUiEvent(next, { type: "toast", title: "Withdrawal requested", body: "Added to queue (prototype)" });
      out = pushIcon(out, { emoji: "⬜", text: `-${coins}` });
      return out;
    }

    case "PLACE_ANIMAL_SLOT": {
  state = ensureZooSystems(state);
  const { slotId, animalId } = action;
  const slot = state.zooSlots?.find(s => s.slotId === slotId);
  if (!slot || !slot.unlocked) return state;

  const owned = state.ownedAnimals?.[animalId] || 0;
  const placed = placedCounts(state);
  // if replacing, free old first
  const prev = slot.animalId;
  if (prev) placed[prev] = Math.max(0, (placed[prev]||0) - 1);

  if (owned <= (placed[animalId]||0)) {
    pushToast(state, "Not enough copies owned to place.");
    return state;
  }
  slot.animalId = animalId;
  pushToast(state, "Placed in zoo ✅");
  return state;
}

case "REMOVE_ANIMAL_SLOT": {
  state = ensureZooSystems(state);
  const { slotId } = action;
      const needP = prestigeRequiredForSlot(slotId);
      const curP = calcPrestige(state);
      if (needP > 0 && curP < needP) {
        pushToast(state, `Need Prestige ${needP}+ to unlock this pen.`);
        return state;
      }
  const slot = state.zooSlots?.find(s => s.slotId === slotId);
  if (!slot) return state;
  slot.animalId = null;
  pushToast(state, "Removed from pen.");
  return state;
}

case "LEVEL_UP_ANIMAL": {
  state = ensureZooSystems(state);
  const { animalId } = action;
  const def = ANIMALS.find(a => a.id === animalId);
  if (!def) return state;
  const cur = levelFor(state, animalId);
  const max = def.maxLevel || 20;
  if (cur >= max) { pushToast(state, "Max level reached."); return state; }

  const next = cur + 1;
  const cost = levelUpCostCoins(animalId, next);
  if ((state.coinsPurchase||0) < cost) {
    pushToast(state, "Not enough purchase coins.");
    return state;
  }
  state.coinsPurchase -= cost;
  state.animalLevels[animalId] = next;
  pushToast(state, `Level up! ${def.name} → Lv.${next}`);
  pushReward(state, { kind: "levelup", animalId, level: next });
  return state;
}

case "PAY_UPKEEP": {
  state = ensureZooSystems(state);
  state = ensureShop(state);
  const now = Date.now();
  const due = upkeepDue(state, now);
  if (due <= 0) { pushToast(state, "Upkeep already paid ✅"); return state; }
  if ((state.coinsPurchase || 0) < due) { pushToast(state, "Not enough purchase coins to pay upkeep."); return state; }
  state.coinsPurchase -= due;
  state.upkeepPaidThroughDay = dayKey(now);
  pushToast(state, `Upkeep paid (-${due} 🟩)`);
  return state;
}

case "REROLL_SHOP": {
  state = ensureShop(state);
  const now = Date.now();
  const today = dayKey(now);
  if ((state.shopRerollDay ?? today) !== today) {
    state.shopRerollDay = today;
    state.shopRerollsToday = 0;
  }
  const cost = shopRerollCost(state, now);
  if ((state.coinsPurchase || 0) < cost) { pushToast(state, "Not enough purchase coins to reroll."); return state; }
  state.coinsPurchase -= cost;
  state.shopRerollsToday = (state.shopRerollsToday || 0) + 1;
  const ids = ANIMALS.map(a => a.id);
  const pick = [];
  while (pick.length < Math.min(5, ids.length)){
    const id = ids[Math.floor(Math.random()*ids.length)];
    if (!pick.includes(id)) pick.push(id);
  }
  state.shopAnimalIds = pick;
  pushToast(state, `Shop rerolled (-${cost} 🟩)`);
  return state;
}

case "UNLOCK_ZOO_SLOT": {
  state = ensureZooSystems(state);
  const { slotId } = action;
  const slot = state.zooSlots?.find(s => s.slotId === slotId);
  if (!slot || slot.unlocked) return state;
  const cost = unlockSlotCostCoins(slotId);
  if ((state.coinsPurchase||0) < cost) {
    pushToast(state, "Not enough purchase coins to unlock.");
    return state;
  }
  state.coinsPurchase -= cost;
  slot.unlocked = true;
  pushToast(state, "New pen unlocked 🧱");
  pushReward(state, { kind: "unlock", slotId });
  return state;
}
case "PLAY_CARD_FLIP": {
  const cost = 400; // tickets
  if ((s.tickets || 0) < cost) return s;

  const cards = [
    { coins: 40, weight: 45, label: "+40 🟩" },
    { coins: 120, weight: 35, label: "+120 🟩" },
    { coins: 320, weight: 20, label: "+320 🟩" },
  ];
  const totalW = cards.reduce((a,b)=>a+b.weight,0);
  let r = randInt(1, totalW);
  let pick = cards[0];
  for (const c of cards){ r -= c.weight; if (r<=0){ pick=c; break; } }

  const next = {
    ...s,
    tickets: s.tickets - cost,
    coinsPurchase: (s.coinsPurchase || 0) + pick.coins,
    lastGameResult: { game: "card", label: pick.label, coins: pick.coins, costTickets: cost, at: now },
  };
  next.dailyProgress = bumpCounter(next.dailyProgress, "card_flip", 1);

  let out = pushUiEvent(next, { type:"pop", variant: pick.coins >= 320 ? "green" : "blue", text:"Card Flip" });
  out = pushIcon(out, { emoji:"🟩", text:`+${pick.coins}` });
  if (pick.coins >= 320){
    out = pushUiEvent(out, { type:"celebrate" });
    out = unlockAchievement(out, "card_big", "Lucky Flip!");
  }
  return out;
}

case "PLAY_COIN_RUSH": {
  const cost = 150; // visitors
  if ((s.visitors || 0) < cost) return s;

  const o = [
    { coins: 25, w: 60, label:"+25 🟩" },
    { coins: 90, w: 30, label:"+90 🟩" },
    { coins: 250, w: 10, label:"+250 🟩" },
  ];
  const totalW = o.reduce((a,b)=>a+b.w,0);
  let r = randInt(1, totalW);
  let pick = o[0];
  for (const c of o){ r -= c.w; if (r<=0){ pick=c; break; } }

  const next = {
    ...s,
    visitors: s.visitors - cost,
    coinsPurchase: (s.coinsPurchase || 0) + pick.coins,
    lastGameResult: { game:"rush", label: pick.label, coins: pick.coins, costVisitors: cost, at: now },
  };
  next.dailyProgress = bumpCounter(next.dailyProgress, "coin_rush", 1);

  let out = pushUiEvent(next, { type:"pop", variant: pick.coins >= 250 ? "green" : "blue", text:"Coin Rush" });
  out = pushIcon(out, { emoji:"🟩", text:`+${pick.coins}` });
  if (pick.coins >= 250){
    out = pushUiEvent(out, { type:"celebrate" });
  }
  return out;
}

case "EXCHANGE_TICKETS": {
  let next = { ...s };
  next = ensureTicketExchange(next);
  const want = Math.max(0, Math.floor(action.tickets || 0));
  if (want < 1000) { pushToast(next, "Minimum exchange is 1,000 tickets."); return next; }
  const dailyCap = 20000; // tickets/day
  const remaining = Math.max(0, dailyCap - (next.ticketExchangeUsed || 0));
  const amount = Math.min(want, remaining, next.tickets || 0);
  if (amount < 1000) { pushToast(next, "Daily exchange cap reached."); return next; }

  const coins = ticketExchangeRateCoins(amount);
  next.tickets -= amount;
  next.coinsPurchase = (next.coinsPurchase || 0) + coins;
  next.ticketExchangeUsed = (next.ticketExchangeUsed || 0) + amount;

  pushToast(next, `Exchanged ${amount.toLocaleString()} 🎟️ → +${coins} 🟩`);
  return next;
}

case "DAILY_CHECKIN": {
  let next = { ...s };
  next = ensureVisitorsLoop(next);
  const today = dayKey(now);
  if (next.lastCheckInDay === today){
    pushToast(next, "Already checked in today.");
    return next;
  }
  const yd = dayKey(now - 86400000);
  if (next.streakDay === yd) next.streakCount = (next.streakCount || 0) + 1;
  else next.streakCount = 1;
  next.streakDay = today;
  next.lastCheckInDay = today;

  const bonusVisitors = 200 + Math.min(10, next.streakCount) * 40;
  const bonusTickets = 150 + Math.min(10, next.streakCount) * 25;

  next.visitors = (next.visitors || 0) + bonusVisitors;
      next.totalVisitorsEarned = (next.totalVisitorsEarned || 0) + bonusVisitors;
  next.tickets = (next.tickets || 0) + bonusTickets;

  next.dailyProgress = bumpCounter(next.dailyProgress, "check_in", 1);

  pushToast(next, `Daily check-in: +${bonusVisitors} 👥 and +${bonusTickets} 🎟️`);
  next = pushUiEvent(next, { type:"pop", variant:"green", text:"Check-in!" });
  next = pushIcon(next, { emoji:"👥", text:`+${bonusVisitors}` });
  return next;
}

case "BUY_MARKETING_UP": {
  let next = { ...s };
  next = ensureVisitorsLoop(next);
  const cost = marketingUpgradeCost(next.marketingLevel || 0);
  if ((next.coinsPurchase || 0) < cost){
    pushToast(next, "Not enough purchase coins.");
    return next;
  }
  next.coinsPurchase -= cost;
  next.marketingLevel = (next.marketingLevel || 0) + 1;
  pushToast(next, `Marketing upgraded to L${next.marketingLevel}.`);
  return next;
}

case "BUY_ATTRACTION_UP": {
  let next = { ...s };
  next = ensureVisitorsLoop(next);
  const cost = attractionUpgradeCost(next.attractionLevel || 0);
  if ((next.coinsPurchase || 0) < cost){
    pushToast(next, "Not enough purchase coins.");
    return next;
  }
  next.coinsPurchase -= cost;
  next.attractionLevel = (next.attractionLevel || 0) + 1;
  pushToast(next, `Attractions upgraded to L${next.attractionLevel}.`);
  return next;
}

case "ACTIVATE_MARKETING_BOOST": {
  let next = { ...s };
  next = ensureVisitorsLoop(next);
  const cost = marketingBoostCost();
  if ((next.tickets || 0) < cost){
    pushToast(next, "Not enough tickets.");
    return next;
  }
  next.tickets -= cost;
  next.marketingBoostUntil = now + 2*60*60*1000;
  pushToast(next, "Marketing boost active for 2 hours!");
  next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Boost!" });
  return next;
}

default:
      return s;
  }
}

export function useGameState() {
  const [state, dispatch] = useReducer(reducer, undefined, loadState);

  useEffect(() => {
    const t = setInterval(() => dispatch({ type: "__TICK__" }), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    saveState(state);
  }, [state]);

  const derived = useMemo(() => ({
    ticketsPerHour: Math.floor(ticketsPerHourTotal(state)),
    visitorsPerDay: Math.floor(visitorsPerDayTotal(state)),
  }), [state]);

  const actions = useMemo(() => ({
    toast: (msg) => dispatch({ type: "PUSH_TOAST", msg }),
    buyPavilion: (id) => dispatch({ type: "BUY_PAVILION", id }),
    buyAnimal: (id) => dispatch({ type: "BUY_ANIMAL", id }),
    placeAnimalSlot: (slotId, animalId) => dispatch({ type: "PLACE_ANIMAL_SLOT", slotId, animalId }),
    removeAnimalSlot: (slotId) => dispatch({ type: "REMOVE_ANIMAL_SLOT", slotId }),
    levelUpAnimal: (animalId) => dispatch({ type: "LEVEL_UP_ANIMAL", animalId }),
    unlockZooSlot: (slotId) => dispatch({ type: "UNLOCK_ZOO_SLOT", slotId }),
    payUpkeep: () => dispatch({ type: "PAY_UPKEEP" }),
    rerollShop: () => dispatch({ type: "REROLL_SHOP" }),
    exchangeTickets: () => dispatch({ type: "EXCHANGE_TICKETS" }),
    simTopUp: (usd) => dispatch({ type: "SIM_TOPUP", usd }),
    playWheel: () => dispatch({ type: "PLAY_WHEEL" }),
    playCardFlip: () => dispatch({ type: "PLAY_CARD_FLIP" }),
    playCoinRush: () => dispatch({ type: "PLAY_COIN_RUSH" }),
    exchangeTickets: (tickets) => dispatch({ type: "EXCHANGE_TICKETS", tickets }),
    dailyCheckIn: () => dispatch({ type: "DAILY_CHECKIN" }),
    buyMarketingUpgrade: () => dispatch({ type: "BUY_MARKETING_UP" }),
    buyAttractionUpgrade: () => dispatch({ type: "BUY_ATTRACTION_UP" }),
    activateMarketingBoost: () => dispatch({ type: "ACTIVATE_MARKETING_BOOST" }),
    playSlots: () => dispatch({ type: "PLAY_SLOTS" }),
    buyBooster: (id) => dispatch({ type: "BUY_BOOSTER", id }),
    placeAuctionBid: (bid) => dispatch({ type: "PLACE_AUCTION_BID", bid }),
    recordDeposit: ({ amountTon, usd, treasury }) => dispatch({ type: "RECORD_DEPOSIT", amountTon, usd, treasury }),
    confirmDeposit: (id) => dispatch({ type: "CONFIRM_DEPOSIT", id }),
    simDeposit: (usd, amountTon, treasury) => dispatch({ type: "SIM_DEPOSIT", usd, amountTon, treasury }),

    
createDepositIntent: async (currency, usd, expectedNano) => {
  const userId = s.userId || "local";
  const res = await fetch(`${API_BASE}/api/deposits/create`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, currency, usd, expectedNano })
  });
  const j = await res.json();
  if (j?.deposit?.id) dispatch({ type: "CREATE_DEPOSIT_INTENT", deposit: j.deposit, pay: j.pay });
  return j;
},

registerReferral: async () => {
  try{
    const userId = s.userId || "local";
    const ref = detectReferrerId();
    if (!ref) return;
    if (s.referrerId) return;
    await fetch(`${API_BASE}/api/referrals/register`, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ userId, referrerId: ref })
    });
    dispatch({ type:"SET_REFERRER", referrerId: ref });
  }catch{}
},

fetchReferralStatus: async () => {
  try{
    const userId = s.userId || "local";
    const res = await fetch(`${API_BASE}/api/referrals/status?userId=${encodeURIComponent(userId)}`);
    const j = await res.json();
    if (j?.ok && j.referral){
      dispatch({ type:"APPLY_REFERRAL_STATUS", referral: j.referral });
    }
  }catch{}
},

claimReferralRewards: async () => {
  try{
    const userId = s.userId || "local";
    const res = await fetch(`${API_BASE}/api/referrals/claim`, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ userId })
    });
    const j = await res.json();
    if (j?.ok && j.coins){
      dispatch({ type:"CLAIM_REFERRAL_REWARDS", coins: j.coins });
    }
    return j;
  }catch{}
  return null;
},
fetchWithdrawalsServer: async () => {
  try{
    const userId = s.userId || "local";
    const res = await fetch(`${API_BASE}/api/withdrawals/list?userId=${encodeURIComponent(userId)}`);
    const j = await res.json();
    if (j?.ok && Array.isArray(j.withdrawals)){
      dispatch({ type:"SET_WITHDRAWALS", withdrawals: j.withdrawals });
    }
  }catch{}
},
syncProfile: async () => {
  try{
    const userId = s.userId || "local";
    const name = (s.playerName || "Player").trim() || "Player";
    const visitors = s.visitors || 0;
    const prestige = derived.prestige || 0;
    const coinsPurchase = s.coinsPurchase || 0;
    const res = await fetch(`${API_BASE}/api/profile/sync`, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ userId, name, coinsPurchase, visitors, prestige })
    });
    const j = await res.json();
    if (j?.ok && j.profile){
      dispatch({ type:"APPLY_SERVER_PROFILE", profile: j.profile });
    }
  }catch{}
},
reportLeaderboard: async () => {
  try{
    const userId = s.userId || "local";
    const name = (s.playerName || "Player").trim() || "Player";
    const visitors = s.visitors || 0;
    const prestige = derived.prestige || 0;
    await fetch(`${API_BASE}/api/leaderboard/report`, {
      method: "POST",
      headers: { "Content-Type":"application/json" },
      body: JSON.stringify({ userId, name, visitors, prestige })
    });
  }catch{}
},
refreshLedger: async () => {
      const res = await fetch(`${API_BASE}/api/admin/status`);
      const j = await res.json();
      if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },

    
requestWithdrawServer: async (address, currency, coins) => {
  const usd = +(Math.floor(coins) / 1000).toFixed(2);
  const userId = s.userId || "local";
  const res = await fetch(`${API_BASE}/api/withdrawals/request`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, address, currency, usd, coins })
  });
  const j = await res.json();
  if (!res.ok) {
    dispatch({ type: "PUSH_TOAST", msg: j?.error || "Withdrawal request failed." });
  }
  if (j?.cooldownMsLeft) {
    const mins = Math.ceil(j.cooldownMsLeft / 60000);
    dispatch({ type: "PUSH_TOAST", msg: `Cooldown: wait ~${mins} min before withdrawing.` });
  }
  if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
  return j;
},

processWithdrawalsServer: async () => {
      const res = await fetch(`${API_BASE}/api/withdrawals/process`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      const j = await res.json();
      if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      if (j?.paid?.length) dispatch({ type: "APPLY_PAID_WITHDRAWALS", paid: j.paid });
      return j;
    },

    demoConfirmDeposit: async (id) => {
      const res = await fetch(`${API_BASE}/api/demo/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      const j = await res.json();
      if (j?.confirmed?.length) dispatch({ type: "APPLY_CONFIRMED_DEPOSITS", confirmed: j.confirmed, ledger: j.ledger });
      else if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },

    checkDeposits: async () => {
      const res = await fetch(`${API_BASE}/api/deposits/check`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 60 })
      });
      const j = await res.json();
      if (j?.confirmed?.length) dispatch({ type: "APPLY_CONFIRMED_DEPOSITS", confirmed: j.confirmed, ledger: j.ledger });
      else if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },
    adminProcessReady: () => dispatch({ type: "ADMIN_PROCESS_READY" }),
    adminToggleWithdrawals: () => dispatch({ type: "ADMIN_TOGGLE_WITHDRAWALS" }),
    adminSetTreasuryConfig: (cfg) => dispatch({ type: "ADMIN_SET_TREASURY_CONFIG", ...cfg }),
    processWithdrawal: (id, status) => dispatch({ type: "PROCESS_WITHDRAWAL", id, status }),
    simulateDeposit: () => dispatch({ type: "SIM_DEPOSIT" }),
    claimBonusAnimal: () => dispatch({ type: "CLAIM_BONUS_ANIMAL" }),
    simulateInvite: () => dispatch({ type: "SIM_REF_INVITE" }),
    claimReferralMilestone: (k) => dispatch({ type: "CLAIM_REF_MILESTONE", k }),
    setReferrer: (code) => dispatch({ type: "SET_REFERRER", code }),
    claimTask: (taskId, scope) => dispatch({ type: "CLAIM_TASK", taskId, scope }),
    requestWithdraw: ({ wallet, coins }) => dispatch({ type: "REQUEST_WITHDRAW", wallet, coins }),
    ackUiEvent: (id) => dispatch({ type: "ACK_UI_EVENT", id }),
    claimMission: (scope, id) => dispatch({ type: "CLAIM_MISSION", scope, id }),
    advanceOnboarding: () => dispatch({ type: "ADVANCE_ONBOARDING" }),
    toggleSound: () => dispatch({ type: "TOGGLE_SOUND" }),
    claimAchievement: (id) => dispatch({ type: "CLAIM_ACHIEVEMENT", id }),
    setPlayerName: (name) => dispatch({ type: "SET_PLAYER_NAME", name }),
    buyEventPass: (priceUsd) => dispatch({ type: "BUY_EVENT_PASS", priceUsd }),
    buyEventAnimal: (id, priceVisitors) => dispatch({ type: "BUY_EVENT_ANIMAL", id, priceVisitors }),
    claimEventQuest: (id) => dispatch({ type: "CLAIM_EVENT_QUEST", id }),
    claimTrackTier: (tier, isPass) => dispatch({ type: "CLAIM_TRACK_TIER", tier, isPass }),
    claimInbox: (id) => dispatch({ type: "CLAIM_INBOX", id }),
    finishTutorial: () => dispatch({ type: "FINISH_TUTORIAL" }),
    reset: () => dispatch({ type: "RESET" }),
  }), []);

  // Phase 29: referral registration + status poll
useEffect(() => {
  actions.registerReferral();
  actions.fetchReferralStatus();
  const id = setInterval(() => actions.fetchReferralStatus(), 45000);
  return () => clearInterval(id);
}, [s.userId, s.referrerId]);

// Phase 30: server profile sync (balances)
useEffect(() => {
  actions.syncProfile();
  const id = setInterval(() => actions.syncProfile(), 30000);
  return () => clearInterval(id);
}, [s.userId, s.playerName, s.visitors, s.coinsPurchase, derived.prestige]);

// Phase 32: refresh withdrawals from server
useEffect(() => {
  actions.fetchWithdrawalsServer();
  const id = setInterval(() => actions.fetchWithdrawalsServer(), 20000);
  return () => clearInterval(id);
}, [s.userId]);

return { state, derived, actions };
}function calcPrestige(state){
  state = ensureZooSystems(state);
  let p = 0;

  // Pens unlocked
  for (const sl of state.zooSlots || []){
    if (sl.unlocked) p += 15;
  }

  // Animal ownership + level + rarity
  for (const def of ANIMALS){
    const owned = state.ownedAnimals?.[def.id] || 0;
    if (!owned) continue;
    const tier = def.rarityTier || "common";
    const base = RARITY_PRESTIGE[tier] ?? 10;
    const lvl = levelFor(state, def.id);
    const lvlMult = 1 + (lvl - 1) * 0.10;
    p += owned * base * lvlMult;
  }

  return Math.floor(p);
}

function prestigeRank(prestige){
  let rank = PRESTIGE_RANKS[0];
  for (const r of PRESTIGE_RANKS){
    if (prestige >= r.min) rank = r;
  }
  return rank;
}

function prestigeRequiredForSlot(slotId){
  // light gating only for later pens
  if (slotId <= 3) return 0;
  if (slotId === 4) return 750;
  if (slotId === 5) return 2000;
  return 0;
}

// random visitor event (every ~6h, low chance)
try{
  out = ensureVisitorsLoop(out);
  const last = out.lastVisitorEventAt || 0;
  const since = now - last;
  if (since > 6*60*60*1000){
    if (randInt(1, 100) <= 25){
      const burst = 120 + randInt(0, 180) + Math.floor((out.attractionLevel||0) * 15);
      out.visitors = (out.visitors || 0) + burst;
      out.lastVisitorEventAt = now;
      out = pushUiEvent(out, { type:"pop", variant:"blue", text:"Tour Bus Arrived!" });
      out = pushIcon(out, { emoji:"🚌", text:`+${burst} 👥` });
    }
  }
}catch{}

case "APP_BOOT": {
      let next = { ...s };
      const now = Date.now();

      // Offline progress (tickets per hour)
      const hoursAway = Math.max(0, (now - (s.lastActiveAt || now)) / 36e5);
      if (hoursAway > 0.05) {
        const mult = (s.eventState?.passOwned) ? 1.1 : 1.0;
      const ticketsGained = Math.floor(hoursAway * (s.ticketsPerHour || 0) * mult);
        if (ticketsGained > 0) {
          next.tickets += ticketsGained;
          next = pushUiEvent(next, { type: "toast", title: "Offline progress", body: `+${ticketsGained} tickets while away` });
          next = pushIcon(next, { emoji: "🎟️", text: `+${ticketsGained}` });
        }
      }

      // Weekly reset (leaderboard)
      const wk = weekKey(now);
      if ((s.eventState?.weeklyKey || wk) !== wk) {
        // Determine last week's rank (approx) and grant prizes (prototype)
        const playerScore = s.visitors || 0;
        const seed = (s.eventState?.leaderboardSeed || 1337) + playerScore;
        let x = seed % 2147483647; if (x<=0) x += 2147483646;
        const rnd = () => (x = (x * 16807) % 2147483647) / 2147483647;
        const base = Math.max(500, Math.floor(playerScore * 1.2));
        const bots = Array.from({length:7}).map((_,i)=> (base + Math.floor(rnd()*2500) + i*120));
        const all = bots.concat([playerScore]).sort((a,b)=>b-a);
        const rank = all.indexOf(playerScore) + 1;

        let prize = 0;
        if (rank === 1) prize = 4000;
        else if (rank === 2) prize = 2500;
        else if (rank === 3) prize = 1500;
        else if (rank <= 8) prize = 600;

        if (prize > 0) {
          next = addInbox(next, { id: "lb_" + (s.eventState?.weeklyKey || "wk"), title: "Leaderboard Prize", body: `Rank #${rank} — +${prize} tickets`, tickets: prize, createdAt: now });
          next = pushUiEvent(next, { type: "toast", title: "Weekly prize", body: `Rank #${rank} reward added to Inbox` });
        }

        next.eventState = { ...(next.eventState || {}), weeklyKey: wk, leaderboardSeed: Math.floor(Math.random()*999999) };
        next = pushUiEvent(next, { type: "toast", title: "Weekly reset", body: "Leaderboard refreshed" });
      }

      // withdraw cap reset
      const dk2 = dayKey(now);
      const wk2 = weekKey(now);
      if ((s.lastWithdrawCapDay || dk2) !== dk2) {
        next.withdrawalsPaidUsdToday = 0;
        next.lastWithdrawCapDay = dk2;
      }
      if ((s.lastWithdrawCapWeek || wk2) !== wk2) {
        next.withdrawalsPaidUsdWeek = 0;
        next.lastWithdrawCapWeek = wk2;
      }

      // Event quests reset (daily)
      const dk = dayKey(now);
      if ((s.eventQuests?.dailyKey || dk) !== dk) {
        next.eventQuests = {
          dailyKey: dk,
          list: [
            { id: "eq_buy", title: "Buy 1 animal", goal: 1, progress: 0, rewardPts: 120, claimed: false },
            { id: "eq_play", title: "Play 5 games", goal: 5, progress: 0, rewardPts: 180, claimed: false },
            { id: "eq_claim", title: "Claim 1 mission", goal: 1, progress: 0, rewardPts: 120, claimed: false }
          ]
        };
        next = pushUiEvent(next, { type: "toast", title: "Event quests", body: "New daily quests available" });
      }

      // Daily login
      const today = dayKey(now);
      if (s.dailyLogin.lastDay !== today) {
        const streak = s.dailyLogin.lastDay ? s.dailyLogin.streak + 1 : 1;
        next.dailyLogin = { lastDay: today, streak };
        const reward = 300 + Math.min(7, streak) * 200;
        next.tickets += reward;
        next = pushUiEvent(next, { type: "toast", title: `Daily login Day ${streak}`, body: `+${reward} tickets` });
        next = pushIcon(next, { emoji: "🔥", text: `Streak ${streak}` });
        if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      }

      next.lastActiveAt = now;
      return next;
    }


    case "ACK_UI_EVENT": {
      const id = action.id;
      if (!id) return s;
      return { ...s, uiEvents: (s.uiEvents || []).filter((e) => e.id !== id) };
    }

    case "ADVANCE_ONBOARDING": {
      const step = (s.onboarding?.step || 0) + 1;
      return { ...s, onboarding: { step } };
    }

    case "CLAIM_ACHIEVEMENT": {
      const { id } = action;
      if (!id) return s;
      if (!s.achievements?.[id]) return s;
      if (s.achievementsClaimed?.[id]) return s;
      // simple rewards
      const reward = (id === "big_win") ? 1500 : 600;
      let next = { ...s, tickets: s.tickets + reward, achievementsClaimed: { ...(s.achievementsClaimed||{}), [id]: true } };
      next = pushUiEvent(next, { type: "toast", title: "Achievement claimed", body: `+${reward} tickets` });
      next = pushIcon(next, { emoji: "🏆", text: `+${reward}` });
      return next;
    }

    
case "SET_PLAYER_NAME": {
      const name = (action.name || "").slice(0, 16);
      return { ...s, playerName: name };
    }

    case "BUY_EVENT_PASS": {
      const price = Number(action.priceUsd) || 3;
      if ((s.depositUsdTotal || 0) < price) {
        let out = pushUiEvent(s, { type: "toast", title: "Event Pass", body: `Deposit $${price} total to buy pass.` });
        out = pushIcon(out, { emoji: "💎", text: `$${price}` });
        return out;
      }
      let next = { ...s, eventState: { ...(s.eventState || {}), passOwned: true } };
      next = pushUiEvent(next, { type: "toast", title: "Event Pass", body: "Pass activated (+10% tickets)" });
      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      return next;
    }

    case "BUY_EVENT_ANIMAL": {
      const id = action.id;
      const price = Number(action.priceVisitors) || 950;
      const now = Date.now();
      if (now > (s.eventState?.endsAt || 0)) {
        return pushUiEvent(s, { type: "toast", title: "Event ended", body: "This animal is no longer available." });
      }
      if (s.visitors < price) return s;
      let next = { ...s, visitors: s.visitors - price };
      next.ownedAnimals = { ...(s.ownedAnimals || {}), [id]: (s.ownedAnimals?.[id] || 0) + 1 };
      next.lastBought = { kind: "animal", id, at: now };
      let out = summonEvent(next, "animal", id);
      out = pushUiEvent(out, { type: "toast", title: "Limited animal bought", body: "Neon Fox joined your zoo" });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

    case "CLAIM_INBOX": {
      const id = action.id;
      const item = (s.inbox || []).find((x) => x.id === id);
      if (!item) return s;
      let next = { ...s, inbox: (s.inbox || []).filter((x) => x.id !== id) };
      if (item.tickets) {
        next.tickets += item.tickets;
        next = pushIcon(next, { emoji: "📬", text: `+${item.tickets}` });
      }
      next = pushUiEvent(next, { type: "toast", title: "Claimed", body: item.title });
      return next;
    }

    case "CLAIM_EVENT_QUEST": {
      const id = action.id;
      const q = (s.eventQuests?.list || []).find((x) => x.id === id);
      if (!q || q.claimed || q.progress < q.goal) return s;
      let next = { ...s };
      next.eventPoints = (s.eventPoints || 0) + (q.rewardPts || 0);
      next.eventQuests = { ...s.eventQuests, list: (s.eventQuests?.list || []).map((x) => (x.id === id ? { ...x, claimed: true } : x)) };
      next = pushUiEvent(next, { type: "toast", title: "Quest complete", body: `+${q.rewardPts} event points` });
      next = pushIcon(next, { emoji: "✨", text: `+${q.rewardPts}` });
      return next;
    }

    case "CLAIM_TRACK_TIER": {
      const tier = Number(action.tier);
      const isPass = !!action.isPass;
      const t = (s.eventTrack?.tiers || []).find((x) => x.t === tier);
      if (!t) return s;
      if ((s.eventPoints || 0) < t.need) return s;

      const claimedMap = isPass ? (s.eventTrack?.claimedPass || {}) : (s.eventTrack?.claimedFree || {});
      if (claimedMap[tier]) return s;
      if (isPass && !s.eventState?.passOwned) return s;

      const reward = isPass ? t.pass : t.free;
      let next = { ...s };
      if (reward?.tickets) next.tickets += reward.tickets;

      next.eventTrack = {
        ...s.eventTrack,
        claimedFree: isPass ? (s.eventTrack?.claimedFree || {}) : { ...(s.eventTrack?.claimedFree || {}), [tier]: true },
        claimedPass: isPass ? { ...(s.eventTrack?.claimedPass || {}), [tier]: true } : (s.eventTrack?.claimedPass || {}),
      };

      next = pushUiEvent(next, { type: "toast", title: "Track reward", body: `Tier ${tier} claimed` });
      next = pushIcon(next, { emoji: isPass ? "💎" : "🎁", text: `+${reward?.tickets || 0}` });
      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      return next;
    }

    case "CREATE_DEPOSIT_INTENT": {
      const dep = action.deposit;
      const pay = action.pay;
      if (!dep?.id) return s;
      const intents = { ...(s.depositIntents || {}), [dep.id]: { ...dep, pay } };
      let out = { ...s, depositIntents: intents };
      out = pushUiEvent(out, { type: "toast", title: "Deposit created", body: `Send with comment TONZOO:${dep.id}` });
      return out;
    }

    case "APPLY_CONFIRMED_DEPOSITS": {
      const list = action.confirmed || [];
      if (!Array.isArray(list) || list.length === 0) return s;
      let next = { ...s, lastDepositCheckAt: Date.now() };

      for (const dep of list) {
        if (!dep?.id) continue;
        // prevent double apply
        if ((next.deposits || []).some((d) => d.id === dep.id && d.status === "Confirmed")) continue;

        const usd = Math.max(1, Number(dep.usd) || 1);
        const ssplit = (dep.split || null);
        const tAdd = ssplit ? Number(ssplit.tAdd||0) : (usd * (split.treasury ?? 0.6));
        const pAdd = ssplit ? Number(ssplit.pAdd||0) : (usd * (split.profit ?? 0.3));
        const bAdd = ssplit ? Number(ssplit.bAdd||0) : (usd * (split.buffer ?? 0.1));
        const coinsAdd = ssplit ? Math.floor(Number(ssplit.coinsAdd||0)) : Math.floor(usd * 1000);

        next.deposits = [...(next.deposits || []), { ...dep, status: "Confirmed" }];
        next.hasDeposited = true;
        next.depositUsdTotal = (next.depositUsdTotal || 0) + usd;
        next.treasuryUsd = (next.treasuryUsd || 0) + tAdd;
        next.profitUsd = (next.profitUsd || 0) + pAdd;
        next.bufferUsd = (next.bufferUsd || 0) + bAdd;
        next.coinsPurchase = (next.coinsPurchase || 0) + coinsAdd;
        next.coins = (next.coins || 0) + coinsAdd;
      }

      if (action.ledger) {
        next.treasuryUsd = Number(action.ledger.treasuryUsd || next.treasuryUsd || 0);
        next.profitUsd = Number(action.ledger.profitUsd || next.profitUsd || 0);
        next.bufferUsd = Number(action.ledger.bufferUsd || next.bufferUsd || 0);
        next.withdrawalsPaused = !!action.ledger.withdrawalsPaused;
        next.withdrawFeePct = Number(action.ledger.withdrawFeePct ?? next.withdrawFeePct);
        next.withdrawDelayMs = Number(action.ledger.withdrawDelayMs ?? next.withdrawDelayMs);
        next.withdrawDailyCapUsd = Number(action.ledger.withdrawDailyCapUsd ?? next.withdrawDailyCapUsd);
        next.withdrawWeeklyCapUsd = Number(action.ledger.withdrawWeeklyCapUsd ?? next.withdrawWeeklyCapUsd);
        next.withdrawalsPaidUsdToday = Number(action.ledger.paidTodayUsd ?? next.withdrawalsPaidUsdToday);
        next.withdrawalsPaidUsdWeek = Number(action.ledger.paidWeekUsd ?? next.withdrawalsPaidUsdWeek);
      }
      next = pushUiEvent(next, { type: "celebrate" });
      next = pushUiEvent(next, { type: "toast", title: "Deposit confirmed", body: "Coins credited" });
      return next;
    }

    case "APPLY_SERVER_LEDGER": {
      const l = action.ledger;
      if (!l) return s;
      return {
        ...s,
        treasuryUsd: Number(l.treasuryUsd || 0),
        profitUsd: Number(l.profitUsd || 0),
        bufferUsd: Number(l.bufferUsd || 0),
        withdrawalsPaused: !!l.withdrawalsPaused,
        withdrawFeePct: Number(l.withdrawFeePct ?? s.withdrawFeePct),
        withdrawDelayMs: Number(l.withdrawDelayMs ?? s.withdrawDelayMs),
        withdrawDailyCapUsd: Number(l.withdrawDailyCapUsd ?? s.withdrawDailyCapUsd),
        withdrawWeeklyCapUsd: Number(l.withdrawWeeklyCapUsd ?? s.withdrawWeeklyCapUsd),
        withdrawalsPaidUsdToday: Number(l.paidTodayUsd ?? s.withdrawalsPaidUsdToday),
        withdrawalsPaidUsdWeek: Number(l.paidWeekUsd ?? s.withdrawalsPaidUsdWeek),
      };
    }

    case "ADMIN_SET_TREASURY_CONFIG": {
      const next = { ...s };
      if (action.split) next.treasurySplit = { ...next.treasurySplit, ...action.split };
      if (typeof action.withdrawFeePct === "number") next.withdrawFeePct = Math.max(0, Math.min(0.2, action.withdrawFeePct));
      if (typeof action.withdrawDelayMs === "number") next.withdrawDelayMs = Math.max(0, action.withdrawDelayMs);
      if (typeof action.withdrawDailyCapUsd === "number") next.withdrawDailyCapUsd = Math.max(0, action.withdrawDailyCapUsd);
      if (typeof action.withdrawWeeklyCapUsd === "number") next.withdrawWeeklyCapUsd = Math.max(0, action.withdrawWeeklyCapUsd);
      return next;
    }

    case "ADMIN_TOGGLE_WITHDRAWALS": {
      return { ...s, withdrawalsPaused: !s.withdrawalsPaused };
    }

    case "ADMIN_PROCESS_READY": {
      // Process any Ready withdrawals if delay passed & treasury has enough
      const now2 = now;
      const feePct = s.withdrawFeePct ?? 0.05;
      const delay = s.withdrawDelayMs ?? (24*60*60*1000);

      // reset caps if day/week changed
      let next = { ...s };
      const dk = dayKey(now2);
      const wk = weekKey(now2);
      if ((next.lastWithdrawCapDay || dk) !== dk) { next.withdrawalsPaidUsdToday = 0; next.lastWithdrawCapDay = dk; }
      if ((next.lastWithdrawCapWeek || wk) !== wk) { next.withdrawalsPaidUsdWeek = 0; next.lastWithdrawCapWeek = wk; }

      const capDay = next.withdrawDailyCapUsd ?? 10;
      const capWeek = next.withdrawWeeklyCapUsd ?? 50;

      const ws = (next.withdrawals || []).map((w) => ({ ...w }));
      for (const w of ws) {
        if (w.status !== "Pending") continue;
        if ((w.processAfter || 0) > now2) continue;

        const usd = Number(w.usd) || 0;
        const net = Math.max(0, +(usd * (1 - feePct)).toFixed(2));

        if (next.withdrawalsPaused) { w.status = "Paused"; continue; }
        if ((next.treasuryUsd || 0) < net) { w.status = "Insufficient treasury"; continue; }
        if ((next.withdrawalsPaidUsdToday || 0) + net > capDay) { w.status = "Daily cap reached"; continue; }
        if ((next.withdrawalsPaidUsdWeek || 0) + net > capWeek) { w.status = "Weekly cap reached"; continue; }

        // pay
        next.treasuryUsd = +( (next.treasuryUsd || 0) - net ).toFixed(2);
        next.withdrawalsPaidUsdToday = +( (next.withdrawalsPaidUsdToday || 0) + net ).toFixed(2);
        next.withdrawalsPaidUsdWeek = +( (next.withdrawalsPaidUsdWeek || 0) + net ).toFixed(2);
        w.status = "Paid";
        w.paidAt = now2;
        w.netUsd = net;
      }

      next.withdrawals = ws;
      next = pushUiEvent(next, { type: "toast", title: "Admin", body: "Processed ready withdrawals" });
      return next;
    }

    case "TOGGLE_SOUND": {

      return { ...s, soundOn: !s.soundOn };
    }

    case "FINISH_TUTORIAL": {
      return { ...s, tutorialSeen: true };
    }

    case "RESET":
      return { ...initial, lastAccrueAt: now, dailyResetAt: now };

    case "__TICK__":
      // Just accrue (includes auction advance)
      return s;

    case "BUY_PAVILION": {
      const p = PAVILIONS.find((x) => x.id === action.id);
      if (!p) return s;
      if (s.coinsPurchase < p.priceCoins) return s;

      const next = {
        ...s,
        coinsPurchase: s.coinsPurchase - p.priceCoins,
        ownedPavilions: { ...s.ownedPavilions, [p.id]: (s.ownedPavilions[p.id] || 0) + 1 },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "pavilion_bought", 1);
      next.oneProgress = bumpCounter(next.oneProgress, "pavilion_bought", 1);
      next.lastBought = { kind: "pavilion", id: action.id, at: Date.now() };
      let out = summonEvent(next, "pavilion", action.id);
      out = pushUiEvent(out, { type: "pop", variant: "blue", text: "Pavilion bought" });
      out = pushIcon(out, { emoji: "🎟️", text: "+ tickets/hr" });
      out = unlockAchievement(out, "first_pavilion", "First Pavilion");
      return out;
    }

    
case "BUY_ANIMAL": {

      const a = ANIMALS.find((x) => x.id === action.id);
      if (!a || a.locked) return s;
      if (a.priceVisitors == null) return s;
      if (s.visitors < a.priceVisitors) return s;

      const next = {
        ...s,
        visitors: s.visitors - a.priceVisitors,
        ownedAnimals: { ...s.ownedAnimals, [a.id]: (s.ownedAnimals[a.id] || 0) + 1 },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "animal_bought", 1);
      next.oneProgress = bumpCounter(next.oneProgress, "animal_bought", 1);
      
// Mission progress
if (next.missions?.daily) {
  next.missions.daily = next.missions.daily.map(m =>
    m.id === "buy_animal" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m
  );
}

let out = pushUiEvent(next, { type: "pop", variant: "pink", text: "Animal bought" });

      out = pushIcon(out, { emoji: "👥", text: "+ visitors/day" });
      return out;
    }

    case "EXCHANGE_TICKETS": {
      const batch = Math.floor(s.tickets / 300);
      if (batch <= 0) return s;

      const next = {
        ...s,
        tickets: s.tickets - batch * 300,
        coinsPurchase: s.coinsPurchase + batch * 2,
        coinsWithdraw: s.coinsWithdraw + batch * 1,
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "exchange", 1);
      let out = pushUiEvent(next, { type: "toast", title: "Exchanged tickets", body: `+${batch*2} purchase coins, +${batch} withdraw coins` });
      out = pushIcon(out, { emoji: "🟩", text: `+${batch*2}` });
      out = pushIcon(out, { emoji: "⬜", text: `+${batch}` });
      return out;
    }

    case "SIM_TOPUP": {
      const usd = Math.max(0, Number(action.usd) || 0);
      const visitorsAdd = Math.floor(usd * 300);

      return {
        ...s,
        coinsPurchase: s.coinsPurchase + Math.floor(usd * 1000),
        visitors: s.visitors + visitorsAdd,
        dailyVisitorsGained: (s.dailyVisitorsGained || 0) + visitorsAdd,
      };
    }

    case "BUY_BOOSTER": {
      const b = BOOSTERS.find((x) => x.id === action.id);
      if (b?.requiresDeposit && !s.hasDeposited) {
        pushToast(s, "Deposit $1+ to unlock premium boosters.");
        return s;
      }
      if (!b) return s;

      const cost = b.cost?.coinsPurchase || 0;
      if (s.coinsPurchase < cost) return s;

      let next = { ...s, coinsPurchase: s.coinsPurchase - cost };

      if (b.effect?.freeWheelSpins) {
        next.freeWheelSpins = (next.freeWheelSpins || 0) + b.effect.freeWheelSpins;
      }

      if (b.durationMs && (b.effect?.ticketsMult || b.effect?.visitorsMult)) {
        next.activeBoosters = [
          ...(next.activeBoosters || []),
          { id: b.id, effect: b.effect, expiresAt: now + b.durationMs },
        ];
      }

      return next;
    }

    
case "PLAY_WHEEL": {

      const cost = 50;
      const hasFree = (s.freeWheelSpins || 0) > 0;

      if (!hasFree && s.visitors < cost) return s;

      const outcomes = [
        { tickets: 0, weight: 20, label: "Try Again" },
        { tickets: 200, weight: 25, label: "+200 tickets" },
        { tickets: 500, weight: 20, label: "+500 tickets" },
        { tickets: 1000, weight: 18, label: "+1,000 tickets" },
        { tickets: 2000, weight: 12, label: "+2,000 tickets" },
        { tickets: 5000, weight: 5, label: "+5,000 tickets" },
      ];

      const totalW = outcomes.reduce((a, b) => a + b.weight, 0);
      let r = randInt(1, totalW);
      let pick = outcomes[0];
      for (const o of outcomes) {
        r -= o.weight;
        if (r <= 0) { pick = o; break; }
      }

      const next = {
        ...s,
        visitors: hasFree ? s.visitors : (s.visitors - cost),
        freeWheelSpins: hasFree ? (s.freeWheelSpins - 1) : s.freeWheelSpins,
        tickets: s.tickets + pick.tickets,
        lastGameResult: { game: "wheel", label: pick.label, tickets: pick.tickets, costVisitors: hasFree ? 0 : cost, at: now },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "wheel_spin", 1);
      const celebrate = (pick.tickets || 0) >= 2000;
      
// Mission progress
if (next.missions?.daily) {
  next.missions.daily = next.missions.daily.map(m =>
    m.id === "play_game" ? { ...m, progress: Math.min(m.goal, m.progress + 1) } : m
  );
}

let out = pushUiEvent(next, { type: "pop", variant: celebrate ? "green" : "blue", text: `Wheel win` });

      out = pushIcon(out, { emoji: "🎟️", text: `+${pick.tickets}` });
      if (celebrate) {
        out = pushUiEvent(out, { type: "celebrate" });
        out = unlockAchievement(out, "big_win", "Big Win!");
      }
      return out;
    }

    case "PLAY_SLOTS": {
      const cost = 100;
      if (s.visitors < cost) return s;

      const symbols = ["🦁", "🐧", "🐍", "🐊", "🦜", "🦓"];
      const a = symbols[randInt(0, symbols.length - 1)];
      const b = symbols[randInt(0, symbols.length - 1)];
      const c = symbols[randInt(0, symbols.length - 1)];

      let winTickets = 0;
      let label = "No win";

      if (a === b && b === c) {
        winTickets = 6000;
        label = "JACKPOT! +6,000 tickets";
      } else if (a === b || b === c || a === c) {
        winTickets = 1500;
        label = "Win! +1,500 tickets";
      } else {
        winTickets = 200;
        label = "+200 tickets";
      }

      const next = {
        ...s,
        visitors: s.visitors - cost,
        tickets: s.tickets + winTickets,
        lastGameResult: {
          game: "slots",
          label,
          reels: [a, b, c],
          tickets: winTickets,
          costVisitors: cost,
          at: now,
        },
      };

      next.dailyProgress = bumpCounter(next.dailyProgress, "slots_spin", 1);
      const celebrate = winTickets >= 6000;
      let out = pushUiEvent(next, { type: "pop", variant: celebrate ? "green" : "blue", text: "Slots result" });
      out = pushIcon(out, { emoji: "🎟️", text: `${winTickets >= 0 ? "+" : ""}${winTickets}` });
      out = pushUiEvent(out, { type: "toast", title: "Slots", body: label });
      if (celebrate) {
        out = pushUiEvent(out, { type: "celebrate" });
        out = unlockAchievement(out, "big_win", "Big Win!");
      }
      return out;
    }

    case "PLACE_AUCTION_BID": {
      const bid = Math.max(0, Math.floor(Number(action.bid) || 0));
      if (!s.auction) return s;

      const a = s.auction;
      if (now >= a.endsAt) return s;

      const minNext = (a.highestBid || 0) + (a.minIncrement || 25);
      if (bid < minNext) return s;

      // Additional visitors needed beyond your current bid (escrow)
      const delta = Math.max(0, bid - (a.yourBid || 0));
      if (s.visitors < delta) return s;

      return {
        ...s,
        visitors: s.visitors - delta,
        auction: {
          ...a,
          yourBid: bid,
          highestBid: bid,
          highestBidder: "you",
        },
      };
    }

    case "CLAIM_TASK": {
      const { taskId, scope } = action;
      const isDaily = scope === "daily";

      const def = isDaily
        ? DAILY_TASKS.find((t) => t.id === taskId)
        : ONETIME_TASKS.find((t) => t.id === taskId);

      if (!def) return s;

      if (isDaily && s.dailyClaimed?.[taskId]) return s;
      if (!isDaily && s.oneClaimed?.[taskId]) return s;

      let done = false;

      if (def.kind === "counter") {
        const key = def.event;
        const val = isDaily ? (s.dailyProgress?.[key] || 0) : (s.oneProgress?.[key] || 0);
        done = val >= def.target;
      } else if (def.kind === "accum") {
        const val = s.dailyVisitorsGained || 0;
        done = val >= def.target;
      } else if (def.kind === "state_check") {
        const val = s[def.stateField] || 0;
        done = val >= def.target;
      }

      if (!done) return s;

      let next = applyReward(s, def.reward);

      if (isDaily) {
        next.dailyClaimed = { ...(next.dailyClaimed || {}), [taskId]: true };
      } else {
        next.oneClaimed = { ...(next.oneClaimed || {}), [taskId]: true };
      }

      return next;
    }
case "RECORD_DEPOSIT": {
      const amountTon = Math.max(0, Number(action.amountTon) || 0);
      if (amountTon <= 0) return s;

      const dep = {
        id: "dep_" + (crypto.randomUUID?.() || String(Math.random())),
        amountTon: Number(amountTon.toFixed(4)),
        usd: Math.max(0, Number(action.usd) || 0),
        treasury: action.treasury || "",
        status: "Pending",
        createdAt: now,
      };

      return { ...s, deposits: [...(s.deposits || []), dep] };
    }

    case "CONFIRM_DEPOSIT": {
      const id = action.id;
      const deps = (s.deposits || []).map((d) =>
        d.id === id ? { ...d, status: "Confirmed", confirmedAt: now } : d
      );
      const dep = (s.deposits || []).find((d) => d.id === id);
      const usd = Math.max(0, Number(dep?.usd) || 0) || 1; // fallback to $1 minimum for prototype
      const wasConfirmed = (dep?.status === "Confirmed");
      if (wasConfirmed) return s;

      const split = s.treasurySplit || { treasury: 0.6, profit: 0.3, buffer: 0.1 };
      const tAdd = usd * (split.treasury ?? 0.6);
      const pAdd = usd * (split.profit ?? 0.3);
      const bAdd = usd * (split.buffer ?? 0.1);
      const coinsAdd = Math.floor(usd * 1000);
      let out = { ...s, deposits: deps, hasDeposited: true, depositUsdTotal: (s.depositUsdTotal || 0) + usd,
        treasuryUsd: (s.treasuryUsd || 0) + tAdd,
        profitUsd: (s.profitUsd || 0) + pAdd,
        bufferUsd: (s.bufferUsd || 0) + bAdd,
        coinsPurchase: (s.coinsPurchase || 0) + coinsAdd,
        coins: (s.coins || 0) + coinsAdd,
      };
      out = pushUiEvent(out, { type: "toast", title: "Deposit confirmed", body: "Deposit-only animal unlocked" });
      out = pushIcon(out, { emoji: "💎", text: "Unlocked" });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

    case "PROCESS_WITHDRAWAL": {
      const { id, status } = action;
      if (!id || !status) return s;
      const ws = (s.withdrawals || []).map((w) =>
        w.id === id ? { ...w, status } : w
      );
      return { ...s, withdrawals: ws };
    }

    case "SIM_DEPOSIT": {
      const usd = Math.max(1, Number(action.usd) || 1);
      const amountTon = Math.max(0.1, Number(action.amountTon) || Number((usd / 5).toFixed(3))); // rough
      const id = "dep_" + (crypto.randomUUID?.() || String(Math.random()));
      const dep = {
        id,
        amountTon: Number(amountTon.toFixed(4)),
        usd,
        treasury: action.treasury || "",
        status: "Confirmed",
        createdAt: now,
        confirmedAt: now,
      };

      // split
      const split = s.treasurySplit || { treasury: 0.6, profit: 0.3, buffer: 0.1 };
      const tAdd = usd * (split.treasury ?? 0.6);
      const pAdd = usd * (split.profit ?? 0.3);
      const bAdd = usd * (split.buffer ?? 0.1);

      // credit purchased coins ($1 = 1000 coins)
      const coinsAdd = Math.floor(usd * 1000);

      let out = {
        ...s,
        deposits: [...(s.deposits || []), dep],
        hasDeposited: true,
        depositUsdTotal: (s.depositUsdTotal || 0) + usd,
        treasuryUsd: (s.treasuryUsd || 0) + tAdd,
        profitUsd: (s.profitUsd || 0) + pAdd,
        bufferUsd: (s.bufferUsd || 0) + bAdd,
        coinsPurchase: (s.coinsPurchase || 0) + coinsAdd,
        coins: (s.coins || 0) + coinsAdd,
      };

      out = pushUiEvent(out, { type: "toast", title: "Demo deposit", body: `+$${usd} → +${coinsAdd} coins` });
      out = pushIcon(out, { emoji: "💰", text: `+$${usd}` });
      out = pushUiEvent(out, { type: "celebrate" });
      return out;
    }

case "CLAIM_BONUS_ANIMAL": {
  // Claim deposit-only bonus animal once for free (1A)
  if (!s.hasDeposited) return s;
  if (s.bonusAnimalClaimed) return s;
  const id = "ton_panther";
  return {
    ...s,
    bonusAnimalClaimed: true,
    ownedAnimals: { ...s.ownedAnimals, [id]: (s.ownedAnimals[id] || 0) + 1 },
  };
}

case "SET_REFERRER": {
      const code = (action.code || "").trim();
      if (!code) return s;
      // prevent self-ref (when referral code exists)
      if (code && s.referral?.code && code === s.referral.code) return s;
      if (s.referredBy) return s; // only set once in prototype
      return { ...s, referredBy: code };
    }

    case "SIM_REF_INVITE": {

  const invited = (s.referral?.invited || 0) + 1;
  // In prototype, randomly mark some invited as active
  const active = (s.referral?.active || 0) + (Math.random() < 0.6 ? 1 : 0);
  return {
    ...s,
    referral: { ...(s.referral || {}), invited, active, claimed: (s.referral?.claimed || {}) },
  };
}

case "CLAIM_REF_MILESTONE": {
  const k = Number(action.k) || 0;
  const m = REF_MILESTONES.find((x) => x.k === k);
  if (!m) return s;
  const claimed = !!s.referral?.claimed?.[k];
  if (claimed) return s;
  if ((s.referral?.invited || 0) < k) return s;

  const next = applyReward(s, m.reward);
  return {
    ...next,
    referral: {
      ...(next.referral || {}),
      claimed: { ...(next.referral?.claimed || {}), [k]: true },
    },
  };
}


    
case "CLAIM_MISSION": {
  const { scope, id } = action;
  const list = s.missions?.[scope] || [];
  const m = list.find(x => x.id === id);
  if (!m || m.progress < m.goal) return s;

  let next = { ...s };
  if (m.reward?.tickets) {
    next.tickets += m.reward.tickets;
    next = pushIcon(next, { emoji: "🎯", text: `+${m.reward.tickets}` });
  }
  next.missions[scope] = list.filter(x => x.id !== id);
  next = pushUiEvent(next, { type: "toast", title: "Mission complete", body: m.title });
      // Event quest progress
      if (next.eventQuests?.list) {
        next.eventQuests = { ...next.eventQuests, list: next.eventQuests.list.map(q => q.id === "eq_claim" ? { ...q, progress: Math.min(q.goal, q.progress + 1) } : q) };
      }
  next = pushUiEvent(next, { type: "celebrate" });
  return next;
}

case "REQUEST_WITHDRAW": {

      const wallet = (action.wallet || "").trim();
      const coins = Math.max(0, Math.floor(Number(action.coins) || 0));
      const feePct = s.withdrawFeePct ?? 0.05;
      const delay = s.withdrawDelayMs ?? (24*60*60*1000);
      if (coins < 1000) return s;
      if ((s.depositUsdTotal || 0) < 1) return s;
      if (s.withdrawalsPaused) return s;
      if (s.visitors < 1000) return s;
      if (s.coinsWithdraw < coins) return s;
      const usd = +(coins / 1000).toFixed(2);
      const net = Math.max(0, +(usd * (1 - feePct)).toFixed(2));
      if (wallet.length < 10) return s;

      const next = {
        ...s,
        coinsWithdraw: s.coinsWithdraw - coins,
        withdrawals: [
          ...s.withdrawals,
          {
            id: (action.id || (crypto.randomUUID?.() || String(Math.random()))),
            processAfter: now + delay,
            feePct,
            netUsd: net,
            wallet,
            coins,
            usd: coins / 1000,
            status: "Pending",
            createdAt: now,
          },
        ],
      };
      let out = pushUiEvent(next, { type: "toast", title: "Withdrawal requested", body: "Added to queue (prototype)" });
      out = pushIcon(out, { emoji: "⬜", text: `-${coins}` });
      return out;
    }

    case "PLACE_ANIMAL_SLOT": {
  state = ensureZooSystems(state);
  const { slotId, animalId } = action;
  const slot = state.zooSlots?.find(s => s.slotId === slotId);
  if (!slot || !slot.unlocked) return state;

  const owned = state.ownedAnimals?.[animalId] || 0;
  const placed = placedCounts(state);
  // if replacing, free old first
  const prev = slot.animalId;
  if (prev) placed[prev] = Math.max(0, (placed[prev]||0) - 1);

  if (owned <= (placed[animalId]||0)) {
    pushToast(state, "Not enough copies owned to place.");
    return state;
  }
  slot.animalId = animalId;
  pushToast(state, "Placed in zoo ✅");
  return state;
}

case "REMOVE_ANIMAL_SLOT": {
  state = ensureZooSystems(state);
  const { slotId } = action;
      const needP = prestigeRequiredForSlot(slotId);
      const curP = calcPrestige(state);
      if (needP > 0 && curP < needP) {
        pushToast(state, `Need Prestige ${needP}+ to unlock this pen.`);
        return state;
      }
  const slot = state.zooSlots?.find(s => s.slotId === slotId);
  if (!slot) return state;
  slot.animalId = null;
  pushToast(state, "Removed from pen.");
  return state;
}

case "LEVEL_UP_ANIMAL": {
  state = ensureZooSystems(state);
  const { animalId } = action;
  const def = ANIMALS.find(a => a.id === animalId);
  if (!def) return state;
  const cur = levelFor(state, animalId);
  const max = def.maxLevel || 20;
  if (cur >= max) { pushToast(state, "Max level reached."); return state; }

  const next = cur + 1;
  const cost = levelUpCostCoins(animalId, next);
  if ((state.coinsPurchase||0) < cost) {
    pushToast(state, "Not enough purchase coins.");
    return state;
  }
  state.coinsPurchase -= cost;
  state.animalLevels[animalId] = next;
  pushToast(state, `Level up! ${def.name} → Lv.${next}`);
  pushReward(state, { kind: "levelup", animalId, level: next });
  return state;
}

case "PAY_UPKEEP": {
  state = ensureZooSystems(state);
  state = ensureShop(state);
  const now = Date.now();
  const due = upkeepDue(state, now);
  if (due <= 0) { pushToast(state, "Upkeep already paid ✅"); return state; }
  if ((state.coinsPurchase || 0) < due) { pushToast(state, "Not enough purchase coins to pay upkeep."); return state; }
  state.coinsPurchase -= due;
  state.upkeepPaidThroughDay = dayKey(now);
  pushToast(state, `Upkeep paid (-${due} 🟩)`);
  return state;
}

case "REROLL_SHOP": {
  state = ensureShop(state);
  const now = Date.now();
  const today = dayKey(now);
  if ((state.shopRerollDay ?? today) !== today) {
    state.shopRerollDay = today;
    state.shopRerollsToday = 0;
  }
  const cost = shopRerollCost(state, now);
  if ((state.coinsPurchase || 0) < cost) { pushToast(state, "Not enough purchase coins to reroll."); return state; }
  state.coinsPurchase -= cost;
  state.shopRerollsToday = (state.shopRerollsToday || 0) + 1;
  const ids = ANIMALS.map(a => a.id);
  const pick = [];
  while (pick.length < Math.min(5, ids.length)){
    const id = ids[Math.floor(Math.random()*ids.length)];
    if (!pick.includes(id)) pick.push(id);
  }
  state.shopAnimalIds = pick;
  pushToast(state, `Shop rerolled (-${cost} 🟩)`);
  return state;
}

case "UNLOCK_ZOO_SLOT": {
  state = ensureZooSystems(state);
  const { slotId } = action;
  const slot = state.zooSlots?.find(s => s.slotId === slotId);
  if (!slot || slot.unlocked) return state;
  const cost = unlockSlotCostCoins(slotId);
  if ((state.coinsPurchase||0) < cost) {
    pushToast(state, "Not enough purchase coins to unlock.");
    return state;
  }
  state.coinsPurchase -= cost;
  slot.unlocked = true;
  pushToast(state, "New pen unlocked 🧱");
  pushReward(state, { kind: "unlock", slotId });
  return state;
}
case "PLAY_CARD_FLIP": {
  const cost = 400; // tickets
  if ((s.tickets || 0) < cost) return s;

  const cards = [
    { coins: 40, weight: 45, label: "+40 🟩" },
    { coins: 120, weight: 35, label: "+120 🟩" },
    { coins: 320, weight: 20, label: "+320 🟩" },
  ];
  const totalW = cards.reduce((a,b)=>a+b.weight,0);
  let r = randInt(1, totalW);
  let pick = cards[0];
  for (const c of cards){ r -= c.weight; if (r<=0){ pick=c; break; } }

  const next = {
    ...s,
    tickets: s.tickets - cost,
    coinsPurchase: (s.coinsPurchase || 0) + pick.coins,
    lastGameResult: { game: "card", label: pick.label, coins: pick.coins, costTickets: cost, at: now },
  };
  next.dailyProgress = bumpCounter(next.dailyProgress, "card_flip", 1);

  let out = pushUiEvent(next, { type:"pop", variant: pick.coins >= 320 ? "green" : "blue", text:"Card Flip" });
  out = pushIcon(out, { emoji:"🟩", text:`+${pick.coins}` });
  if (pick.coins >= 320){
    out = pushUiEvent(out, { type:"celebrate" });
    out = unlockAchievement(out, "card_big", "Lucky Flip!");
  }
  return out;
}

case "PLAY_COIN_RUSH": {
  const cost = 150; // visitors
  if ((s.visitors || 0) < cost) return s;

  const o = [
    { coins: 25, w: 60, label:"+25 🟩" },
    { coins: 90, w: 30, label:"+90 🟩" },
    { coins: 250, w: 10, label:"+250 🟩" },
  ];
  const totalW = o.reduce((a,b)=>a+b.w,0);
  let r = randInt(1, totalW);
  let pick = o[0];
  for (const c of o){ r -= c.w; if (r<=0){ pick=c; break; } }

  const next = {
    ...s,
    visitors: s.visitors - cost,
    coinsPurchase: (s.coinsPurchase || 0) + pick.coins,
    lastGameResult: { game:"rush", label: pick.label, coins: pick.coins, costVisitors: cost, at: now },
  };
  next.dailyProgress = bumpCounter(next.dailyProgress, "coin_rush", 1);

  let out = pushUiEvent(next, { type:"pop", variant: pick.coins >= 250 ? "green" : "blue", text:"Coin Rush" });
  out = pushIcon(out, { emoji:"🟩", text:`+${pick.coins}` });
  if (pick.coins >= 250){
    out = pushUiEvent(out, { type:"celebrate" });
  }
  return out;
}

case "EXCHANGE_TICKETS": {
  let next = { ...s };
  next = ensureTicketExchange(next);
  const want = Math.max(0, Math.floor(action.tickets || 0));
  if (want < 1000) { pushToast(next, "Minimum exchange is 1,000 tickets."); return next; }
  const dailyCap = 20000; // tickets/day
  const remaining = Math.max(0, dailyCap - (next.ticketExchangeUsed || 0));
  const amount = Math.min(want, remaining, next.tickets || 0);
  if (amount < 1000) { pushToast(next, "Daily exchange cap reached."); return next; }

  const coins = ticketExchangeRateCoins(amount);
  next.tickets -= amount;
  next.coinsPurchase = (next.coinsPurchase || 0) + coins;
  next.ticketExchangeUsed = (next.ticketExchangeUsed || 0) + amount;

  pushToast(next, `Exchanged ${amount.toLocaleString()} 🎟️ → +${coins} 🟩`);
  return next;
}

case "DAILY_CHECKIN": {
  let next = { ...s };
  next = ensureVisitorsLoop(next);
  const today = dayKey(now);
  if (next.lastCheckInDay === today){
    pushToast(next, "Already checked in today.");
    return next;
  }
  const yd = dayKey(now - 86400000);
  if (next.streakDay === yd) next.streakCount = (next.streakCount || 0) + 1;
  else next.streakCount = 1;
  next.streakDay = today;
  next.lastCheckInDay = today;

  const bonusVisitors = 200 + Math.min(10, next.streakCount) * 40;
  const bonusTickets = 150 + Math.min(10, next.streakCount) * 25;

  next.visitors = (next.visitors || 0) + bonusVisitors;
  next.tickets = (next.tickets || 0) + bonusTickets;

  next.dailyProgress = bumpCounter(next.dailyProgress, "check_in", 1);

  pushToast(next, `Daily check-in: +${bonusVisitors} 👥 and +${bonusTickets} 🎟️`);
  next = pushUiEvent(next, { type:"pop", variant:"green", text:"Check-in!" });
  next = pushIcon(next, { emoji:"👥", text:`+${bonusVisitors}` });
  return next;
}

case "BUY_MARKETING_UP": {
  let next = { ...s };
  next = ensureVisitorsLoop(next);
  const cost = marketingUpgradeCost(next.marketingLevel || 0);
  if ((next.coinsPurchase || 0) < cost){
    pushToast(next, "Not enough purchase coins.");
    return next;
  }
  next.coinsPurchase -= cost;
  next.marketingLevel = (next.marketingLevel || 0) + 1;
  pushToast(next, `Marketing upgraded to L${next.marketingLevel}.`);
  return next;
}

case "BUY_ATTRACTION_UP": {
  let next = { ...s };
  next = ensureVisitorsLoop(next);
  const cost = attractionUpgradeCost(next.attractionLevel || 0);
  if ((next.coinsPurchase || 0) < cost){
    pushToast(next, "Not enough purchase coins.");
    return next;
  }
  next.coinsPurchase -= cost;
  next.attractionLevel = (next.attractionLevel || 0) + 1;
  pushToast(next, `Attractions upgraded to L${next.attractionLevel}.`);
  return next;
}

case "ACTIVATE_MARKETING_BOOST": {
  let next = { ...s };
  next = ensureVisitorsLoop(next);
  const cost = marketingBoostCost();
  if ((next.tickets || 0) < cost){
    pushToast(next, "Not enough tickets.");
    return next;
  }
  next.tickets -= cost;
  next.marketingBoostUntil = now + 2*60*60*1000;
  pushToast(next, "Marketing boost active for 2 hours!");
  next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Boost!" });
  return next;
}

case "CLAIM_COLLECTION": {
  const key = action.key;
  const now = Date.now();
  const r = next.collectionRewards || (next.collectionRewards = {});
  const entry = r[key];
  if (!entry || entry.claimed) return next;
  entry.claimed = true;
  entry.claimedAt = now;
  // reward chest
  const amount = 600; // Phase 38: claimable chest feels better
  next.tickets = (next.tickets || 0) + amount;
  next = pushUiEvent(next, { type:"celebrate" });
  next = pushUiEvent(next, { type:"pop", variant:"green", text:`Claimed +${amount} 🎟️` });
  next = pushIcon(next, { emoji:"🎟️", text:`+${amount}` });
  pushToast(next, `Reward claimed: ${entry.title || key}`);
  return next;
}
case "PLAN_ADD": {
  const id = action.id;
  if (!id) return next;
  const plan = next.buyPlan || (next.buyPlan = []);
  if (!plan.includes(id)) plan.unshift(id);
  next = pushUiEvent(next, { type:"toast", title:"Added to Plan", body:String(id).replace("_"," ") });
  return next;
}
case "PLAN_REMOVE": {
  const id = action.id;
  next.buyPlan = (next.buyPlan || []).filter(x => x !== id);
  return next;
}
case "PLAN_CLEAR": {
  next.buyPlan = [];
  next.planNotified = {};
  return next;
}
case "PLAN_AUTOBUY_SET": {
  next.autoBuyPlan = !!action.on;
  next = ensureAutoBuy(next);
  return next;
}
case "PLAN_AUTOBUY_LIMIT": {
  const n = Math.max(0, Math.min(10, Number(action.n || 0)));
  next.autoBuyDailyLimit = n;
  next = ensureAutoBuy(next);
  return next;
}
case "ZONE_UNLOCK": {
  const id = action.zoneId;
  next = ensureZones(next);
  const defs = zoneDefs();
  const d = defs.find(x => x.id === id);
  if (!d) return next;
  const z = next.zones[id];
  if (z.unlocked) return next;

  const req = zoneUnlockRequirements(next, id);
  if (!req.ok){
    next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Locked" });
    pushToast(next, req.text || "Requirement not met.");
    return next;
  }

  const cost = d.unlockCost || 0;
  if ((next.visitors || 0) < cost){
    next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Need more visitors" });
    return next;
  }

  next.visitors = (next.visitors || 0) - cost;
  z.unlocked = true;
  z.level = 1;
  next = pushUiEvent(next, { type:"celebrate" });
  next = pushUiEvent(next, { type:"pop", variant:"green", text:`Unlocked ${d.name}` });
  next = pushIcon(next, { emoji:d.emoji || "🗺️", text:"New Zone" });
  pushToast(next, `${d.name} unlocked! Visitors/day boosted.`);
  return next;
}

case "ZONE_UPGRADE": {
  const id = action.zoneId;
  next = ensureZones(next);
  const defs = zoneDefs();
  const d = defs.find(x => x.id === id);
  if (!d) return next;
  const z = next.zones[id];
  if (!z.unlocked){
    next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Unlock first" });
    return next;
  }
  const nextLevel = Math.min(d.maxLevel || 10, (z.level || 1) + 1);
  if (nextLevel === (z.level || 1)) return next;
  const cost = zoneUpgradeCost(id, nextLevel);
  if ((next.visitors || 0) < cost){
    next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Need more visitors" });
    return next;
  }
  next.visitors = (next.visitors || 0) - cost;
  z.level = nextLevel;
  next = pushUiEvent(next, { type:"pop", variant:"green", text:`${d.name} Lv.${nextLevel}` });
  next = pushIcon(next, { emoji:"⬆️", text:`Lv.${nextLevel}` });
  return next;
}
case "ZONE_QUEST_CLAIM": {
  const zoneId = action.zoneId;
  const questId = action.questId;
  next = ensureZoneQuests(next);
  const list = (next.zoneQuests && next.zoneQuests[zoneId]) ? next.zoneQuests[zoneId] : [];
  const q = list.find(x => x.id === questId);
  if (!q) return next;
  if (q.claimed) return next;
  if (!isQuestComplete(next, q)){
    next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Not complete yet" });
    return next;
  }
  q.claimed = true;
  q.claimedAt = Date.now();
  next = applyQuestReward(next, q);
  return next;
}
case "COSMETIC_BUY": {
  const id = action.cosmeticId;
  const item = cosmeticsCatalog().find(x => x.id === id);
  if (!item) return next;
  next.cosmeticsOwned = next.cosmeticsOwned || {};
  if (next.cosmeticsOwned[id]){
    next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Already owned" });
    return next;
  }
  const cost = Number(item.cost || 0);
  if ((next.zoneTickets || 0) < cost){
    next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Need more zone tickets" });
    return next;
  }
  next.zoneTickets = (next.zoneTickets || 0) - cost;
  next.cosmeticsOwned[id] = true;
  next = pushUiEvent(next, { type:"pop", variant:"green", text:"Cosmetic unlocked!" });
  next = pushIcon(next, { emoji:"✨", text:item.name });
  pushToast(next, `Unlocked cosmetic: ${item.name}`);
  return next;
}

case "COSMETIC_EQUIP": {
  const slot = action.slot;
  const id = action.cosmeticId;
  next.cosmeticsEquipped = next.cosmeticsEquipped || { border:null, nameplate:null, profileIcon:null };
  if (!id){
    next.cosmeticsEquipped[slot] = null;
    return next;
  }
  next.cosmeticsOwned = next.cosmeticsOwned || {};
  if (!next.cosmeticsOwned[id]){
    next = pushUiEvent(next, { type:"pop", variant:"pink", text:"Buy first" });
    return next;
  }
  const item = cosmeticsCatalog().find(x => x.id === id);
  if (!item) return next;
  next.cosmeticsEquipped[slot] = id;
  next = pushUiEvent(next, { type:"pop", variant:"green", text:`Equipped ${item.name}` });
  return next;
}
case "COSMETIC_PRESET_SAVE": {
  const key = action.key;
  next.cosmeticPresets = next.cosmeticPresets || {};
  next.cosmeticsEquipped = next.cosmeticsEquipped || { border:null, nameplate:null, profileIcon:null };
  const p = next.cosmeticPresets[key] || { name: `Preset ${key}`, slots: {} };
  p.slots = { ...next.cosmeticsEquipped };
  next.cosmeticPresets[key] = p;
  next = pushUiEvent(next, { type:"pop", variant:"green", text:"Preset saved" });
  return next;
}

case "COSMETIC_PRESET_LOAD": {
  const key = action.key;
  next.cosmeticPresets = next.cosmeticPresets || {};
  const p = next.cosmeticPresets[key];
  if (!p || !p.slots) return next;
  next.cosmeticsEquipped = next.cosmeticsEquipped || { border:null, nameplate:null, profileIcon:null };
  next.cosmeticsEquipped = { ...next.cosmeticsEquipped, ...p.slots };
  next = pushUiEvent(next, { type:"pop", variant:"green", text:`Loaded ${p.name || "Preset"}` });
  return next;
}

case "COSMETIC_PRESET_RENAME": {
  const key = action.key;
  const name = String(action.name || "").slice(0,24);
  next.cosmeticPresets = next.cosmeticPresets || {};
  const p = next.cosmeticPresets[key] || { name: "Preset", slots: { border:null, nameplate:null, profileIcon:null } };
  p.name = name || p.name || "Preset";
  next.cosmeticPresets[key] = p;
  return next;
}
default:
      return s;
  }
}

export function useGameState() {
  const [state, dispatch] = useReducer(reducer, undefined, loadState);

  useEffect(() => {
    const t = setInterval(() => dispatch({ type: "__TICK__" }), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    saveState(state);
  }, [state]);

  const derived = useMemo(() => ({
    ticketsPerHour: Math.floor(ticketsPerHourTotal(state)),
    visitorsPerDay: Math.floor(visitorsPerDayTotal(state)),
  }), [state]);

  const actions = useMemo(() => ({
    toast: (msg) => dispatch({ type: "PUSH_TOAST", msg }),
    buyPavilion: (id) => dispatch({ type: "BUY_PAVILION", id }),
    buyAnimal: (id) => dispatch({ type: "BUY_ANIMAL", id }),
    placeAnimalSlot: (slotId, animalId) => dispatch({ type: "PLACE_ANIMAL_SLOT", slotId, animalId }),
    removeAnimalSlot: (slotId) => dispatch({ type: "REMOVE_ANIMAL_SLOT", slotId }),
    levelUpAnimal: (animalId) => dispatch({ type: "LEVEL_UP_ANIMAL", animalId }),
    unlockZooSlot: (slotId) => dispatch({ type: "UNLOCK_ZOO_SLOT", slotId }),
    payUpkeep: () => dispatch({ type: "PAY_UPKEEP" }),
    rerollShop: () => dispatch({ type: "REROLL_SHOP" }),
    exchangeTickets: () => dispatch({ type: "EXCHANGE_TICKETS" }),
    simTopUp: (usd) => dispatch({ type: "SIM_TOPUP", usd }),
    playWheel: () => dispatch({ type: "PLAY_WHEEL" }),
    playCardFlip: () => dispatch({ type: "PLAY_CARD_FLIP" }),
    playCoinRush: () => dispatch({ type: "PLAY_COIN_RUSH" }),
    exchangeTickets: (tickets) => dispatch({ type: "EXCHANGE_TICKETS", tickets }),
    dailyCheckIn: () => dispatch({ type: "DAILY_CHECKIN" }),
    buyMarketingUpgrade: () => dispatch({ type: "BUY_MARKETING_UP" }),
    buyAttractionUpgrade: () => dispatch({ type: "BUY_ATTRACTION_UP" }),
    activateMarketingBoost: () => dispatch({ type: "ACTIVATE_MARKETING_BOOST" }),
    playSlots: () => dispatch({ type: "PLAY_SLOTS" }),
    buyBooster: (id) => dispatch({ type: "BUY_BOOSTER", id }),
    placeAuctionBid: (bid) => dispatch({ type: "PLACE_AUCTION_BID", bid }),
    recordDeposit: ({ amountTon, usd, treasury }) => dispatch({ type: "RECORD_DEPOSIT", amountTon, usd, treasury }),
    confirmDeposit: (id) => dispatch({ type: "CONFIRM_DEPOSIT", id }),
    simDeposit: (usd, amountTon, treasury) => dispatch({ type: "SIM_DEPOSIT", usd, amountTon, treasury }),

    
createDepositIntent: async (currency, usd, expectedNano) => {
  const userId = s.userId || "local";
  const res = await fetch(`${API_BASE}/api/deposits/create`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, currency, usd, expectedNano })
  });
  const j = await res.json();
  if (j?.deposit?.id) dispatch({ type: "CREATE_DEPOSIT_INTENT", deposit: j.deposit, pay: j.pay });
  return j;
},

registerReferral: async () => {
  try{
    const userId = s.userId || "local";
    const ref = detectReferrerId();
    if (!ref) return;
    if (s.referrerId) return;
    await fetch(`${API_BASE}/api/referrals/register`, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ userId, referrerId: ref })
    });
    dispatch({ type:"SET_REFERRER", referrerId: ref });
  }catch{}
},

fetchReferralStatus: async () => {
  try{
    const userId = s.userId || "local";
    const res = await fetch(`${API_BASE}/api/referrals/status?userId=${encodeURIComponent(userId)}`);
    const j = await res.json();
    if (j?.ok && j.referral){
      dispatch({ type:"APPLY_REFERRAL_STATUS", referral: j.referral });
    }
  }catch{}
},

claimReferralRewards: async () => {
  try{
    const userId = s.userId || "local";
    const res = await fetch(`${API_BASE}/api/referrals/claim`, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ userId })
    });
    const j = await res.json();
    if (j?.ok && j.coins){
      dispatch({ type:"CLAIM_REFERRAL_REWARDS", coins: j.coins });
    }
    return j;
  }catch{}
  return null;
},
fetchWithdrawalsServer: async () => {
  try{
    const userId = s.userId || "local";
    const res = await fetch(`${API_BASE}/api/withdrawals/list?userId=${encodeURIComponent(userId)}`);
    const j = await res.json();
    if (j?.ok && Array.isArray(j.withdrawals)){
      dispatch({ type:"SET_WITHDRAWALS", withdrawals: j.withdrawals });
    }
  }catch{}
},
syncProfile: async () => {
  try{
    const userId = s.userId || "local";
    const name = (s.playerName || "Player").trim() || "Player";
    const visitors = s.visitors || 0;
    const prestige = derived.prestige || 0;
    const coinsPurchase = s.coinsPurchase || 0;
    const res = await fetch(`${API_BASE}/api/profile/sync`, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ userId, name, coinsPurchase, visitors, prestige })
    });
    const j = await res.json();
    if (j?.ok && j.profile){
      dispatch({ type:"APPLY_SERVER_PROFILE", profile: j.profile });
    }
  }catch{}
},
reportLeaderboard: async () => {
  try{
    const userId = s.userId || "local";
    const name = (s.playerName || "Player").trim() || "Player";
    const visitors = s.visitors || 0;
    const prestige = derived.prestige || 0;
    await fetch(`${API_BASE}/api/leaderboard/report`, {
      method: "POST",
      headers: { "Content-Type":"application/json" },
      body: JSON.stringify({ userId, name, visitors, prestige })
    });
  }catch{}
},
refreshLedger: async () => {
      const res = await fetch(`${API_BASE}/api/admin/status`);
      const j = await res.json();
      if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },

    
requestWithdrawServer: async (address, currency, coins) => {
  const usd = +(Math.floor(coins) / 1000).toFixed(2);
  const userId = s.userId || "local";
  const res = await fetch(`${API_BASE}/api/withdrawals/request`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, address, currency, usd, coins })
  });
  const j = await res.json();
  if (!res.ok) {
    dispatch({ type: "PUSH_TOAST", msg: j?.error || "Withdrawal request failed." });
  }
  if (j?.cooldownMsLeft) {
    const mins = Math.ceil(j.cooldownMsLeft / 60000);
    dispatch({ type: "PUSH_TOAST", msg: `Cooldown: wait ~${mins} min before withdrawing.` });
  }
  if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
  return j;
},

processWithdrawalsServer: async () => {
      const res = await fetch(`${API_BASE}/api/withdrawals/process`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      const j = await res.json();
      if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      if (j?.paid?.length) dispatch({ type: "APPLY_PAID_WITHDRAWALS", paid: j.paid });
      return j;
    },

    demoConfirmDeposit: async (id) => {
      const res = await fetch(`${API_BASE}/api/demo/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      const j = await res.json();
      if (j?.confirmed?.length) dispatch({ type: "APPLY_CONFIRMED_DEPOSITS", confirmed: j.confirmed, ledger: j.ledger });
      else if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },

    checkDeposits: async () => {
      const res = await fetch(`${API_BASE}/api/deposits/check`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 60 })
      });
      const j = await res.json();
      if (j?.confirmed?.length) dispatch({ type: "APPLY_CONFIRMED_DEPOSITS", confirmed: j.confirmed, ledger: j.ledger });
      else if (j?.ledger) dispatch({ type: "APPLY_SERVER_LEDGER", ledger: j.ledger });
      return j;
    },
    adminProcessReady: () => dispatch({ type: "ADMIN_PROCESS_READY" }),
    adminToggleWithdrawals: () => dispatch({ type: "ADMIN_TOGGLE_WITHDRAWALS" }),
    adminSetTreasuryConfig: (cfg) => dispatch({ type: "ADMIN_SET_TREASURY_CONFIG", ...cfg }),
    processWithdrawal: (id, status) => dispatch({ type: "PROCESS_WITHDRAWAL", id, status }),
    simulateDeposit: () => dispatch({ type: "SIM_DEPOSIT" }),
    claimBonusAnimal: () => dispatch({ type: "CLAIM_BONUS_ANIMAL" }),
    simulateInvite: () => dispatch({ type: "SIM_REF_INVITE" }),
    claimReferralMilestone: (k) => dispatch({ type: "CLAIM_REF_MILESTONE", k }),
    setReferrer: (code) => dispatch({ type: "SET_REFERRER", code }),
    claimTask: (taskId, scope) => dispatch({ type: "CLAIM_TASK", taskId, scope }),
    requestWithdraw: ({ wallet, coins }) => dispatch({ type: "REQUEST_WITHDRAW", wallet, coins }),
    ackUiEvent: (id) => dispatch({ type: "ACK_UI_EVENT", id }),
    claimMission: (scope, id) => dispatch({ type: "CLAIM_MISSION", scope, id }),
    advanceOnboarding: () => dispatch({ type: "ADVANCE_ONBOARDING" }),
    toggleSound: () => dispatch({ type: "TOGGLE_SOUND" }),
    claimAchievement: (id) => dispatch({ type: "CLAIM_ACHIEVEMENT", id }),
    setPlayerName: (name) => dispatch({ type: "SET_PLAYER_NAME", name }),
    buyEventPass: (priceUsd) => dispatch({ type: "BUY_EVENT_PASS", priceUsd }),
    buyEventAnimal: (id, priceVisitors) => dispatch({ type: "BUY_EVENT_ANIMAL", id, priceVisitors }),
    claimEventQuest: (id) => dispatch({ type: "CLAIM_EVENT_QUEST", id }),
    claimTrackTier: (tier, isPass) => dispatch({ type: "CLAIM_TRACK_TIER", tier, isPass }),
    claimInbox: (id) => dispatch({ type: "CLAIM_INBOX", id }),
    finishTutorial: () => dispatch({ type: "FINISH_TUTORIAL" }),
    reset: () => dispatch({ type: "RESET" }),
  }), []);

  // Phase 29: referral registration + status poll
useEffect(() => {
  actions.registerReferral();
  actions.fetchReferralStatus();
  const id = setInterval(() => actions.fetchReferralStatus(), 45000);
  return () => clearInterval(id);
}, [s.userId, s.referrerId]);

// Phase 30: server profile sync (balances)
useEffect(() => {
  actions.syncProfile();
  const id = setInterval(() => actions.syncProfile(), 30000);
  return () => clearInterval(id);
}, [s.userId, s.playerName, s.visitors, s.coinsPurchase, derived.prestige]);

// Phase 32: refresh withdrawals from server
useEffect(() => {
  actions.fetchWithdrawalsServer();
  const id = setInterval(() => actions.fetchWithdrawalsServer(), 20000);
  return () => clearInterval(id);
}, [s.userId]);

return { state, derived, actions };
}function calcPrestige(state){
  state = ensureZooSystems(state);
  let p = 0;

  // Pens unlocked
  for (const sl of state.zooSlots || []){
    if (sl.unlocked) p += 15;
  }

  // Animal ownership + level + rarity
  for (const def of ANIMALS){
    const owned = state.ownedAnimals?.[def.id] || 0;
    if (!owned) continue;
    const tier = def.rarityTier || "common";
    const base = RARITY_PRESTIGE[tier] ?? 10;
    const lvl = levelFor(state, def.id);
    const lvlMult = 1 + (lvl - 1) * 0.10;
    p += owned * base * lvlMult;
  }

  return Math.floor(p);
}

function prestigeRank(prestige){
  let rank = PRESTIGE_RANKS[0];
  for (const r of PRESTIGE_RANKS){
    if (prestige >= r.min) rank = r;
  }
  return rank;
}

function prestigeRequiredForSlot(slotId){
  // light gating only for later pens
  if (slotId <= 3) return 0;
  if (slotId === 4) return 750;
  if (slotId === 5) return 2000;
  return 0;
}



# TonZoo Prototype (Phase 1)

## Install & Run
1) Install Node.js (LTS).
2) In this folder:
   - `npm install`
   - `npm run dev`

Open the URL printed in the terminal.

## Notes
- Top up is demod (adds Coins for purchases + visitors bonus).
- Withdraw coins come ONLY from exchanging tickets.
- Withdrawal requests are stored locally as "Pending".
- Progress saves to localStorage.


## Run as a Telegram Mini App (TWA)
1) Deploy this project to HTTPS hosting (Vercel/Netlify/Cloudflare Pages).
2) In BotFather:
   - Set **Menu Button** URL to your deployed site (or set a Web App button).
3) Open your bot in Telegram → tap the menu button → TonZoo opens.

### Local testing
You can run locally with `npm run dev`, but Telegram requires HTTPS for real embedding.


## Phase 2 additions
- Tasks (Daily + One-time)
- Boosters (timed multipliers + free wheel spin)


## Phase 2.5 additions
- Auction mini-game (demod competitors, visitor bids, 80% refund on loss)


## Phase 4 additions
- Telegram start parameter parsing (tgWebAppStartParam / initDataUnsafe.start_param)
- Referral deep link format using startapp=ref_CODE
- TON Connect scaffolding (@tonconnect/ui-react) + connect button + sendTransaction deposit flow (demo + real TonConnect option)


## Phase 5 additions
- App config (bot username, miniapp shortname, treasury)
- Referral invite link uses startapp=ref_CODE with optional /shortname
- Deposit receipt model (Pending/Confirmed) + demo confirm
- Withdrawal queue admin demo mode (mark paid/reject)


## Polish pass
- Fixed missing imports in Friends screen
- Rebuilt Profile screen UI (TonConnect + deposit/withdraw panels)
- Added small UI transitions + safe-area padding


## UI consistency pass
- Unified card padding/radius, pills, list items, segmented tabs, button styling
- Improved Games/Auction/Tasks/Boosters layouts
- Enhanced Animals deposit-only badge


## Phase 6
- Swipe indicators for carousels
- First-run tutorial overlay


## Phase 7
- Framer Motion spring swipe carousel (Animals + Pavilions)
- Active-card scaling + snap + smoother gestures


## Reward FX
- Floating reward pops for buys/wins
- Toast notifications for claims/requests
- Confetti burst for jackpots/auction wins/milestones/deposit confirm


## Phase 9
- Multi-color confetti (cyan/purple/pink)
- Icon fly-ups for tickets/visitors/coins rewards


## Withdrawal gate
- Withdrawals require at least $1 total deposits (prototype). Enforced via depositUsdTotal >= 1.


## Onboarding
- Starting visitors set to first animal cost (180) so players can buy one animal immediately.
- Animated intro story replaces tutorial overlay.


## Cinematic intro
- 2.4s logo reveal then animated onboarding steps
- Tap highlights guide users to key tabs


## Guided first purchase
- After intro, Zoo opens directly on Animals.
- Animals tab + first buy button pulse until first animal is bought.


## Phase 11 (Cool upgrades)
- Summon animation modal when buying animals/pavilions
- Achievement unlock modal (first animal/pavilion/mission + big win)
- Lightweight SFX using WebAudio (toggle in Profile)


## Phase 12 (Wow pack)
- In-card hatch burst animation after purchases
- Achievements panel (Profile) with claimable rewards
- Global button press feel (CSS) + click SFX + light haptics


## Phase 13 (Live events)
- Events tab with limited-time animal + countdown
- Event Pass (+10% tickets) gated by total deposits
- Weekly local leaderboard (prototype) with weekly UTC reset


## Phase 14 (Events expansion)
- Rewards Track (tiers) with free + pass rewards
- Event Quests (daily) that grant event points
- Weekly leaderboard prizes delivered to Inbox on reset


## Phase 15B (B2 Auto-Verify Deposits)
- Added /server express app for on-chain verification (TON + USDT prototype)
- Frontend Deposit modal creates deposit intent + shows required comment
- "Check Deposits" polls server and credits coins + treasury split when confirmed

### Run server
```bash
cd server
cp .env.example .env
npm install
npm run dev
```

### Run frontend
```bash
npm install
npm run dev
```


## Phase 16 (Phase C: Withdrawals server queue + user currency)
- Withdrawal requests go to server (TON or USDT choice)
- Server processes withdrawals after delay and deducts only from Treasury ledger
- Frontend syncs server ledger and updates local withdrawal statuses


## Phase 17 (Demo Wallet)
- Added Demo Pay button in Deposit modal to instantly confirm a deposit intent (no blockchain)
- Server endpoint `/api/demo/confirm` for demo/testing only


## Phase 18 (Demo wallet UI + optional real TonConnect)
- Deposit modal has Wallet Mode: Demo Wallet or Real TonConnect
- Demo Wallet shows a fake approval popup and confirms deposit instantly
- Real TonConnect uses TonConnectButton + sendTransaction for TON deposits
- USDT via TonConnect is marked as next phase (use Demo for USDT deposits)


## Phase 20 (Bulletproof deposit confirmation)
- Server runs an auto-poller to scan and confirm pending deposits (POLL_INTERVAL_MS)
- Client auto-checks deposits after TonConnect payments (TON + USDT)
- Greatly reduces cases where users have to manually spam "Check Deposits"


## Phase 21 (Server receipt store persistence)
- Server persists ledger + deposits + withdrawals to `DB_FILE` (default: server/tonzoo_db.json)
- Prevents losing confirmations if client reloads or server restarts


## Phase 22 (Icons + Telegram mobile polish)
- Added favicon + Apple touch icon + PWA manifest
- Added app icons (192/512) and updated TonConnect iconUrl
- Improved mobile touch behavior (no overscroll, tap highlight off, safe-area/viewport-fit)


## Phase 23 (Telegram native feel)
- Telegram WebApp theme sync (colors update live)
- Telegram HapticFeedback on key events
- Telegram BackButton closes open modals


## Phase 24 (Animal progression + Zoo pens)
- Added Zoo Pens (2 unlocked at start). Only placed animals generate visitors.
- Added animal rarities (mapped from catalog) + level system (Lv.1-20) affecting visitor output.
- Added Level Up using purchase coins and slot unlocks using purchase coins.


## Phase 26 (Prestige + Global Leaderboards + Unlock gating)
- Added Prestige score + Rank derived from owned animals (rarity + levels) and pens.
- Added mock Global Leaderboards (Visitors/Prestige) on Profile.
- Added Prestige gating for late pens (Pen 5: 750+, Pen 6: 2000+).


## Phase 27 (Mini-games pack + safe rewards)
- Added Card Flip (tickets -> purchase coins), Coin Rush (visitors -> purchase coins), Ticket Exchange (daily capped).
- Updated Games result UI to show coins/tickets.


## Phase 28 (Server leaderboard + anti-abuse)
- Added server leaderboard report + top endpoints.
- Client reports (userId,name,visitors,prestige) every 30s.
- Added server rate limiting and daily withdrawal per-user cap.
- Profile leaderboard now pulls real server leaderboard with fallback.


## Phase 29 (Referrals)
- Added referral registration via Telegram start_param `ref_<userId>`.
- Server stores referrer and grants inviter +600 purchase coins when invitee confirms first deposit.
- Profile shows Invite card with copy/share and Claim button.


## Phase 30 (Server profiles + balance sync)
- Added server profile sync endpoints storing player name, visitors, prestige, and purchase-coin balance.
- Client syncs every 30s and applies server balances.
- Withdrawals now validate against server-stored coin balance and deduct coins on request.


## Phase 31 (Admin dashboard)
- Added admin auth via ADMIN_KEY (x-admin-key).
- Added admin endpoints: status, config, withdrawals list/approve/deny, treasury adjust.
- Withdrawals now start as Requested, require admin approve, and process endpoint pays Approved only.
- Added in-app AdminScreen (start_param=admin) with moderation tools.


## Phase 32 (Payout hooks + tx audit trail)
- Added withdrawal fields: txHash, paidBy, paidAt.
- Admin can Set TX and Mark Paid manually (stores txHash).
- Added /api/withdrawals/list for user history synced from server.
- Client auto-refreshes withdrawal history.


## Phase 33 (Withdrawal UX)
- Added in-Profile withdrawal request form with coin slider, quick buttons, fee/net preview.
- Added status timeline explanation (Requested → Approved → Paid).
- Improved mobile-friendly inputs.


## Phase 34 (Withdrawal status cards)
- Each withdrawal request now shows a 3-step timeline with status highlighting.
- Added countdown display to processAfter (Ready / Xm / Xh Ym).
- Profile re-renders every 30s for countdown updates.


## Phase 35 (Visitors growth loop)
- Fixed VisitorsScreen and added Daily Check-in (streak rewards).
- Added Marketing/Attractions upgrades (coin sinks) and a 2h Marketing Boost (ticket sink).
- Visitors per day now scales with upgrades, boost, and streak.
- Added occasional Tour Bus visitor burst event.


## Phase 35.1 (Bugfix)
- Fixed server/index.js syntax and ES module imports (fs/path).


## Phase 35.2 (Integration fix)
- Restored missing src/telegram/theme.js used by App.


## Phase 36a (Icon + UI polish)
- Added Icon component with lightweight inline SVG icons.
- Visitors screen upgraded to KPI grid layout and icon buttons.
- Withdrawal UX buttons and TX display now use icons.


## Phase 36B (Polish everything)
- Added nav + feature icons across main screens.
- Improved global glass/shadow styling, list rows, segmented tabs.
- Added consistent empty states and micro-interactions.


## Phase 36C (Motion polish)
- Added framer-motion screen transitions for main tabs and Zoo sub-tabs.
- Added animated active highlight for segmented tabs and bottom nav.
- Smoothed micro-interactions and transitions.


## Phase 36D (Reward motion polish)
- Juiced RewardFX: stronger pop springs, drifted icon fly-ups, blurred toast transitions.
- Bigger confetti burst with stagger.
- Mini-game big rewards trigger celebrate + pop + icon bursts.
- Per-type UI event lifetimes.


## Phase 36E (Animal reveal)
- Rebuilt AnimalCarousel (fixed invalid placeholder code) and added a premium reveal overlay.
- Card flip / reveal animation + local confetti burst when buying an animal.
- Added new hatch/reveal styles.


## Phase 36E.1 (No placeholder config)
- Removed hard-coded placeholder TREASURY_ADDRESS.
- Treasury address now comes from VITE_TREASURY_ADDRESS (.env).
- Deposit UI shows a clear warning and disables real sends if treasury is not configured.


## Strict pass (no placeholder/stub/mock words)
- Removed hard-coded placeholder treasury address; now uses VITE_TREASURY_ADDRESS.
- Updated copy and internal comments to avoid stub/mock language.
- Server payout mode: PAYOUT_MODE=manual (default) or PAYOUT_MODE=auto (testing).


## Phase 37 (Synergies + Featured + Collections)
- Added synergy multipliers based on owned animal combos.
- Added daily Featured Animal (10% cost discount; +5% visitors/day if owned).
- Added collection unlocks that grant permanent visitor multipliers + a one-time ticket chest.
- UI panels added in Animals screen and featured badges in carousel.


## Phase 38 (Set Tracking + Claim Screen)
- Collections are now claimable (unlocked -> claim ticket chest).
- Added Collection Tracker UI with progress bars and Claim buttons.
- Featured animal shows countdown until reset.


## Phase 39 (Synergy status + suggestions)
- Synergies now show live Active/Inactive status with per-animal check pills.
- Added suggested next animal to complete the closest synergy.
- One-tap Buy CTA (if affordable) directly from the Synergy panel.


## Phase 40 (Featured Shop Spotlight)
- Added a Featured Animal spotlight section to the Shop/Boosters tab.
- Countdown until reset, spotlight pulse animation, and Quick Buy flow.


## Phase 41 (Smart Shop Recommendations)
- Added Recommended Picks in Shop: Best ROI, Complete Synergy, and Affordable Now.
- Each recommendation shows ROI, cost, and a quick Buy CTA.
- Added small icon tiles for recommended rows.


## Phase 42 (Plan / Wishlist)
- Added Plan list (wishlist) for animals.
- Smart notifications when a planned animal becomes affordable.
- Recommended Picks now includes an “Add to Plan” action.
- Plan UI shows cost, affordability, remove, clear, and one-tap buy.


## Phase 43 (Plan Auto-Queue)
- Added Auto-buy toggle for Plan items.
- Auto-buys the first affordable planned animal (one per tick/check-in).
- Daily safety limit (1/2/3/5, capped) with today usage display.


## Phase 44 (Zoo Map / Zones)
- Added unlockable Zoo Zones (Safari, Arctic, Reptile House, Aviary) with permanent visitor multipliers.
- Zones can be upgraded (levels) for additional scaling bonuses.
- Unlocks cost visitors and have simple ownership requirements.
- UI added to Animals screen: Zoo Map with unlock/upgrade buttons.


## Phase 45 (Zone Quests)
- Added daily rotating Zone Quests (2 per zone per day).
- Quests track progress automatically and can be claimed for rewards.
- Rewards (Style A): tickets, temporary +10% boost, and zone badges.
- Added quest boost indicator in Zoo Map.


## Phase 46 (Cosmetics Shop)
- Added Zone Tickets currency (earned from zone quests alongside tickets).
- Cosmetics Shop in Shop tab: buy and equip borders/nameplates/icons (visual only).
- Equipping a border applies subtle card-frame styling globally.


## Phase 47 (Cosmetic Preview + Profile Card)
- Added cosmetic preview modal in Cosmetics Shop (tap an item).
- Added Profile card showing equipped icon/nameplate/border and quick navigation.
- Added styling for nameplate and preview frame.


## Phase 48 (Visual-only Cosmetic Set Bonuses)
- If you own a zone border cosmetic AND have that zone's quest badge, the zone row sparkles (visual only).
- Stronger sparkle when the matching border is equipped.
- Profile shows 'Set Bonus active' indicator when any set is active.


## Phase 49 (Cosmetic Loadout Presets)
- Added 3 cosmetic presets (save + load) from Profile.
- Presets store equipped border/nameplate/profile icon.
- Fast swapping for seasonal looks.
